﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Resources;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Refrigtz")]
[assembly: AssemblyDescription("This Computer program is published by Tetra Shop E-Commerce Company and is freeware. All Non Compercial Uses is Non Illegal CopyRighted By Ramin Edjlal of Pre-User of Manshoreh Varzesh Inistitude. All Of the exeption of this uses can be kept under criminal Copyrighted 2016 Tetra Shop of edjlal.sellfile.ir URL.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Manshoreh Varzesh")]
[assembly: AssemblyProduct("Refrigtz")]
[assembly: AssemblyCopyright("Copyright ©  2016")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(true)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("3d42e3c2-d505-4a01-b16a-b706bbd9378d")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers 
// by using the '*' as shown below:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("13.55.88.440")]
[assembly: AssemblyFileVersion("13.55.88.440")]
[assembly: NeutralResourcesLanguageAttribute("fa")]
