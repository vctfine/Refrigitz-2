﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;





















namespace Refrigtz
{
    public class ClassLoad
    {
        public static void Load_f()
        {            
            (new Load()).ShowDialog();
        }
    }
}
