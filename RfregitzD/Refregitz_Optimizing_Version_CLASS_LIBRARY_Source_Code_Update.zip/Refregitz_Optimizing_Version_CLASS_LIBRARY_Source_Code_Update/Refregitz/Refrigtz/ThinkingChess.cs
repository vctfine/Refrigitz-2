/****************************************************************************
 * Thinking Operation class.*************************************************
 * Ramin Edjlal**************************************************************
 * Drived Classess of Autamata Cellular Quantum Thinking Kernel**************
 * 1394/12/19****************************************************************
 * Crashed with Stack Overflow Exception***************************************RS**0.12**4**Managements and Cuation Programing**********************(+)
 * Drives Caused Memory lack***************************************************RS**0.12**4**Managements and Cuation Programing**********************(+)
 * New Version Cased Stack Overflow********************************************RS**0.12**4**Managements and Cuation Programing**********************(+)
 * Scanning Four Dimension Homes of Thing Existences Taking A lot Of Time******RS**0.12**4**Managements and Cuation Programing**********************(+)
 * All Data in This Scope From AllDraw Become Clear When Scope Changes*********RS**0.12**4**Managements and Cuation Programing**********************(+)
 * Heuristic Work but the Movements And Attack Method Doesn’t work*************RS**0.12**4**Managements and Cuation Programing**********************(+)
 * Probability Heuristic constant Table return*********************************RS**0.12**4**Managements and Cuation Programing**********************(+)
 * Heuristic Working Not Constant Immunity*************************************RS**0.12**4**Managements and Cuation Programing**********************(+)
 * Heuristic Constant Result Mechanism*****************************************RS**0.12**4**Managements and Cuation Programing**********************(+)
 * Things Order and Virtualization Error***************************************RS**0.12**4**Managements and Cuation Programing**********************(+)
 * Misleading Things Order movement********************************************RS**0.12**4**Managements and Cuation Programing**********************(+)
 * Multi Movements (3 ) In Chess Thinking**************************************RS**0.12**4**Managements and Cuation Programing**********************(+)
 * Location of Horse 'Bob' (Gray) After Hitting Un logically UnSelfSupported***RS**0.12**4**Managements and Cuation Programing**********************(+)
 * Check Thinking 'Alice' Malfunction*******************************************RS**0.12**4**Managements and Cuation Programing*********************(+)
 * 'CheckMate' By 'Bob' Have Not Been Recognized.***********************************RS**0.12**4**Managements and Cuation Programing*****************(+)
 * 'Check' By 'Bob' Not Recognized.*********************************************RS**0.12**4**Managements and Cuation Programing*********************(+)
 * 'Check' 'Alice' Detected. No Action Was Done.********************************RS**0.12**4**Managements and Cuation Programing*********************(+)
 * 'Check' Mechanism Failure.***************************************************RS**0.12**4**Managements and Cuation Programing*********************(+)
 * Strategy By 'Alice' Changed. 'Check' Not Recognized By 'Alice'.**************RS**0.12**4**Managements and Cuation Programing*********************(+)
 * Heuristic Loop**************************************************************RS**0.12**4**Managements and Cuation Programing**********************(+)
 * 'Check' Mechanism For Penalty Regard Is Malfunction**************************RC**0.88**1**Risk Control*******************************************(*)QC-OK.
 * Things Location Failure. Row and Column of this Objects class Malfunction***RS**0.12**4**Managements and Cuation Programing**********************(+)
 * Malfunction Of Operating Lists in this class.*******************************RS**0.12**4**Managements and Cuation Programing**********************(+)
 * Some Movements of All Possible Movements is not Identified******************RS**0.12**4**Managements and Cuation Programing**********************(+)
 * Malfunction Clone Data To be Copied. List Will be erased********************RS**0.12**4**Managements and Cuation Programing**********************(+)
 * King Cannot Hit UnSelfSupported Enemy Things at Check.***********************RS**0.12**4**Managements and Cuation Programing**********************(+)
 * Thinking Time Taking al lot of time.****************************************RS**0.12**4**Managements and Cuation Programing**********************(+)
 * There is No Reason For Mal Function of Thinking.****************************RS**0.12**4**Managements and Cuation Programing**********************[+]
 * Huristic SelfSupported at horse huristic cal at table content malfunction.**RS**0.12**4**Managements and Cuation Programing**********************[+]
 * No Reason for malfunctioning of table content at huristic SelfSupported.****RS**0.12**4**Managements and Cuation Programing**********************[+]
 * Thinking Finished Misleading.bool Variable of Think Finished Not Work on.***RS**0.12**4**Managements and Cuation Programing**********************(+) 
 * A non Identified King Table List Alice is in List and Unhabitly ignored.****RS**0.12**4**Managements and Cuation Programing**********************(+)
 * The Location of Penalty Regard Mechansim is Misleading.*********************RS**0.12**4**Managements and Cuation Programing**********************(+)
 * Penalty Reagrd List is Empty.No Misleading List of Penalty Regard Mec.******RS**0.12**4**Managements and Cuation Programing**********************(+)
 * No Ilegal Non ObjectDanger and Check By 'Alice' at Current Game in PR Mech.********RS**0.12**4**Managements and Cuation Programing***************(+)
 * Mechansianm For Like Napeloonires KLish CheckMate is Incompletable.**************RC**0.88**1**Risk Control***************************************(*)QC-OK.
 * Ileegal Table Content Ignoring of Objects Kind.*****************************RC**0.88**1**Risk Control********************************************(*)QC-OK.
 * Tree Construction of AStarGready is Uncompleted.Some Nodes Become Empty.****RS**0.12**4**Managements and Cuation Programing**********************<+>
 * All Penalty Leads to 16 Objects Unmovable or Make Penalty But in Reality Non Penalty Exist.******************************************************(+)
 * All Self and Enemy CheckMate Mechanisam is Logical else Mislaeading.*************RC**0.88**1**Risk Control***************************************(*).QC-Ok.
 * Proccess of Thinking Stop Misleading With Error.*********************************RC**0.88**1**Risk Control***************************************{*}.QC-Ok.
 * All List of this class make differncy at several runable state of one table board state.RC**0.88**1**Risk Control********************************{*}.QC-OK.
 * Thinking Act Misleading.***************************************************************.RC**0.88**1**Risk Control********************************{*}QC-OK.
 * The Achmaz Removing and maybe SelfNotSupported in Attacker conflict and thus Ignore.RC**0.88**1**Risk Control************************************(*)QC-OK.
 * The Self Supporter in Attacker somthime goes to misleading act.********************.RC**0.88**1**Risk Control************************************(*)QC-Ok.
 * Enemy Attacker Not Supported act Misleading.***************************************.RC**0.88**1**Risk Control************************************(*)QC_OK.
 * Heuristic proccesing dosne't haave any aim.****************************************.RC**0.88**1**Risk Control************************************(*)QC-OK.
 * Rating of Alice as Computer Game is very weak as compatitor of users.**************.RC**0.88**1**Risk Control************************************<*>QC_BAD.
 * Thinking gone to take some part of stones.*****************************************.RC**0.88**1**Risk Control************************************<*>QC_BAD.
 * Thinking failed becuase of all possible movment penalties of first level**.********.RC**0.88**1**Risk Control************************************<*>QC_OK.
 * Object Dangour and Check is aditive of HeuristicCheckedand checked mated.**********.RC**0.88**1**Risk Control************************************<*>QC_OK.
 * Heuristics take some part of stone.************************************************.RC**0.88**1**Risk Control************************************<*>QC_OK.
 * Branch Dept at Thinking Tree is low becuse of harware constraints and speed.*******.RC**0.88**1**Risk Control************************************<*>QC_BAD.
 * Thinking falied becuase of All Possible of Penalties movments.*********************.RC**0.88**1**Risk Control************************************<*>QC_OK.
 * Tow Confliction Misleading in Self Attacked and King Dangoure Separatedly.*********.RC**0.88**1**Risk Control************************************<*>QC_OK.
 * Conflict in Restoring UsePenaltyRegardMechanisam value during User false.**********.RC**0.88**1**Risk Control************************************<*>QC_OK.
 * Self Objects Movments Comes to Dangrous Location.**********************************.RC**0.88**1**Risk Control************************************(*).
 * Thinking Tree Construction was not Complition and have empty with no reason.*********************************************************************{*}
 * Heuristic of 'Attack';'Movment';'Support';'CheckMate...' Undisiarable.***************************************************************************<*>
 * **************************************************************************(+:Sum(26)) (*:Sum(1)) 5:(+:Sum(3)) 6.(+:Sum0.12**4**Managements and Cuation Programing**********************(+)) 7.(QC-OK:Sum(1))
 * **************************************************************************
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Threading;
using LearningMachine;
using System.IO;
using System.Diagnostics;
using System.Threading.Tasks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
namespace Refrigtz
{
    public class ThinkingChess
    {
        //Initiate Global and Static Variables.        
        const int ThresholdBlitz = 10000;
        const int ThresholdFullGame = 20000;
        bool BeforeAttacker = false;
        public static double MaxHuristicx = Double.MinValue;
        public bool MovementsAStarGreedyHuristicFoundT = false;
        public bool IgnoreSelfObjectsT = false;
        public bool UsePenaltyRegardMechnisamT = true;
        public bool BestMovmentsT = false;
        public bool PredictHuristicT = true;
        public bool OnlySelfT = false;
        public bool AStarGreedyHuristicT = false;
        bool ArrangmentsChanged = false;
        public int NumberOfPenalties = 0;
        static int NumbersOfCurrentBranchesPenalties = 0;
        public static int NumbersOfAllNode = 0;
        public int SodierMidle = 8;
        public int SodierHigh = 16;
        public int ElefantMidle = 2;
        public int ElefantHigh = 4;
        public int HourseMidle = 2;
        public int HourseHight = 4;
        public int BridgeMidle = 2;
        public int BridgeHigh = 4;
        public int MinisterMidle = 1;
        public int MinisterHigh = 2;
        public int KingMidle = 1;
        public int KingHigh = 2;
        public static bool KingMaovableGray = false;
        public static bool KingMaovableBrown = false;
        public static int FoundFirstMating = 0;
        bool EE = false;
        public int SodierValue = 1 * 3;//1 * 3;
        public int ElefantValue = 2 * 16;//2 * 16;
        public int HourseValue = 3 * 8;//3 * 8;
        public int BridgeValue = 5 * 16;//5 * 16;
        public int MinisterValue = 8 * 32;//8 * 32;
        public int KingValue = 10 * 8;//10 * 8;
        public static int BeginThread = 0;
        public static int EndThread = 0;
        bool ExistingOfEnemyHiiting = false;
        int IgnoreObjectDangour = -1;
        public int CheckMateAStarGreedy = 0;
        bool CheckMateOcuured = false;
        int CurrentRow = -1, CurrentColumn = -1;
        public bool IsCheck = false;
        public bool SelfCheckMateAction = false;
        public bool AchamazCurrent = false;
        public bool InAttackedNotSelfSupported = false;
        public bool SelfSupported = false;
        public bool InAttackedNotSelfSupportedBefore = false;
        public bool SelfSupportedBefore = false;
        public bool EnemyNotSupported = false;
        public bool InAttackedNotEnemySupported = false;
        public static int Sign = 1;
        public int Kind = 0;
        public List<int> HitNumber = new List<int>();
        public static bool NotSolvedKingDanger = false;
        public static bool ThinkingRun = false;
        public int ThingsNumber = 0;
        public int CurrentArray = 0;
        public double HuristicAttackValue = 0;
        public double HuristicMovementValue = 0;
        public double HuristicSelfSupportedValue = 0;
        public double HuristicObjectDangourCheckMateValue = 0;
        public double HuristicHittingValue = 0;
        public double HuristicReducedAttackValue = 0;
        public double HeuristicDistabceOfCurrentMoveFromEnemyKingValue = 0;
        public bool ThinkingBegin = false;
        public bool ThinkingFinished = false;
        public int IndexSoldier = 0;
        public int IndexElefant = 0;
        public int IndexHourse = 0;
        public int IndexBridge = 0;
        public int IndexMinister = 0;
        public int IndexKing = 0;
        static public int Index = 0;
        static public int[,] RowColumn;
        public List<int[]> RowColumnSoldier;
        public List<int[]> RowColumnElefant;
        public List<int[]> RowColumnHourse;
        public List<int[]> RowColumnBridge;
        public List<int[]> RowColumnMinister;
        public List<int[]> RowColumnKing;
        public int[,] TableT;
        public List<int> HitNumberSoldier;
        public List<int> HitNumberElefant;
        public List<int> HitNumberHourse;
        public List<int> HitNumberBridge;
        public List<int> HitNumberMinister;
        public List<int> HitNumberKing;
        public int[,] TableConst;
        public List<int[,]> TableListSolder = new List<int[,]>();
        public List<int[,]> TableListElefant = new List<int[,]>();
        public List<int[,]> TableListHourse = new List<int[,]>();
        public List<int[,]> TableListBridge = new List<int[,]>();
        public List<int[,]> TableListMinister = new List<int[,]>();
        public List<int[,]> TableListKing = new List<int[,]>();
        public List<double[]> HuristicListSolder = new List<double[]>();
        public List<double[]> HuristicListElefant = new List<double[]>();
        public List<double[]> HuristicListHourse = new List<double[]>();
        public List<double[]> HuristicListBridge = new List<double[]>();
        public List<double[]> HuristicListMinister = new List<double[]>();
        public List<double[]> HuristicListKing = new List<double[]>();
        public List<QuantumAtamata> PenaltyRegardListSolder = new List<QuantumAtamata>();
        public List<QuantumAtamata> PenaltyRegardListElefant = new List<QuantumAtamata>();
        public List<QuantumAtamata> PenaltyRegardListHourse = new List<QuantumAtamata>();
        public List<QuantumAtamata> PenaltyRegardListBridge = new List<QuantumAtamata>();
        public List<QuantumAtamata> PenaltyRegardListMinister = new List<QuantumAtamata>();
        public List<QuantumAtamata> PenaltyRegardListKing = new List<QuantumAtamata>();
        public int Max;
        public int Row, Column;
        public Color color;
        public int Order;
        public Task t = null;
        public List<AllDraw> AStarGreedy = null;
        public FormRefrigtz THIS;
        private static ParallelLoopResult result1;
        public static long SomeExtremelyLargeNumber { get; private set; }
        ///Log of Errors.
        static void Log(Exception ex)
        {
            
                //Initiate Variable.
                string stackTrace = ex.ToString();
                //Write to File.
                File.AppendAllText(FormRefrigtz.Root + "\\ErrorProgramRun.txt", stackTrace + ": On" + DateTime.Now.ToString()); /// path of file where stack trace will be stored.
           
        }
        //Constructor
        public ThinkingChess(bool MovementsAStarGreedyHuristicTFou, bool IgnoreSelfObject, bool UsePenaltyRegardMechnisa, bool BestMovment, bool PredictHurist, bool OnlySel, bool AStarGreedyHuris, bool Arrangments, int i, int j)
        {
            //Initiate Variables.
            MovementsAStarGreedyHuristicFoundT = MovementsAStarGreedyHuristicTFou;
            IgnoreSelfObjectsT = IgnoreSelfObject;
            UsePenaltyRegardMechnisamT = UsePenaltyRegardMechnisa;
            BestMovmentsT = BestMovment;
            PredictHuristicT = PredictHurist;
            OnlySelfT = OnlySel;
            AStarGreedyHuristicT = AStarGreedyHuris;

            ArrangmentsChanged = Arrangments;
            Row = i;
            Column = j;
            //Clear Dearty Part.
            TableListSolder.Clear();
            TableListElefant.Clear();
            TableListHourse.Clear();
            TableListBridge.Clear();
            TableListMinister.Clear();
            TableListKing.Clear();
            RowColumnSoldier = new List<int[]>();
            RowColumnElefant = new List<int[]>();
            RowColumnHourse = new List<int[]>();
            RowColumnBridge = new List<int[]>();
            RowColumnMinister = new List<int[]>();
            RowColumnKing = new List<int[]>();
            HitNumberSoldier = new List<int>();
            HitNumberElefant = new List<int>();
            HitNumberHourse = new List<int>();
            HitNumberBridge = new List<int>();
            HitNumberMinister = new List<int>();
            HitNumberKing = new List<int>();
            PenaltyRegardListSolder = new List<QuantumAtamata>();
            PenaltyRegardListElefant = new List<QuantumAtamata>();
            PenaltyRegardListHourse = new List<QuantumAtamata>();
            PenaltyRegardListBridge = new List<QuantumAtamata>();
            PenaltyRegardListMinister = new List<QuantumAtamata>();
            PenaltyRegardListKing = new List<QuantumAtamata>();
            AStarGreedy = new List<AllDraw>();

        }

        ///Constructor
        public ThinkingChess(
                bool MovementsAStarGreedyHuristicTFou,
            bool IgnoreSelfObject,
            bool UsePenaltyRegardMechnisa,
            bool BestMovment,
            bool PredictHurist,
            bool OnlySel,
            bool AStarGreedyHuris,
        bool Arrangments, int i, int j, Color a, int[,] Tab, int Ma, int Ord, bool ThinkingBeg, int CurA, int ThingN//, ref FormRefrigtz TH
            , int Kin)
        {
            MovementsAStarGreedyHuristicFoundT = MovementsAStarGreedyHuristicTFou;
            IgnoreSelfObjectsT = IgnoreSelfObject;
            UsePenaltyRegardMechnisamT = UsePenaltyRegardMechnisa;
            BestMovmentsT = BestMovment;
            PredictHuristicT = PredictHurist;
            OnlySelfT = OnlySel;
            AStarGreedyHuristicT = AStarGreedyHuris;
            //Initiate Variables.
            ArrangmentsChanged = Arrangments;
            Kind = Kin;
            SetObjectNumbers(Tab);
            //THIS = TH;
            AStarGreedy = new List<AllDraw>();
            ThingsNumber = ThingN;
            CurrentArray = CurA;
            TableListSolder.Clear();
            TableListElefant.Clear();
            TableListHourse.Clear();
            TableListBridge.Clear();
            TableListMinister.Clear();
            TableListKing.Clear();
            RowColumnSoldier = new List<int[]>();
            RowColumnElefant = new List<int[]>();
            RowColumnHourse = new List<int[]>();
            RowColumnBridge = new List<int[]>();
            RowColumnMinister = new List<int[]>();
            RowColumnKing = new List<int[]>();
            RowColumn = new int[1000000, 2];
            HitNumberSoldier = new List<int>();
            HitNumberElefant = new List<int>();
            HitNumberHourse = new List<int>();
            HitNumberBridge = new List<int>();
            HitNumberMinister = new List<int>();
            HitNumberKing = new List<int>();
            PenaltyRegardListSolder = new List<QuantumAtamata>();
            PenaltyRegardListElefant = new List<QuantumAtamata>();
            PenaltyRegardListHourse = new List<QuantumAtamata>();
            PenaltyRegardListBridge = new List<QuantumAtamata>();
            PenaltyRegardListMinister = new List<QuantumAtamata>();
            PenaltyRegardListKing = new List<QuantumAtamata>();
            Row = i;
            Column = j;
            color = a;
            Max = Ma;
            TableT = Tab;
            Index = 0;
            IndexSoldier = 0;
            IndexElefant = 0;
            IndexHourse = 0;
            IndexBridge = 0;
            IndexMinister = 0;
            IndexKing = 0;
            TableConst = new int[8, 8];
            for (int ii = 0;
                ii < 8; ii++)
                for (int jj = 0; jj < 8; jj++)
                {
                    TableConst[ii, jj] = TableT[ii, jj];
                }
            Order = Ord;
            ThinkingBegin = ThinkingBeg;
            AStarGreedy = new List<AllDraw>();

        }
        //Clone A Table
        int[,] CloneATable(int[,] Tab)
        {
            //Create and new an Object.
            int[,] Table = new int[8, 8];
            //Assigne Parameter To New Objects.
            for (int i = 0; i < 8; i++)
                for (int j = 0; j < 8; j++)
                    Table[i, j] = Tab[i, j];
            //Return New Object.
            return Table;
        }
        //Clone A List.  
        int[] CloneAList(int[] Tab, int Count)
        {
            //Initiate new Objects.
            int[] Table = new int[Count];
            //Asigne to new Objects.
            for (int i = 0; i < Count; i++)
                Table[i] = Tab[i];
            //Retrun new Object.
            return Table;
        }
        //Clone a copy of an array.
        double[] CloneAList(double[] Tab, int Count)
        {
            //Initiate New Object.
            double[] Table = new double[Count];
            //Assigne to new Object.,
            for (int i = 0; i < Count; i++)
                Table[i] = Tab[i];
            //Return New Object.
            return Table;
        }
        ///Clone a Copy.
        public void Clone(ref ThinkingChess AA//, ref FormRefrigtz THIS
            )
        {
            //Assignment Content to New Content Object.
            //Initaite New Object.
            AA = new ThinkingChess(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, Row, Column);
            AA.ArrangmentsChanged = ArrangmentsChanged;
            //When Depth Object is not NULL.
            if (AStarGreedy.Count != 0)
            {
                AA.AStarGreedy = new System.Collections.Generic.List<AllDraw>();
                //For All Depth(s).
                for (int i = 0; i < AStarGreedy.Count; i++)
                {
                    
                        //Clone a Copy From Depth Objects.
                        AStarGreedy[i].Clone(AA.AStarGreedy[i]);
                   
                }
            }
            //For All Moves Indexx Solders List Count.
            for (int j = 0; j < RowColumnSoldier.Count; j++)

                //Add a Clone To New Solder indexx Object.
                AA.RowColumnSoldier.Add(CloneAList(RowColumnSoldier[j], 2));
            //For All Bridge List Count.
            for (int j = 0; j < RowColumnBridge.Count; j++)
                //Add a Clone to New Bridge index Objects List.
                AA.RowColumnBridge.Add(CloneAList(RowColumnBridge[j], 2));

            //For All Elephant index List Count.
            for (int j = 0; j < RowColumnElefant.Count; j++)
                //Add a Clone to New Elephant Object List.
                AA.RowColumnElefant.Add(CloneAList(RowColumnElefant[j], 2));
            //For All Hourse index List Count.
            for (int j = 0; j < RowColumnHourse.Count; j++)
                //Add a Clone to New Hourse index List.
                AA.RowColumnHourse.Add(CloneAList(RowColumnHourse[j], 2));
            //For All King index List Count.
            for (int j = 0; j < RowColumnKing.Count; j++)
                //Add a Clone To New King Object List.
                AA.RowColumnKing.Add(CloneAList(RowColumnKing[j], 2));
            //For All Minister index Count.
            for (int j = 0; j < RowColumnMinister.Count; j++)
                //Add a Clone To Minister New index List.
                AA.RowColumnMinister.Add(CloneAList(RowColumnMinister[j], 2));
            //Assgine thread.
            AA.t = t;
            //Create and Initiate new Table Object.
            AA.TableT = new int[8, 8];
            //Create and Initaite New Table Object.
            AA.TableConst = new int[8, 8];
            //if Table is not NULL>
            if (TableT != null)
                //For All Items in Table Object.
                for (int i = 0; i < 8; i++)
                    for (int j = 0; j < 8; j++)
                        //Assgine Table items in New Table Object.
                        AA.TableT[i, j] = TableT[i, j];
            //If Table is Not Null.
            if (TableConst != null)
                //For All Items in Table Object.
                for (int i = 0; i < 8; i++)
                    for (int j = 0; j < 8; j++)
                        //Assignm Items in New Table Object.
                        AA.TableConst[i, j] = TableConst[i, j];
            //For All Table State Movements in Bridges Objects.
            for (int i = 0; i < TableListBridge.Count; i++)
                //Add aclon of a Table in New Briges Table List.
                AA.TableListBridge.Add(CloneATable(TableListBridge[i]));
            //For All Table List Movements in  Elephant Objects 
            for (int i = 0; i < TableListElefant.Count; i++)
                //Add a Clone of Tables in Elephant Mevments Obejcts List To New One.
                AA.TableListElefant.Add(CloneATable(TableListElefant[i]));
            //For All Hourse Table Movemnts items.
            for (int i = 0; i < TableListHourse.Count; i++)
                //Add a Clone of Hourse Table Movement in New List.
                AA.TableListHourse.Add(CloneATable(TableListHourse[i]));
            //For All King Tables Movment Count.
            for (int i = 0; i < TableListKing.Count; i++)
                //Add a Clone To New King Table List.
                AA.TableListKing.Add(CloneATable(TableListKing[i]));
            //For All Minister Table Movment Items.
            for (int i = 0; i < TableListMinister.Count; i++)
                //Add a clone To New Minister Table Movment List.
                AA.TableListMinister.Add(CloneATable(TableListMinister[i]));
            //For All Solder Table Movment Count.
            for (int i = 0; i < TableListSolder.Count; i++)
                //Add a Clone of Table item to New Table List Movments.
                AA.TableListSolder.Add(CloneATable(TableListSolder[i]));

            //For All Solder Husrist List Count.
            for (int i = 0; i < HuristicListSolder.Count; i++)
                //Ad a Clone of Hueristic Solders To New List.
                AA.HuristicListSolder.Add(CloneAList(HuristicListSolder[i], 4));
            //For All Elephant Huristic List Count. 
            for (int i = 0; i < HuristicListElefant.Count; i++)
                //Add A Clone of Copy to New Elephant Huristic List.
                AA.HuristicListElefant.Add(CloneAList(HuristicListElefant[i], 4));
            //For All Hours Huristic Hourse Count.
            for (int i = 0; i < HuristicListHourse.Count; i++)
                //Add a Clone of Copy To New Housre Huristic List.
                AA.HuristicListHourse.Add(CloneAList(HuristicListHourse[i], 4));
            //For All Bridges Huristic List Count.
            for (int i = 0; i < HuristicListBridge.Count; i++)
                //Add a Clone of Copy to New Bridges Huristic List.
                AA.HuristicListBridge.Add(CloneAList(HuristicListBridge[i], 4));
            //For All Minister Huristic List Count.
            for (int i = 0; i < HuristicListMinister.Count; i++)
                //Add a Clone of Copy to New Minister List.
                AA.HuristicListMinister.Add(CloneAList(HuristicListMinister[i], 4));
            //For All King Husrict List Items.
            for (int i = 0; i < HuristicListKing.Count; i++)
                //Add a Clone of Copy to New King Hursitic List.
                AA.HuristicListKing.Add(CloneAList(HuristicListKing[i], 4));
            //Initiate and create Penalty Solder List.
            AA.PenaltyRegardListSolder = new List<QuantumAtamata>();
            //For All Solder Penalty List Count.
            for (int i = 0; i < PenaltyRegardListSolder.Count; i++)
            {
                //Initiate a new Quantum Atamata Object
                QuantumAtamata Current = new QuantumAtamata(3, 3, 3);
                //Clone a Copy Of Penalty Solider.
                PenaltyRegardListSolder[i].Clone(ref Current);
                //Add New Object Create to New Penalty Solder List.
                AA.PenaltyRegardListSolder.Add(Current);
            }
            //Initaite and Create Elephant Penalty List Object.
            AA.PenaltyRegardListElefant = new List<QuantumAtamata>();
            //For All Elepahtn Penalty List Count.
            for (int i = 0; i < PenaltyRegardListElefant.Count; i++)
            {
                //Initiate a new Quantum Atamata Object
                QuantumAtamata Current = new QuantumAtamata(3, 3, 3);
                //Clone a Copy Of Penalty Elephant.
                PenaltyRegardListElefant[i].Clone(ref Current);
                //Add New Object Create to New Penalty Elephant List.
                AA.PenaltyRegardListElefant.Add(Current);
            }
            //Initaite and Create Hourse Penalty List Object.
            AA.PenaltyRegardListHourse = new List<QuantumAtamata>();
            //For All Solder Hourse List Count.
            for (int i = 0; i < PenaltyRegardListHourse.Count; i++)
            {
                //Initiate a new Quantum Atamata Object
                QuantumAtamata Current = new QuantumAtamata(3, 3, 3);
                //Clone a Copy Of Penalty Hourse.
                PenaltyRegardListHourse[i].Clone(ref Current);
                //Add New Object Create to New Penalty Hourse List.
                AA.PenaltyRegardListHourse.Add(Current);
            }
            //Initaite and Create Bridges Penalty List Object.
            AA.PenaltyRegardListBridge = new List<QuantumAtamata>();
            //For All Solder Bridge List Count.
            for (int i = 0; i < PenaltyRegardListBridge.Count; i++)
            {
                //Initiate a new Quantum Atamata Object
                QuantumAtamata Current = new QuantumAtamata(3, 3, 3);
                //Clone a Copy Of Penalty Bridges.
                PenaltyRegardListBridge[i].Clone(ref Current);
                //Add New Object Create to New Penalty Bridges List.
                AA.PenaltyRegardListBridge.Add(Current);
            }
            //Initaite and Create Minister Penalty List Object.
            AA.PenaltyRegardListMinister = new List<QuantumAtamata>();
            //For All Solder Minster List Count.
            for (int i = 0; i < PenaltyRegardListMinister.Count; i++)
            {
                //Initiate a new Quantum Atamata Object
                QuantumAtamata Current = new QuantumAtamata(3, 3, 3);
                //Clone a Copy Of Penalty Minsiter.
                PenaltyRegardListMinister[i].Clone(ref Current);
                //Add New Object Create to New Penalty Minsietr List.
                AA.PenaltyRegardListMinister.Add(Current);
            }
            //Initaite and Create King Penalty List Object.
            AA.PenaltyRegardListKing = new List<QuantumAtamata>();
            //For All Solder King List Count.
            for (int i = 0; i < PenaltyRegardListKing.Count; i++)
            {
                //Initiate a new Quantum Atamata Object
                QuantumAtamata Current = new QuantumAtamata(3, 3, 3);
                //Clone a Copy Of Penalty King.
                PenaltyRegardListKing[i].Clone(ref Current);
                //Add New Object Create to New Penalty King List.
                AA.PenaltyRegardListKing.Add(Current);
            }
            //Iniktiate Same Obejcts to New Same Obejcts.
            AA.AchamazCurrent = AchamazCurrent;
            AA.AStarGreedy = AStarGreedy;
            AA.BridgeValue = BridgeValue;
            AA.color = color;
            AA.Column = Column;
            AA.CurrentArray = CurrentArray;
            AA.CurrentColumn = CurrentColumn;
            AA.CurrentRow = CurrentRow;
            AA.ElefantValue = ElefantValue;
            AA.EnemyNotSupported = EnemyNotSupported;
            AA.ExistingOfEnemyHiiting = ExistingOfEnemyHiiting;
            AA.HourseValue = HourseValue;
            AA.HuristicAttackValue = HuristicAttackValue;
            AA.HuristicObjectDangourCheckMateValue = HuristicObjectDangourCheckMateValue;
            AA.HuristicMovementValue = HuristicMovementValue;
            AA.HuristicSelfSupportedValue = HuristicSelfSupportedValue;
            AA.IgnoreObjectDangour = IgnoreObjectDangour;
            AA.InAttackedNotEnemySupported = InAttackedNotEnemySupported;
            AA.InAttackedNotSelfSupported = InAttackedNotSelfSupported;
            AA.IndexBridge = IndexBridge;
            AA.IndexElefant = IndexElefant;
            AA.IndexHourse = IndexHourse;
            AA.IndexKing = IndexKing;
            AA.IndexMinister = IndexMinister;
            AA.IndexSoldier = IndexSoldier;
            AA.IsCheck = IsCheck;
            AA.Kind = Kind;
            AA.KingValue = KingValue;
            AA.CheckMateAStarGreedy = CheckMateAStarGreedy;
            AA.CheckMateOcuured = CheckMateOcuured;
            AA.Max = Max;
            AA.MinisterValue = MinisterValue;
            AA.Order = Order;
            AA.Row = Row;
            AA.SelfCheckMateAction = SelfCheckMateAction;
            AA.SelfSupported = SelfSupported;
            AA.SodierValue = SodierValue;
            AA.ThingsNumber = ThingsNumber;
            AA.ThinkingBegin = ThinkingBegin;
            AA.ThinkingFinished = ThinkingFinished;
            AA.THIS = THIS;
        }
        ///Huristic of Attacker.QC-OK
        double HuristicAttack(int[,] Table, int Order, Color a, int i, int j)
        {
            double HA = 0;
            int DumOrder = Order;
            int DummyOrder = Order;
            int DummyCurrentOrder = ChessRules.CurrentOrder;
            ///When AStarGreedy Huristic is Not Assigned.
            
                //When Huristic is not Greedy.
                if (!AStarGreedyHuristicT)
                {
                    ///For Every Objects.
                    //int i = Row, j = Column;
                    ///For All Movments.
                    for (int ii = 0; ii < 8; ii++)
                    {
                        for (int jj = 0; jj < 8; jj++)
                        {
                            if (i == ii && j == jj)
                                continue;
                            int Sign = 1;
                            Order = DummyOrder;
                            ///When Attack is true. means [ii,jj] is in Attacked  [i,j].
                            ///What is Attack!
                            ///Ans:When [ii,jj] is Attacked [i,j] return true when enemy is located in [ii,jj].
                            if (Table[ii, jj] > 0 && DummyOrder == -1 && Table[i, j] < 0)
                            {
                                Order = -1;
                                Sign = 1 * AllDraw.SignAttack;
                                ChessRules.CurrentOrder = -1;
                                a = Color.Brown;
                            }
                            else if (Table[ii, jj] < 0 && DummyOrder == 1 && Table[i, j] > 0)
                            {
                                Order = 1;
                                Sign = 1 * AllDraw.SignAttack;
                                ChessRules.CurrentOrder = 1;
                                a = Color.Gray;
                            }
                            else
                                continue;
                            //For Attack Movments.
                            if (Attack(Table, i, j, ii, jj, a, Order))
                            {
                                //Find Huristic Value Of Current and Add to Sumation.
                                if (System.Math.Abs(Table[i, j]) == 1)
                                    //When Solder.
                                    HA += (Sign * System.Math.Abs(GetObjectValue(Table, ii, jj, Order) - SodierValue
                                        ));

                                else if (System.Math.Abs(Table[i, j]) == 2)
                                    //When Elephant
                                    HA += (Sign * System.Math.Abs(GetObjectValue(Table, ii, jj, Order) - ElefantValue
                                        ));
                                else if (System.Math.Abs(Table[i, j]) == 3)
                                    //When Hourse
                                    HA += (Sign * System.Math.Abs(GetObjectValue(Table, ii, jj, Order) - HourseValue
                                        ));
                                else if (System.Math.Abs(Table[i, j]) == 4)
                                    //When Bridges.
                                    HA += (Sign * System.Math.Abs(GetObjectValue(Table, ii, jj, Order) - BridgeValue
                                        ));
                                else if (System.Math.Abs(Table[i, j]) == 5)
                                    //When Minister.
                                    HA += (Sign * System.Math.Abs(GetObjectValue(Table, ii, jj, Order) - MinisterValue
                                        ));
                                else if (System.Math.Abs(Table[i, j]) == 6)
                                    //When King.
                                    HA += (Sign * System.Math.Abs(GetObjectValue(Table, ii, jj, Order) - KingValue
                                        ));
                                //When there is supporter of attacked Objects take huristic negative else take muliply sign and muliply huristic.
                                /*bool Supported = false;
                                //For All Enemy Obejcts.                                             
                                for (int g = 0; g < 8; g++)
                                    for (int h = 0; h < 8; h++)
                                    {
                                        //Ignore Of Enemy Objects.
                                        if (Order == 1 && Table[g, h] >= 0)
                                            continue;
                                        if (Order == -1 && Table[g, h] <= 0)
                                            continue;
                                        Color aa;
                                        //Assgin Enemy Colors.
                                        if (Order == -1)
                                            aa = Color.Brown;
                                        else
                                            aa = Color.Gray;
                                        //When Enemy is Supported.
                                        if (Support(Table, g, h, ii, jj, aa, Table[g, h]))
                                        {
                                            //Assgine variable.
                                            Supported = true;
                                            //Multyply 10.
                                            Sign *= 10;
                                            //When Solder.
                                            if (System.Math.Abs(Table[g, h]) == 1)
                                                HA -= (Sign * System.Math.Abs(GetObjectValue(Table,ii, jj,Order)-SodierValue 
                                                    ));
                                            //When Elephant.
                                            else if (System.Math.Abs(Table[g, h]) == 2)
                                                HA -= (Sign * System.Math.Abs(ElefantValue + GetObjectValue(Table,ii, jj,Order)
                                                    ));
                                            //When Hourse.
                                            else if (System.Math.Abs(Table[g, h]) == 3)
                                                HA -= (Sign * System.Math.Abs(HourseValue + GetObjectValue(Table,ii, jj,Order)
                                                    ));
                                            //When Bridges.
                                            else if (System.Math.Abs(Table[g, h]) == 4)
                                                HA -= (Sign * System.Math.Abs(BridgeValue + GetObjectValue(Table,ii, jj,Order)
                                                    ));
                                            //When Minister.
                                            else if (System.Math.Abs(Table[g, h]) == 5)
                                                HA -= (Sign * System.Math.Abs(MinisterValue + GetObjectValue(Table,ii, jj,Order)
                                                    ));
                                            //When King.
                                            else if (System.Math.Abs(Table[g, h]) == 6)
                                                HA -= (Sign * System.Math.Abs(KingValue + GetObjectValue(Table,ii, jj,Order)
                                                    ));

                                        }
                                    }
                                //When there is supported take positive multiply else take negative multiply.                               
                                if (!Supported)
                                    //When is Not Supported Multyply 100
                                    HA *= 100;
                                else
                                    //When is Supported Multyply -100.
                                    HA *= -100;


                                                   */

                            }
                            //When there is not attacked.
                            /*else
                            {
                                //Initiate Object.
                                bool Supported = false;

                                //For Enemy objects.
                                for (int g = 0; g < 8; g++)
                                    for (int h = 0; h < 8; h++)
                                    {
                                        //Ignore of current.
                                        if (Order == 1 && Table[g, h] >= 0)
                                            continue;
                                        if (Order == -1 && Table[g, h] <= 0)
                                            continue;
                                        Color aa;
                                        if (Order == -1)
                                            aa = Color.Brown;
                                        else
                                            aa = Color.Gray;
                                        //When there is supporter of enemy object.
                                        if (Support(Table, g, h, ii, jj, aa, Table[g, h]))
                                        {
                                            //Assigne true.
                                            Supported = true;
                                            //Multyply 10.
                                            Sign *= 10;
                                            //take negative huristic.
                                            if (System.Math.Abs(Table[g, h]) == 1)
                                                //When Solder.
                                                HA -= (Sign * System.Math.Abs(GetObjectValue(Table,ii, jj,Order)-SodierValue 
                                                    ));
                                            else if (System.Math.Abs(Table[g, h]) == 2)
                                                //When Elephant.
                                                HA -= (Sign * System.Math.Abs(ElefantValue + GetObjectValue(Table,ii, jj,Order)
                                                    ));
                                            else if (System.Math.Abs(Table[g, h]) == 3)
                                                //When Hourse.
                                                HA -= (Sign * System.Math.Abs(HourseValue + GetObjectValue(Table,ii, jj,Order)
                                                    ));
                                            else if (System.Math.Abs(Table[g, h]) == 4)
                                                //When Bridges.
                                                HA -= (Sign * System.Math.Abs(BridgeValue + GetObjectValue(Table,ii, jj,Order)
                                                    ));
                                            else if (System.Math.Abs(Table[g, h]) == 5)
                                                //When Minister
                                                HA -= (Sign * System.Math.Abs(MinisterValue + GetObjectValue(Table,ii, jj,Order)
                                                    ));
                                            else if (System.Math.Abs(Table[g, h]) == 6)
                                                //When King.
                                                HA -= (Sign * System.Math.Abs(KingValue + GetObjectValue(Table,ii, jj,Order)
                                                    ));

                                        }
                                    }
                                //When there is supported take positive multiply else take negative multiply.
                                if (!Supported)
                                    //When is Not Supported multyply 100.
                                    HA *= 100;
                                else
                                    //When is Supported Multyply -100.
                                    HA *= -100;
                            }
                             */
                        }
                    }

                }
                //For All Table Homes find Attack Huristic.
                else
                {
                    for (i = 0; i < 8; i++)
                    {
                        for (j = 0; j < 8; j++)
                        {
                            for (int ii = 0; ii < 8; ii++)
                            {
                                for (int jj = 0; jj < 8; jj++)
                                {
                                    //Ignore of Current.
                                    if (i == ii && j == jj)
                                        continue;
                                    Order = DummyOrder;
                                    int Sign = 1;
                                    ///When Attack is true. means [ii,jj] is in Attacked  [i,j].
                                    ///What is Attack!
                                    ///Ans:When [ii,jj] is Attacked [i,j] return true when enemy is located in [ii,jj].
                                    if (Table[ii, jj] > 0 && DummyOrder == -1 && Table[i, j] < 0)
                                    {
                                        Order = -1;
                                        Sign = 1 * AllDraw.SignAttack;
                                        ChessRules.CurrentOrder = -1;
                                        a = Color.Brown;
                                    }
                                    else if (Table[ii, jj] < 0 && DummyOrder == 1 && Table[i, j] > 0)
                                    {
                                        Order = 1;
                                        Sign = 1 * AllDraw.SignAttack;
                                        ChessRules.CurrentOrder = 1;
                                        a = Color.Gray;
                                    }
                                    else
                                        continue;
                                    //For Attack Movments.
                                    if (Attack(Table, i, j, ii, jj, a, Order))
                                    {
                                        //Find Huristic Movments Attack.
                                        {
                                            if (System.Math.Abs(Table[i, j]) == 1)
                                                //When Solder.
                                                HA += (Sign * System.Math.Abs(GetObjectValue(Table, ii, jj, Order) - SodierValue
                                                    ));

                                            else if (System.Math.Abs(Table[i, j]) == 2)
                                                //When Elephant
                                                HA += (Sign * System.Math.Abs(GetObjectValue(Table, ii, jj, Order) - ElefantValue
                                                    ));
                                            else if (System.Math.Abs(Table[i, j]) == 3)
                                                //When Hourse
                                                HA += (Sign * System.Math.Abs(GetObjectValue(Table, ii, jj, Order) - HourseValue
                                                    ));
                                            else if (System.Math.Abs(Table[i, j]) == 4)
                                                //When Bridges.
                                                HA += (Sign * System.Math.Abs(GetObjectValue(Table, ii, jj, Order) - BridgeValue
                                                    ));
                                            else if (System.Math.Abs(Table[i, j]) == 5)
                                                //When Minister.
                                                HA += (Sign * System.Math.Abs(GetObjectValue(Table, ii, jj, Order) - MinisterValue
                                                    ));
                                            else if (System.Math.Abs(Table[i, j]) == 6)
                                                //When King.
                                                HA += (Sign * System.Math.Abs(GetObjectValue(Table, ii, jj, Order) - KingValue
                                                    ));
                                            /*            //When there is supporter of attacked Objects take huristic negative else take muliply sign and muliply huristic.
                                                        bool Supported = false;
                                                        //For All Enemy Objects.
                                                        for (int g = 0; g < 8; g++)
                                                            for (int h = 0; h < 8; h++)
                                                            {
                                                                //Ignore of Currents.
                                                                if (Order == 1 && Table[g, h] >= 0)
                                                                    continue;
                                                                if (Order == -1 && Table[g, h] <= 0)
                                                                    continue;
                                                                //Initiate Objects.
                                                                Color A = Color.Gray;
                                                                if (Order == 1)
                                                                    A = Color.Brown;
                                                                else
                                                                    A = Color.Brown;
                                                                //When Enemy is not Supported.
                                                                if (Support(Table, g, h, ii, jj, A, Table[g, h]))
                                                                {

                                                                    //Assigene True.
                                                                    Supported = true;
                                                                    //Multyply To 10
                                                                    Sign *= 10;
                                                                    //When Soder.
                                                                    if (System.Math.Abs(Table[g, h]) == 1)
                                                                        HA -= (Sign * System.Math.Abs(GetObjectValue(Table,ii, jj,Order)-SodierValue 
                                                                            ));
                                                                    //When Elephant.
                                                                    else if (System.Math.Abs(Table[g, h]) == 2)
                                                                        HA -= (Sign * System.Math.Abs(ElefantValue + GetObjectValue(Table,ii, jj,Order)
                                                                            ));
                                                                    //When Hourse.
                                                                    else if (System.Math.Abs(Table[g, h]) == 3)
                                                                        HA -= (Sign * System.Math.Abs(HourseValue + GetObjectValue(Table,ii, jj,Order)
                                                                            ));
                                                                    //When Bridges.
                                                                    else if (System.Math.Abs(Table[g, h]) == 4)
                                                                        HA -= (Sign * System.Math.Abs(BridgeValue + GetObjectValue(Table,ii, jj,Order)
                                                                            ));
                                                                    //When Minsiter.
                                                                    else if (System.Math.Abs(Table[g, h]) == 5)
                                                                        HA -= (Sign * System.Math.Abs(MinisterValue + GetObjectValue(Table,ii, jj,Order)
                                                                            ));
                                                                    //When King.
                                                                    else if (System.Math.Abs(Table[g, h]) == 6)
                                                                        HA -= (Sign * System.Math.Abs(KingValue + GetObjectValue(Table,ii, jj,Order)
                                                                            ));

                                                                }
                                                            }
                                                        //When is Not Supported Multyply to 100.
                                                        if (!Supported)
                                                            HA *= 100;
                                                        else
                                                            //When is Supported Multyply to 100. 
                                                            HA *= -100;
                                                    }
                                                }
                                                //When there is not attacked.
                                                else
                                                {
                                                    {
                                                        //Supported is False.
                                                        bool Supported = false;
                                                        //For enemy objects.
                                                        for (int g = 0; g < 8; g++)
                                                            for (int h = 0; h < 8; h++)
                                                            {
                                                                //ignore of current.
                                                                if (Order == 1 && Table[g, h] >= 0)
                                                                    continue;
                                                                if (Order == -1 && Table[g, h] <= 0)
                                                                    continue;
                                                                //Detect Color.
                                                                Color aa;
                                                                if (Order == -1)
                                                                    aa = Color.Brown;
                                                                else
                                                                    aa = Color.Gray;
                                                                //When there is supporter of enemy object.
                                                                if (Support(Table, g, h, ii, jj, aa, Table[g, h]))
                                                                {
                                                                    //Assgine true.
                                                                    Supported = true;
                                                                    //Multyply 10.
                                                                    Sign *= 10;
                                                                    //When Solder.
                                                                    if (System.Math.Abs(Table[g, h]) == 1)
                                                                        HA -= (Sign * System.Math.Abs(GetObjectValue(Table,ii, jj,Order)-SodierValue 
                                                                            ));
                                                                    //When Elephant.
                                                                    else if (System.Math.Abs(Table[g, h]) == 2)
                                                                        HA -= (Sign * System.Math.Abs(ElefantValue + GetObjectValue(Table,ii, jj,Order)
                                                                            ));
                                                                    //When Hourse.
                                                                    else if (System.Math.Abs(Table[g, h]) == 3)
                                                                        HA -= (Sign * System.Math.Abs(HourseValue + GetObjectValue(Table,ii, jj,Order)
                                                                            ));
                                                                    //When Bridges.
                                                                    else if (System.Math.Abs(Table[g, h]) == 4)
                                                                        HA -= (Sign * System.Math.Abs(BridgeValue + GetObjectValue(Table,ii, jj,Order)
                                                                            ));
                                                                    //When Minster.
                                                                    else if (System.Math.Abs(Table[g, h]) == 5)
                                                                        HA -= (Sign * System.Math.Abs(MinisterValue + GetObjectValue(Table,ii, jj,Order)
                                                                            ));
                                                                    //When King.
                                                                    else if (System.Math.Abs(Table[g, h]) == 6)
                                                                        HA -= (Sign * System.Math.Abs(KingValue + GetObjectValue(Table,ii, jj,Order)
                                                                            ));

                                                                }
                                                            }
                                                        //When there is supported take positive multiply else take negative multiply.
                                                        if (!Supported)
                                                            //When is not supported multyply 100.
                                                            HA *= 100;
                                                        else
                                                            //When is supporetd multyply 00.
                                                            HA *= -100;
                                         */
                                        }
                                    }
                                }

                            }

                        }
                    }
                }
           
            Order = DummyOrder;
            ChessRules.CurrentOrder = DummyCurrentOrder;
            Order = DumOrder;
            //Initiate to Begin Call Orders.
            //Add Local Huristic to Global One.
            HuristicAttackValue += HA * SignOrderToPlate(Order);
            return HA;
        }
        //QC-OK.
        double HuristicReducsedAttack(int[,] Table, int Order, Color a, int i, int j)
        {
            //Initiate Objects.
            double HA = 0;
            int DumOrder = Order;
            int DummyOrder = Order;
            int DummyCurrentOrder = ChessRules.CurrentOrder;
            ///When AStarGreedy Huristic is Not Assigned.
            

                if (!AStarGreedyHuristicT)
                {
                    ///For Every Objects.
                    //int i = Row, j = Column;
                    ///For All Movments.
                    for (int ii = 0; ii < 8; ii++)
                    {
                        for (int jj = 0; jj < 8; jj++)
                        {
                            if (i == ii && j == jj)
                                continue;
                            int Sign = 1;
                            Order = DummyOrder;
                            ///When Attack is true. means [ii,jj] is in Attacked  [i,j].
                            ///What is Attack!
                            ///Ans:When [ii,jj] is Attacked [i,j] return true when enemy is located in [ii,jj].
                            if (Table[ii, jj] > 0 && DummyOrder == -1 && Table[i, j] < 0)
                            {
                                Order = 1;
                                Sign = -1 * AllDraw.SignReducedAttacked;
                                ChessRules.CurrentOrder = 1;
                                a = Color.Gray;
                            }
                            else if (Table[ii, jj] < 0 && DummyOrder == 1 && Table[i, j] > 0)
                            {
                                Order = -1;
                                Sign = -1 * AllDraw.SignReducedAttacked;
                                ChessRules.CurrentOrder = -1;
                                a = Color.Brown;
                            }
                            else
                                continue;
                            //For Attack Movments.
                            if (Attack(Table, ii, jj, i, j, a, Order))
                            {
                                //Finf Huristic Value Of Current and Add to Sumation.
                                {
                                    //When sodiers.
                                    if (System.Math.Abs(Table[i, j]) == 1)
                                        HA += (Sign * System.Math.Abs(SodierValue + GetObjectValue(Table, ii, jj, Order)
                                            ));
                                    //When Elephant.
                                    else if (System.Math.Abs(Table[i, j]) == 2)
                                        HA += (Sign * System.Math.Abs(ElefantValue + GetObjectValue(Table, ii, jj, Order)
                                            ));
                                    //When Hourse.
                                    else if (System.Math.Abs(Table[i, j]) == 3)
                                        HA += (Sign * System.Math.Abs(HourseValue + GetObjectValue(Table, ii, jj, Order)
                                            ));
                                    //When Bridges.
                                    else if (System.Math.Abs(Table[i, j]) == 4)
                                        HA += (Sign * System.Math.Abs(BridgeValue + GetObjectValue(Table, ii, jj, Order)
                                            ));
                                    //When Minister.
                                    else if (System.Math.Abs(Table[i, j]) == 5)
                                        HA += (Sign * System.Math.Abs(MinisterValue + GetObjectValue(Table, ii, jj, Order)
                                            ));
                                    //When King.
                                    else if (System.Math.Abs(Table[i, j]) == 6)
                                        HA += (Sign * System.Math.Abs(KingValue + GetObjectValue(Table, ii, jj, Order)
                                            ));

                                }
                            }
                        }
                    }
                }
                //For All Table Homes find Attack Huristic.
                else
                {
                    for (i = 0; i < 8; i++)
                    {
                        for (j = 0; j < 8; j++)
                        {
                            for (int ii = 0; ii < 8; ii++)
                            {
                                for (int jj = 0; jj < 8; jj++)
                                {
                                    if (i == ii && j == jj)
                                        continue;
                                    Order = DummyOrder;
                                    int Sign = 1;
                                    ///When Attack is true. means [ii,jj] is in Attacked  [i,j].
                                    ///What is Attack!
                                    ///Ans:When [ii,jj] is Attacked [i,j] return true when enemy is located in [ii,jj].
                                    if (Table[ii, jj] > 0 && DummyOrder == -1 && Table[i, j] < 0)
                                    {
                                        Order = 1;
                                        Sign = -1 * AllDraw.SignReducedAttacked;
                                        ChessRules.CurrentOrder = 1;
                                        a = Color.Gray;
                                    }
                                    else if (Table[ii, jj] < 0 && DummyOrder == 1 && Table[i, j] > 0)
                                    {
                                        Order = -1;
                                        Sign = -1 * AllDraw.SignReducedAttacked;
                                        ChessRules.CurrentOrder = -1;
                                        a = Color.Brown;
                                    }
                                    else continue;
                                    //For Attack Movments.
                                    if (Attack(Table, ii, jj, i, j, a, Order))
                                    {

                                        //Find Huristic Movments Attack.
                                        if (System.Math.Abs(Table[i, j]) == 1)
                                            //When Solder.
                                            HA += (Sign * System.Math.Abs(GetObjectValue(Table, ii, jj, Order) - SodierValue
                                                ));
                                        else if (System.Math.Abs(Table[i, j]) == 2)
                                            //when Elephnt.
                                            HA += (Sign * System.Math.Abs(GetObjectValue(Table, ii, jj, Order) - ElefantValue
                                                ));
                                        else if (System.Math.Abs(Table[i, j]) == 3)
                                            //when Hourse.
                                            HA += (Sign * System.Math.Abs(GetObjectValue(Table, ii, jj, Order) - HourseValue
                                                ));
                                        else if (System.Math.Abs(Table[i, j]) == 4)
                                            //when Bridges.
                                            HA += (Sign * System.Math.Abs(GetObjectValue(Table, ii, jj, Order) - BridgeValue
                                                ));
                                        else if (System.Math.Abs(Table[i, j]) == 5)
                                            //when Minbstre.
                                            HA += (Sign * System.Math.Abs(GetObjectValue(Table, ii, jj, Order) - MinisterValue
                                                ));
                                        else if (System.Math.Abs(Table[i, j]) == 6)
                                            //When King.
                                            HA += (Sign * System.Math.Abs(GetObjectValue(Table, ii, jj, Order) - KingValue
                                                ));
                                    }
                                }
                            }
                        }
                    }
                }
           

            //Initiate to Begin Call Orders.
            Order = DummyOrder;
            ChessRules.CurrentOrder = DummyCurrentOrder;
            Order = DumOrder;
            //Add Local Huristic to Global One.
            HuristicReducedAttackValue += HA * SignOrderToPlate(Order);
            return HA;
        }
        ///QC-OK.
        ///Value of Object method.
        int GetObjectValue(int[,] Tabl, int Row, int Column, int Order)
        {
            return ObjectValueCalculator(Tabl, Order, Row, Column);

        }
        ///Huristic of ObjectDanger.QC-OK
        double HuristicObjectDangour(int[,] Table, int Order, Color a)
        {
            double HA = 0;
            int DummyOrder = Order;
            int DummyCurrentOrder = ChessRules.CurrentOrder;
            ///When There is no AStarGreedyHuristicT
            
                if (!AStarGreedyHuristicT)
                {
                    ///For Every Object.
                    int i = Row, j = Column;
                    ///For All Object in Current Table.
                    for (int ii = 0; ii < 8; ii++)
                    {
                        for (int jj = 0; jj < 8; jj++)
                        {
                            if (i == ii && j == jj)
                                continue;
                            Order = DummyOrder;
                            int Sign = 1;
                            ///When ObjectDanger is true. means [ii,jj] is in ObjectDanger by [i,j].
                            ///What is ObjectDanger!
                            ///Ans:When [i,j] is Attacked [ii,jj] return true when enemy is located in [ii,jj].
                            if (Table[ii, jj] > 0 && DummyOrder == -1 && Table[i, j] < 0)
                            {
                                Order = 1;
                                Sign = -100 * AllDraw.SignObjectDangour;
                                ChessRules.CurrentOrder = 1;
                                a = Color.Gray;
                            }
                            else if (Table[ii, jj] < 0 && DummyOrder == 1 && Table[i, j] > 0)
                            {
                                Order = -1;
                                Sign = -100 * AllDraw.SignObjectDangour;
                                ChessRules.CurrentOrder = -1;
                                a = Color.Brown;
                            }
                            else
                                continue;
                            //For ObjectDanger Movments.
                            if (ObjectDanger(Table, ii, jj, i, j, a, Order))
                            {
                                //Find Local Sumation of ObjectDanger Huristic.                                
                                if (System.Math.Abs(Table[i, j]) == 1)
                                    //When Soldier.
                                    HA += Sign * System.Math.Abs(SodierValue);
                                else if (System.Math.Abs(Table[i, j]) == 2)
                                    //When Elephant.
                                    HA += Sign * System.Math.Abs(ElefantValue);
                                else if (System.Math.Abs(Table[i, j]) == 3)
                                    //when Hourse.
                                    HA += Sign * System.Math.Abs(HourseValue);
                                //Wehn Bridges.
                                else if (System.Math.Abs(Table[i, j]) == 4)
                                    HA += Sign * System.Math.Abs(BridgeValue);
                                //When Minister.
                                else if (System.Math.Abs(Table[i, j]) == 5)
                                    HA += Sign * System.Math.Abs(MinisterValue);
                                //When King.
                                else if (System.Math.Abs(Table[i, j]) == 6)
                                    HA += Sign * System.Math.Abs(KingValue);
                            }
                        }
                    }
                }
                //For All Table Home Find ObjectDanger Huristic
                else
                {
                    for (int i = 0; i < 8; i++)
                    {
                        for (int j = 0; j < 8; j++)
                        {
                            for (int ii = 0; ii < 8; ii++)
                            {
                                for (int jj = 0; jj < 8; jj++)
                                {
                                    if (i == ii && j == jj)
                                        continue;
                                    int Sign = 1;
                                    ///When ObjectDanger is true. means [ii,jj] is in ObjectDanger by [i,j].
                                    ///What is ObjectDanger!
                                    ///Ans:When [i,j] is Attacked [ii,jj] return true when enemy is located in [ii,jj].
                                    if (Table[ii, jj] > 0 && DummyOrder == -1 && Table[i, j] < 0)
                                    {
                                        Order = 1;
                                        Sign = -100 * AllDraw.SignObjectDangour;
                                        ChessRules.CurrentOrder = 1;
                                        a = Color.Gray;
                                    }
                                    else if (Table[ii, jj] < 0 && DummyOrder == 1 && Table[i, j] > 0)
                                    {
                                        Order = -1;
                                        Sign = -100 * AllDraw.SignObjectDangour;
                                        ChessRules.CurrentOrder = -1;
                                        a = Color.Brown;
                                    }
                                    else
                                        continue;

                                    //For Current Movments of legal Movments.
                                    if (ObjectDanger(Table, ii, jj, i, j, a, Order))
                                    {
                                        //Find ObjectDanger Huristic Locals.
                                        if (System.Math.Abs(Table[i, j]) == 1)
                                            //When Soldier.
                                            HA += Sign * System.Math.Abs(SodierValue);
                                        else if (System.Math.Abs(Table[i, jj]) == 2)
                                            //When Elephant.
                                            HA += Sign * System.Math.Abs(ElefantValue);
                                        else if (System.Math.Abs(Table[i, j]) == 3)
                                            //When Hourse.
                                            HA += Sign * System.Math.Abs(HourseValue);
                                        //When Bridges.
                                        else if (System.Math.Abs(Table[i, jj]) == 4)
                                            HA += Sign * System.Math.Abs(BridgeValue);
                                        //When Minster.
                                        else if (System.Math.Abs(Table[i, j]) == 5)
                                            HA += Sign * System.Math.Abs(MinisterValue);
                                        else if (System.Math.Abs(Table[i, j]) == 6)
                                            //When Minister.
                                            HA += Sign * System.Math.Abs(KingValue);
                                    }
                                }
                            }
                        }
                    }
                }
           
            //Initiate Orders to Call Begining.
            Order = DummyOrder;
            ChessRules.CurrentOrder = DummyCurrentOrder;
            //Assignments of Global Huristic with Local One.
            HuristicObjectDangourCheckMateValue += HA * SignOrderToPlate(Order);
            //return Local Huristic.
            return HA;
        }
        double HuristicHitting(int[,] Tab, int i, int j, int Order, Color a, bool Hit)
        {
            //Defualt is Gray Order.
            double HA = 0.0;
            int Sign = AllDraw.SignHitting;
            int DummyOrder = Order;
            int DummyCurrentOrder = ChessRules.CurrentOrder;

            
                //For All Objects.
                for (int iii = 0; iii < 8; iii++)
                    for (int jjj = 0; jjj < 8; jjj++)
                    {
                        Color colorAS = a;
                        //When Objects is Gray.
                        if (Tab[iii, jjj] > 0)
                        {
                            //Orders of Gray Objects.
                            Order = 1;
                            //When Orders of enemt take sign negative.
                            if (Order != FormRefrigtz.OrderPlate)
                                Sign *= -1;
                            ChessRules.CurrentOrder = 1;
                            a = Color.Gray;
                        }
                        else//When Objects is Brown.
                            if (Tab[iii, jjj] < 0)
                            {
                                //Orders of Brown Objects.
                                Order = -1;
                                //When Orders of enemt take sign negative.
                                if (Order != FormRefrigtz.OrderPlate)
                                    Sign *= -1;
                                ChessRules.CurrentOrder = -1;
                                a = Color.Brown;
                            }
                        //When there is Attacks to Current Objects.
                        if ((new ThinkingChess(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, iii, jjj)).Attack(Tab, iii, jjj, i, j, a, Order))
                        {
                            //Huristic positive.
                            if (System.Math.Abs(Tab[iii, jjj]) == 1)
                                //When Solder.
                                HA += (double)((GetObjectValue(Tab, i, j, Order) + SodierValue
                                    ) * Sign);
                            else
                                if (System.Math.Abs(Tab[iii, jjj]) == 2)
                                    //When Elephant.
                                    HA += (double)((GetObjectValue(Tab, i, j, Order) + ElefantValue
                                        ) * Sign);
                                else
                                    if (System.Math.Abs(Tab[iii, jjj]) == 3)
                                        //When Hourse.
                                        HA += (double)((GetObjectValue(Tab, i, j, Order) + HourseValue
                                            ) * Sign);
                                    else
                                        if (System.Math.Abs(Tab[iii, jjj]) == 4)
                                            //When Bridges.
                                            HA += (double)((GetObjectValue(Tab, i, j, Order) + BridgeValue
                                                ) * Sign);
                                        else
                                            if (System.Math.Abs(Tab[iii, jjj]) == 5)
                                                //When Minsister.
                                                HA += (double)((GetObjectValue(Tab, i, j, Order) + MinisterValue
                                                    ) * Sign);
                                            else
                                                if (System.Math.Abs(Tab[iii, jjj]) == 6)
                                                    //When King.
                                                    HA += (double)((GetObjectValue(Tab, i, j, Order) + KingValue
                                                        ) * Sign);
                        }


                        a = colorAS;

                        HuristicHittingValue += HA * SignOrderToPlate(Order);
                    }
           
            Order = DummyOrder;
            ChessRules.CurrentOrder = DummyCurrentOrder;

            return HA;
        }
        //Attacks Of Enemy that is not Supported.QC-OK
        bool InAttackedEnemyNotSupporetd(int[,] Table, int Order, Color a, int iii, int jjj, int i, int j)
        {
            //Initiate Global Variables.
            int O = iii, P = jjj;
            List<int> Objects = new System.Collections.Generic.List<int>();
            int[,] Tab = new int[8, 8];
            for (int ik = 0; ik < 8; ik++)
                for (int jk = 0; jk < 8; jk++)
                    Tab[ik, jk] = Table[ik, jk];
            EE = false;
            int Cdum = ChessRules.CurrentOrder;
            int COr = Order;
            InAttackedNotEnemySupported = false;
            EnemyNotSupported = false;
            ExistingOfEnemyHiiting = false;
            //For Enemy Order.
            for (int ii = 0; ii < 8; ii++)
            {
                for (int jj = 0; jj < 8; jj++)
                {
                    //InAttackedNotEnemySupported = false;
                    //Ignore of self Order.
                    if (Order == 1 && Tab[ii, jj] >= 0)
                        continue;
                    else
                        if (Order == -1 && Tab[ii, jj] <= 0)
                            continue;
                    //For Current Order.
                    //int iiii = iii, jjjj = jjj;
                    for (int iiii = 0; iiii < 8; iiii++)
                    {
                        for (int jjjj = 0; jjjj < 8; jjjj++)
                        {
                            if (Order == 1 && Tab[iiii, jjjj] <= 0)
                                continue;
                            else
                                if (Order == -1 && Tab[iiii, jjjj] >= 0)
                                    continue;

                            ChessRules.CurrentOrder = Cdum;
                            Order = COr;
                            //Ignore of Enemy Order.
                            EE = GetObjectValue(Tab, ii, jj, Order) > GetObjectValue(Tab, iiii, jjjj, Order);

                            //When Current Objet Attacked Enemy.
                            if (Attack(Tab, iiii, jjjj, ii, jj, a, Order))
                            {
                                InAttackedNotEnemySupported = true;
                                ExistingOfEnemyHiiting = false;

                                //For All Enemy Objects.
                                for (int iiiii = 0; iiiii < 8; iiiii++)
                                {
                                    for (int jjjjj = 0; jjjjj < 8; jjjjj++)
                                    {
                                        //Ignore of self Order.
                                        if (Order == 1 && Tab[iiiii, jjjjj] >= 0)
                                            continue;
                                        else
                                            if (Order == -1 && Tab[iiiii, jjjjj] <= 0)
                                                continue;
                                        //If Order is Gray.
                                        if (Order == 1)
                                        {
                                            //Set Enemy Order.
                                            ChessRules.CurrentOrder = -1;
                                            //When Enemy is Supporeted.
                                            if (Support(Tab, iiiii, jjjjj, ii, jj, Color.Brown, -1))
                                            {

                                                //Set false and return false.
                                                ExistingOfEnemyHiiting = true;
                                                Objects.Add(Tab[iii, jjj]);
                                                break;
                                            }
                                            else
                                            {

                                                //Set True.
                                                ExistingOfEnemyHiiting = false;
                                                continue;
                                            }

                                        }
                                        //Brown Order.
                                        else
                                        {
                                            //For Enemy Order.
                                            ChessRules.CurrentOrder = 1;
                                            //When Enemy is Supported.
                                            if (Support(Tab, iiiii, jjjjj, ii, jj, Color.Gray, 1))
                                            {
                                                //Set false and return false.
                                                ExistingOfEnemyHiiting = true;
                                                ChessRules.CurrentOrder = Cdum;
                                                Order = COr;
                                                break;
                                            }
                                            else
                                            {
                                                //Set true.
                                                ExistingOfEnemyHiiting = false;
                                                continue;
                                            }
                                        }
                                    }
                                }
                            }
                            if (!ExistingOfEnemyHiiting)
                                break;

                        }
                        if (!ExistingOfEnemyHiiting)
                            break;
                    }
                    if (!ExistingOfEnemyHiiting)
                        break;
                }
                if (!ExistingOfEnemyHiiting)
                    break;
            }
            if (Objects.Count == 1 && MaxObjecvts(Objects, Tab[O, P]))
            {
                //When false
                if (!ExistingOfEnemyHiiting)
                {
                    //Set true.
                    EnemyNotSupported = true;
                }
                else
                {
                    //Set false.
                    EnemyNotSupported = false;
                }
            }
            else
            {
                InAttackedNotEnemySupported = false;
                EnemyNotSupported = false;

            }


            return true;
        }
        //Supported of Self that is Not Attacks.QC-OK
        bool InAttackedُSelfNotSupporetd(int[,] Table, int Order, Color a, int ij, int ji)
        {
            //Initiate Variables.
            List<int> Objects = new System.Collections.Generic.List<int>();
            int[,] Tab = new int[8, 8];
            for (int ik = 0; ik < 8; ik++)
                for (int jk = 0; jk < 8; jk++)
                    Tab[ik, jk] = Table[ik, jk];
            InAttackedNotSelfSupported = false;
            SelfSupported = false;
            bool Supported = false;
            //Fow Current Objects.
            int Dum = ChessRules.CurrentOrder;
            //For Objects.
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    //Ignore of Current Objects.
                    if (Tab[i, j] <= 0 && Order == 1)
                        continue;
                    if (Tab[i, j] >= 0 && Order == -1)
                        continue;
                    //For Enemy.
                    for (int iii = 0; iii < 8; iii++)
                    {
                        for (int jjj = 0; jjj < 8; jjj++)
                        {
                            for (int ik = 0; ik < 8; ik++)
                                for (int jk = 0; jk < 8; jk++)
                                    Tab[ik, jk] = Table[ik, jk];
                            //Ignore of Current Objects.
                            if (Tab[iii, jjj] >= 0 && Order == 1)
                                continue;
                            if (Tab[iii, jjj] <= 0 && Order == -1)
                                continue;
                            bool E = GetObjectValue(Tab, i, j, Order) >= GetObjectValue(Tab, iii, jjj, Order);
                            //When Objects of Current is greater than Objects of Enemy or another.
                            //if (E)
                            {

                                //Gray Order.
                                if (Order == 1)
                                {
                                    //Set Enemy Order.
                                    //ChessRules.CurrentOrder = -1;
                                    //When Enemy Attacked Cuurent Object.
                                    int COr = Order;
                                    //Order *= -1;
                                    //When there is Attacks.
                                    if (Attack(Tab, iii, jjj, i, j, Color.Brown, Order * -1))
                                    {
                                        Order = COr;
                                        //Setting true.
                                        InAttackedNotSelfSupported = true;
                                        //When Objects of Current is greater than Objects of Enemy or another.
                                        /*if (E)
                                        {
                                            //Take Supported false and exit.
                                            Supported = false;
                                            InAttackedNotSelfSupported = true;
                                            goto EndAttacked;
                                        }
                                         */
                                        InAttackedNotSelfSupported = true;
                                        //For Current Order and Setting false for Supporation.
                                        ChessRules.CurrentOrder = Dum;
                                        Supported = false;
                                        //For Current Order.
                                        for (int ii = 0; ii < 8; ii++)
                                        {
                                            for (int jj = 0; jj < 8; jj++)
                                            {
                                                //Ignore of Enemy.
                                                if (Tab[ii, jj] <= 0)
                                                    continue;
                                                //Setting Current Order.
                                                ChessRules.CurrentOrder = Order;
                                                //When Current Object Supported.
                                                if (Support(Tab, ii, jj, i, j, a, Order))
                                                {
                                                    //Setting Sepported true and break.
                                                    Supported = true;
                                                    Objects.Add(Table[i, j]);
                                                }
                                            }
                                            if (InAttackedNotSelfSupported)
                                                break;
                                        }
                                    }
                                    Order = COr;

                                }
                                //For Brown Order.
                                else
                                {
                                    //Setting Enemy Order.
                                    ChessRules.CurrentOrder = 1;
                                    //Wen Enemy Atta
                                    int COr = Order;
                                    // Order *= -1;
                                    //When there is Attacks of Enemy.
                                    if (Attack(Tab, iii, jjj, i, j, Color.Gray, Order * -1))
                                    {
                                        Order = COr;
                                        //Setting true.
                                        InAttackedNotSelfSupported = true;
                                        //When Objects of Current is greater than Objects of Enemy or another.
                                        /*if (E)
                                        {
                                            //Take supported false and exit.
                                            Supported = false;
                                            InAttackedNotSelfSupported = true;
                                            goto EndAttacked;
                                        }
                                         */


                                        //Setting Current Order and setting Supported false.
                                        ChessRules.CurrentOrder = Dum;
                                        Supported = false;
                                        //For Current Objects.
                                        for (int ii = 0; ii < 8; ii++)
                                        {
                                            for (int jj = 0; jj < 8; jj++)
                                            {
                                                //Ignore of Enemy Objects.
                                                if (Tab[ii, jj] >= 0)
                                                    continue;
                                                //For Current Objects.
                                                ChessRules.CurrentOrder = Order;
                                                //When Cuurent Objects has Supporeted.
                                                if (Support(Tab, ii, jj, i, j, a, Order))
                                                {
                                                    //Setting Supporeted and break.
                                                    Supported = true;
                                                    Objects.Add(Table[i, j]);
                                                }

                                            }

                                        }
                                        if (InAttackedNotSelfSupported)
                                            break;

                                    }
                                    Order = COr;
                                }

                            }
                        }
                    }
                    if (InAttackedNotSelfSupported && (!Supported))
                        Objects.Add(Table[i, j]);
                    if (InAttackedNotSelfSupported)
                        break;
                }
                if (InAttackedNotSelfSupported)
                    break;
            }
            ChessRules.CurrentOrder = Dum;
            //When Current condition return true.
            if (Objects.Count == 1 || (MaxObjecvts(Objects, Table[ij, ji])) || BeforeAttacker)
            {
                if (Supported)
                {
                    SelfSupported = true;
                    return true;
                }
                else
                    //return false.
                    SelfSupported = false;
            }
            else
            {
                InAttackedNotSelfSupported = false;
                SelfSupported = false;

            }

            return false;
        }

        bool MaxObjecvts(List<int> Obj, int Max)
        {
            bool MaxO = true;
            if (Obj.Count > 0)
            {
                if (Max == 0)
                    return !MaxO;
                if (Max > 0)
                    if (Obj[0] < 0)
                        return !MaxO;
                if (Max < 0)
                    if (Obj[0] > 0)
                        return !MaxO;
                for (int i = 0; i < Obj.Count; i++)
                {
                    if (System.Math.Abs(Obj[i]) > System.Math.Abs(Max))
                    {
                        MaxO = true;
                        return MaxO;
                    }
                    else
                        MaxO = false;
                }
            }
            return MaxO;
        }
        bool InAttackedُSelfNotSupporetd(int[,] Table, int Order, Color a, ref int ij, ref int ji, int h, int m)
        {
            //Initiate Variables.
            int[,] Tab = new int[8, 8];
            for (int ik = 0; ik < 8; ik++)
                for (int jk = 0; jk < 8; jk++)
                    Tab[ik, jk] = Table[ik, jk];
            InAttackedNotSelfSupported = false;
            SelfSupported = false;
            bool Supported = false;
            //Fow Current Objects.
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    if (i == h && j == m)
                        continue;
                    //Take false.
                    InAttackedNotSelfSupported = false;
                    //Ignore of Enemy Objects.
                    if (Tab[i, j] <= 0 && Order == 1)
                        continue;
                    if (Tab[i, j] >= 0 && Order == -1)
                        continue;
                    int Dum = ChessRules.CurrentOrder;
                    //For Enemy.
                    for (int iii = 0; iii < 8; iii++)
                    {
                        for (int jjj = 0; jjj < 8; jjj++)
                        {
                            //Ignore of Current Objects.
                            if (Tab[iii, jjj] >= 0 && Order == 1)
                                continue;
                            if (Tab[iii, jjj] <= 0 && Order == -1)
                                continue;
                            bool E = GetObjectValue(Tab, i, j, Order) >= GetObjectValue(Tab, iii, jjj, Order);
                            //When Objects of Current is greater than Objects of Enemy or another.
                            if (E)
                            {

                                //Gray Order.
                                if (Order == 1)
                                {
                                    //Set Enemy Order.
                                    ChessRules.CurrentOrder = -1;
                                    //When Enemy Attacked Cuurent Object.
                                    int COr = Order;
                                    Order *= -1;
                                    //When there is Attacks.
                                    if (Attack(Tab, iii, jjj, i, j, Color.Brown, Order))
                                    {
                                        Order = COr;
                                        //Setting true.
                                        InAttackedNotSelfSupported = true;
                                        ij = i;
                                        ji = j;


                                        //For Current Order and Setting false for Supporation.
                                        ChessRules.CurrentOrder = Dum;
                                        Supported = false;
                                        //For Current Order.
                                        for (int ii = 0; ii < 8; ii++)
                                        {
                                            for (int jj = 0; jj < 8; jj++)
                                            {
                                                //Ignore of Enemy.
                                                if (Tab[ii, jj] <= 0)
                                                    continue;
                                                //Setting Current Order.
                                                ChessRules.CurrentOrder = Order;
                                                //When Current Object Supported.
                                                if (Support(Tab, ii, jj, i, j, a, Order))
                                                {
                                                    //Setting Sepported true and break.
                                                    Supported = true;
                                                }

                                            }
                                            if (InAttackedNotSelfSupported && (!Supported))
                                                break;
                                        }
                                    }
                                    Order = COr;

                                }
                                //For Brown Order.
                                else
                                {
                                    //Setting Enemy Order.
                                    ChessRules.CurrentOrder = 1;
                                    //Wen Enemy Atta
                                    int COr = Order;
                                    Order *= -1;
                                    //When there is Attacks of Enemy.
                                    if (Attack(Tab, iii, jjj, i, j, Color.Gray, Order))
                                    {
                                        Order = COr;
                                        //Setting true.
                                        InAttackedNotSelfSupported = true;
                                        //When Objects of Current is greater than Objects of Enemy or another.
                                        ij = i;
                                        ji = j;

                                        //Setting Current Order and setting Supported false.
                                        ChessRules.CurrentOrder = Dum;
                                        Supported = false;
                                        //For Current Objects.
                                        for (int ii = 0; ii < 8; ii++)
                                        {
                                            for (int jj = 0; jj < 8; jj++)
                                            {
                                                //Ignore of Enemy Objects.
                                                if (Tab[ii, jj] >= 0)
                                                    continue;
                                                //For Current Objects.
                                                ChessRules.CurrentOrder = Order;
                                                //When Cuurent Objects has Supporeted.
                                                if (Support(Tab, ii, jj, i, j, a, Order))
                                                {
                                                    //Setting Supporeted and break.
                                                    Supported = true;
                                                }

                                            }

                                        }
                                        if (InAttackedNotSelfSupported && (!Supported))
                                            break;

                                    }
                                    Order = COr;
                                }

                            }
                        EndAttacked:
                            if (InAttackedNotSelfSupported && (!Supported))
                                break;
                        }
                        if (InAttackedNotSelfSupported && (!Supported))
                            break;
                    }
                    ChessRules.CurrentOrder = Dum;
                    if (InAttackedNotSelfSupported && (!Supported))
                        break;

                }
                if (InAttackedNotSelfSupported && (!Supported))
                    break;

            }
            //When Current condition return true.
            if (Supported)
            {
                SelfSupported = true;
                return false;
            }
            else
                //return false.
                SelfSupported = false;
            return true;
        }

        ///Huristic of Suportation.
        double HuristicSelfSupported(int[,] Tab, int Order, Color a, int i, int j)
        {
            //Initiate Local Vrariables.
            double HA = 0;
            int DumOrder = Order;
            int DummyOrder = Order;
            int DummyCurrentOrder = ChessRules.CurrentOrder;
            //If There is Not AStarGreedy Huristic Boolean Value.
            
                if (!AStarGreedyHuristicT)
                {
                    //For Current Object Lcation.
                    //int i = Row, j = Column;
                    //In All Homes of Table.
                    for (int ii = 0; ii < 8; ii++)
                    {
                        for (int jj = 0; jj < 8; jj++)
                        {
                            //Ignore Current Unnessery Home.
                            if (i == ii && j == jj)
                                continue;
                            //Default Is Gray One.
                            int Sign = 1;
                            Order = DummyOrder;
                            ///When Supporte is true. means [ii,jj] Supportes [i,j].
                            ///What is Supporte!
                            ///Ans:When [i,j] is Supporte [ii,jj] return true when Self is located in [ii,jj].
                            if (Tab[ii, jj] < 0 && DummyOrder == -1 && Tab[i, j] < 0)
                            {
                                Order = -1;
                                Sign = 1 * AllDraw.SignSupport;
                                ChessRules.CurrentOrder = -1;
                                a = Color.Brown;
                            }
                            else if (Tab[ii, jj] > 0 && DummyOrder == 1 && Tab[i, j] > 0)
                            {
                                Order = 1;
                                Sign = 1 * AllDraw.SignSupport;
                                ChessRules.CurrentOrder = 1;
                                a = Color.Gray;
                            }
                            else
                                continue;
                            //For Support Movments.
                            if (Support(Tab, ii, jj, i, j, a, Order))
                            {
                                //Calculate Local Support Huristic.
                                {

                                    //When Solder.
                                    if (System.Math.Abs(Tab[ii, jj]) == 1)
                                        HA += (Sign * System.Math.Abs(12 - System.Math.Abs(SodierValue - GetObjectValue(Tab, i, j, Order)
                                            )));
                                    //Wehn Elephant.
                                    else if (System.Math.Abs(Tab[ii, jj]) == 2)
                                        HA += (Sign * System.Math.Abs(12 - System.Math.Abs(ElefantValue - GetObjectValue(Tab, i, j, Order)
                                            )));
                                    //When Hourse.
                                    else if (System.Math.Abs(Tab[ii, jj]) == 3)
                                        HA += (Sign * System.Math.Abs(12 - System.Math.Abs(HourseValue - GetObjectValue(Tab, i, j, Order)
                                            )));
                                    //When Bridges.
                                    else if (System.Math.Abs(Tab[ii, jj]) == 4)
                                        HA += (Sign * System.Math.Abs(12 - System.Math.Abs(BridgeValue - GetObjectValue(Tab, i, j, Order)
                                            )));
                                    //When Minster.
                                    else if (System.Math.Abs(Tab[ii, jj]) == 5)
                                        HA += (Sign * System.Math.Abs(12 - System.Math.Abs(MinisterValue - GetObjectValue(Tab, i, j, Order)
                                            )));
                                    //When King.
                                    else if (System.Math.Abs(Tab[ii, jj]) == 6)
                                        HA += (Sign * System.Math.Abs(12 - System.Math.Abs(KingValue - GetObjectValue(Tab, i, j, Order)
                                            )));
                                }
                            }
                        }
                    }
                }
                //For All Homes Table.
                else
                {
                    for (i = 0; i < 8; i++)
                    {
                        for (j = 0; j < 8; j++)
                        {
                            for (int ii = 0; ii < 8; ii++)
                            {
                                for (int jj = 0; jj < 8; jj++)
                                {
                                    //Ignore Current Home.
                                    if (i == ii && j == jj)
                                        continue;
                                    //Initiate Local Variables.
                                    int Sign = 1;
                                    Order = DummyOrder;
                                    ///When Supporte is true. means [ii,jj] is in SelfSupported.by [i,j].
                                    ///What is Supporte!
                                    ///Ans:When [i,j] is Supporte [ii,jj] return true when Self is located in [ii,jj].
                                    if (Tab[ii, jj] < 0 && DummyOrder == -1 && Tab[i, j] < 0)
                                    {
                                        Order = -1;
                                        Sign = 1 * AllDraw.SignSupport;
                                        ChessRules.CurrentOrder = -1;
                                        a = Color.Brown;
                                    }
                                    else if (Tab[ii, jj] > 0 && DummyOrder == 1 && Tab[i, j] > 0)
                                    {
                                        Order = 1;
                                        Sign = 1 * AllDraw.SignSupport;
                                        ChessRules.CurrentOrder = 1;
                                        a = Color.Gray;
                                    }
                                    else
                                        continue;
                                    //For Support Movments.
                                    if (Support(Tab, ii, jj, i, j, a, Order))
                                    {
                                        //When Soldeir.
                                        if (System.Math.Abs(Tab[ii, jj]) == 1)
                                            HA += (Sign * System.Math.Abs(12 - System.Math.Abs(SodierValue - GetObjectValue(Tab, i, j, Order)
                                                )));
                                        //When Elephant.
                                        else if (System.Math.Abs(Tab[ii, jj]) == 2)
                                            HA += (Sign * System.Math.Abs(12 - System.Math.Abs(ElefantValue - GetObjectValue(Tab, i, j, Order)
                                                )));
                                        //When Hourse.
                                        else if (System.Math.Abs(Tab[ii, jj]) == 3)
                                            HA += (Sign * System.Math.Abs(12 - System.Math.Abs(HourseValue - GetObjectValue(Tab, i, j, Order)
                                                )));
                                        //When Bridges.
                                        else if (System.Math.Abs(Tab[ii, jj]) == 4)
                                            HA += (Sign * System.Math.Abs(12 - System.Math.Abs(BridgeValue - GetObjectValue(Tab, i, j, Order)
                                                )));
                                        //When Minsister.
                                        else if (System.Math.Abs(Tab[ii, jj]) == 5)
                                            HA += (Sign * System.Math.Abs(12 - System.Math.Abs(MinisterValue - GetObjectValue(Tab, i, j, Order)
                                                )));
                                        //When King.
                                        else if (System.Math.Abs(Tab[ii, jj]) == 6)
                                            HA += (Sign * System.Math.Abs(12 - System.Math.Abs(KingValue - GetObjectValue(Tab, i, j, Order)
                                                )));
                                    }
                                }
                            }
                        }
                    }
                }
           

            //Reassignments of Global Orders with Local Begining One.
            Order = DummyOrder;
            ChessRules.CurrentOrder = DummyCurrentOrder;
            Order = DumOrder;
            HuristicSelfSupportedValue += HA * SignOrderToPlate(Order);
            return HA;
        }
        ///Identification of Equality
        public static bool TableEqual(int[,] Tab1, int[,] Tab2)
        {
            
                //For All Home
                for (int i = 0; i < 8; i++)
                    for (int j = 0; j < 8; j++)
                    {
                        //When there is different values in same location of tow Table return non equality.
                        if (Tab1[i, j] != Tab2[i, j])
                            return false;
                    }
                //Else return equlity.
                return true;
           
        }
        //If tow int Objects is equal.
        public static bool TableEqual(int Tab1, int Tab2)
        {
            
                //When there is different values in same location of tow Table return non equality.
                if (Tab1 != Tab2)
                    return false;
                //Else return equlity.
                return true;
           
        }
        //Deterimination of Existance of Table in List.QC-OK.
        static public bool ExistTableInList(int[,] Tab, List<int[,]> List, int Index)
        {
            //Initiate Local Variables.
            bool Exist = false;
            //For All Tables of Table List.
            for (int i = Index; i < List.Count; i++)
            {
                //Strore Equality Value.
                bool Eq = TableEqual(Tab, List[i]);
                //When is Equality is Occurred.
                if (Eq)
                {
                    //Store Equality Local Value in a Global static value.
                    AllDraw.LoopHuristicIndex = i;
                    return Eq;
                }
                Exist |= Eq;
            }
            //return Equality Local value of all lists.
            return Exist;
        }
        ///Move Determination.QC-OK
        public bool Movable(int[,] Tab, int i, int j, int ii, int jj, Color a, int Order)
        {
            int[,] Table = new int[8, 8];
            for (int p = 0; p < 8; p++)
                for (int k = 0; k < 8; k++)
                    Table[p, k] = Tab[p, k];
            //Initiate Local Variables.
            int Store = Table[ii, jj];
            ChessRules A = new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, Table[i, j], Table, Order, i, j);
            ///Table[ii, jj] = 0;
            //Menen Parameter is Moveble to Second Parameters Location returm Movable.
            if (A.Rules(i, j, ii, jj, a, Order))
            {
                //Initiate Movments.
                Table[ii, jj] = Table[i, j];
                Table[i, j] = 0;
                //Default Order Assignments.
                int Ord = 1;
                //Brown Order Consideration.
                if (Table[ii, jj] < 0)
                    Ord = -1;
                //Store of Local Order Assignments in Global Assignments.
                int DummyOrder = Order;
                int DummyCurrentOrder = ChessRules.CurrentOrder;
                //Consider Global Check Variables.
                ChessRules AA = new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, Table[ii, jj], Table, Ord, ii, jj);
                AA.Check(Table, Ord);
                //Reaasignment of Premitive Variables.
                Order = DummyOrder;
                ChessRules.CurrentOrder = DummyCurrentOrder;
                //Reassignments of Table Content and Consider CheckMate Specific Order.
                Table[i, j] = Table[ii, jj];
                //When Gray.
                if (Table[i, j] > 0)
                {
                    //And CheckedMated is Occured for gray. return false.
                    Table[ii, jj] = Store;
                    if (AA.CheckMateGray)
                        return false;


                    return true;
                }

                //When Brown.
                if (Table[i, j] < 0)
                {
                    Table[ii, jj] = Store;
                    //When CheckedMated occured for Brown return false.
                    if (AA.CheckMateBrown)
                        return false;
                    return true;
                }


            }

            Table[ii, jj] = Store;
            return false;
        }
        //QC-OK
        //When Oredrs of OrderPalte and Calculation Order is not equal return negative one and else return one.
        double SignOrderToPlate(int Order)
        {
            double Sign = 1.0;
            //When Current Order Sign Positive.
            if (Order == FormRefrigtz.OrderPlate)
                Sign = 1.0;
            else
                //When Order is Opposite Sign Negative.
                if (Order != FormRefrigtz.OrderPlate)
                    Sign = -1.0;
            return Sign;

        }
        //Remove Penalties of Unnesserily Nodes.
        public bool RemovePenalty(int[,] Tab, int Order, int i, int j)
        {
            bool Remove = false;
            //Create Objects.
            ChessRules AA = new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, Tab[i, j], Tab, Order, i, j);
            //When is Check.
            if (AA.Check(Tab, Order))
            {
                //When there is Current Checked or Objects Danger return false.
                if (Order == 1 && (AA.CheckGray || AA.CheckGrayObjectDangour))
                    return Remove;
                if (Order == -1 && (AA.CheckBrown || AA.CheckBrownObjectDangour))
                    return Remove;
            }



            //For Enemy.
            for (int ii = 0; ii < 8; ii++)
                for (int jj = 0; jj < 8; jj++)
                {
                    if (Order == 1 && Tab[ii, jj] >= 0)
                        continue;
                    if (Order == -1 && Tab[ii, jj] <= 0)
                        continue;
                    //Clone a Copy.
                    int[,] Table = new int[8, 8];
                    //Clone a Table.
                    for (int iii = 0; iii < 8; iii++)
                        for (int jjj = 0; jjj < 8; jjj++)
                            Table[iii, jjj] = Tab[iii, jjj];
                    ChessRules A = new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, Table[ii, jj], Table, Order * -1, ii, jj);
                    Color a = Color.Gray;
                    if (Order * -1 == -1)
                        a = Color.Brown;
                    //When there is movment to current OPbject.
                    if (A.Rules(ii, jj, i, j, a, Table[ii, jj]))
                    {
                        //Number of Attacks and take move.
                        int Count = AttackerCount(Table, Order * -1, a, ii, jj);
                        Table[i, j] = Table[ii, jj];
                        Table[ii, jj] = 0;
                        //When there is Object Danger.
                        //Clone a Copy.
                        for (int iii = 0; iii < 8; iii++)
                            for (int jjj = 0; jjj < 8; jjj++)
                                Table[iii, jjj] = Tab[iii, jjj];
                        //Create New Chess Rule Object.
                        A = new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, Table[ii, jj], Table, Order, ii, jj);
                        //Detect Color.
                        a = Color.Gray;
                        if (Order == -1)
                            a = Color.Brown;
                        //When Current Movments Attacks Enemy.
                        if (Attack(Table, i, j, ii, jj, a, Order))
                        {
                            //For Current Home.
                            for (int iii = 0; iii < 8; iii++)
                                for (int jjj = 0; jjj < 8; jjj++)
                                {
                                    //Ignore of Enemy.
                                    if (Order == 1 && Tab[iii, jjj] <= 0)
                                        continue;
                                    if (Order == -1 && Tab[iii, jjj] >= 0)
                                        continue;
                                    //Whn Value Of Current is Less That Enemy.
                                    if (GetObjectValue(Table, i, j, Order) < GetObjectValue(Table, ii, jj, Order))
                                    {
                                        //Take Move.
                                        Table[ii, jj] = Table[i, j];
                                        Table[i, j] = 0;
                                        a = Color.Gray;
                                        if (Order * -1 == -1)
                                            a = Color.Brown;
                                        //When Enemy Attacks Current Moved.
                                        if (Attack(Table, iii, jjj, ii, jj, a, Order * -1))
                                        {
                                            //For Current Order.
                                            for (int iiii = 0; iiii < 8; iiii++)
                                                for (int jjjj = 0; jjjj < 8; jjjj++)
                                                {
                                                    //Ignore of Enemy.
                                                    if (Order == 1 && Tab[iiii, jjjj] <= 0)
                                                        continue;
                                                    if (Order == -1 && Tab[iiii, jjjj] >= 0)
                                                        continue;
                                                    a = Color.Gray;
                                                    if (Order == -1)
                                                        a = Color.Brown;
                                                    //When Self Supported Current
                                                    if (Support(Table, iiii, jjjj, i, j, a, Order))
                                                    {
                                                        //If V alue of Enemy is Greater Than Current and Value of Enemy is Greater than Supporter.
                                                        if (GetObjectValue(Table, iii, jjj, Order) < GetObjectValue(Table, ii, jj, Order) && GetObjectValue(Table, iii, jjj, Order) > GetObjectValue(Table, iiii, jjjj, Order))
                                                        {
                                                            //When Objects is Dangoure.
                                                            if (A.ObjectDangourKingMove(Order, Table, false) && Count > 0)
                                                            {
                                                                //When is Not Gray Objects Dangoure.
                                                                if (Order == 1 && (!A.CheckGrayObjectDangour))
                                                                {
                                                                    Remove = true;
                                                                    return Remove;
                                                                }
                                                                //When is not Brown Object Dangoure.
                                                                if (Order == -1 && (!A.CheckBrownObjectDangour))
                                                                {
                                                                    Remove = true;
                                                                    return Remove;
                                                                }
                                                            }
                                                        }
                                                        else
                                                            return Remove;
                                                    }
                                                    else
                                                        return Remove;
                                                }
                                        }
                                    }
                                    else
                                        return Remove;
                                }
                        }
                    }
                }
            return Remove;
        }
        //Dangouring of current movment fo current Order.QC-OK
        bool IsCurrentStateIsDangreousForCurrentOrder(int[,] Tabl, int Order, Color a, int ii, int jj)
        {
            //Initiate Object.
            ChessRules A = new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, 1, Tabl, 1, Row, Column);
            //Gray Order.
            if (Order == 1)
            {
                //Find location of Gray King.
                int RowG = -1, ColumnG = -1;
                A.FindGrayKing(Tabl, ref RowG, ref ColumnG);
                //When found.
                if (RowG != -1 && ColumnG != -1)
                {
                    //For Brown
                    for (int i = 0; i < 8; i++)
                        for (int j = 0; j < 8; j++)
                        {
                            if (Tabl[i, j] >= 0)
                                continue;

                            if (i != ii && j != jj)
                            {
                                //Create new Objects of Table
                                int[,] TablCon = new int[8, 8];
                                for (int iii = 0; iii < 8; iii++)
                                    for (int jjj = 0; jjj < 8; jjj++)
                                        TablCon[iii, jjj] = Tabl[iii, jjj];
                                //For Enemy Order.
                                if (TablCon[i, j] < 0)
                                {
                                    //For Gray and Empty Objects.
                                    if (TablCon[ii, jj] >= 0)
                                    {
                                        //Setting Enemy Order.
                                        int DummyOrder = Order;
                                        int DummyCurrentOrder = ChessRules.CurrentOrder;
                                        A = new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, TablCon[i, j], TablCon, -1, i, j);
                                        //When Enemy is Attacked Gray Objects.
                                        if (A.Rules(i, j, ii, jj, Color.Brown, TablCon[i, j]))
                                        {
                                            //Take Movments.
                                            TablCon[ii, jj] = TablCon[i, j];
                                            TablCon[i, j] = 0;
                                            //Settting Current Order.
                                            ChessRules.CurrentOrder = 1;
                                            //Settting Object.
                                            A = new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, TablCon[ii, jj], TablCon, 1, ii, jj);
                                            //When Occured Check.
                                            if (A.Check(TablCon, 1))
                                            {
                                                //When Gray is Check.
                                                if (A.CheckGray)
                                                {
                                                    //For Enemy Order Objects.
                                                    for (int iiii = 0; iiii < 8; iiii++)
                                                        for (int jjjj = 0; jjjj < 8; jjjj++)
                                                        {
                                                            //When is not Conflict.
                                                            if (iiii != i && jjjj != j && iiii != ii && jjjj != jj)
                                                            {
                                                                //Setting Enemy.
                                                                ChessRules.CurrentOrder = -1;
                                                                //When Enemy is Supported 
                                                                if (Support(TablCon, iiii, jjjj, i, j, Color.Brown, -1))
                                                                {
                                                                    //restore and return true.
                                                                    Order = DummyOrder;
                                                                    ChessRules.CurrentOrder = DummyCurrentOrder;
                                                                    return true;
                                                                }
                                                            }
                                                        }
                                                }
                                                Order = DummyOrder;
                                                ChessRules.CurrentOrder = DummyCurrentOrder;

                                            }
                                        }

                                    }
                                }
                            }
                        }
                }


            }
            //For Brown Order.
            else if (Order == -1)
            {
                //Found of Brown King.
                int RowB = -1, ColumnB = -1;
                A.FindBrownKing(Tabl, ref RowB, ref ColumnB);
                //When found.
                if (RowB != -1 && ColumnB != -1)
                {
                    //For Gray.
                    for (int i = 0; i < 8; i++)
                        for (int j = 0; j < 8; j++)
                        {
                            if (Tabl[i, j] <= 0)
                                continue;

                            if (i != ii && j != jj)
                            {
                                //Create new Objects of Table
                                int[,] TablCon = new int[8, 8];
                                for (int iii = 0; iii < 8; iii++)
                                    for (int jjj = 0; jjj < 8; jjj++)
                                        TablCon[iii, jjj] = Tabl[iii, jjj];
                                //For Enemy Objects.
                                if (TablCon[i, j] > 0)
                                {
                                    //For Self Objects and Empty.
                                    if (TablCon[ii, jj] <= 0)
                                    {
                                        //Store and Enemy Order.
                                        int DummyOrder = Order;
                                        int DummyCurrentOrder = ChessRules.CurrentOrder;
                                        A = new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, TablCon[i, j], TablCon, 1, i, j);
                                        ChessRules.CurrentOrder = 1;
                                        //When Enemy Attacked Self Objects.
                                        if (A.Rules(i, j, ii, jj, Color.Gray, TablCon[i, j]))
                                        {
                                            //Take movemnts.
                                            TablCon[ii, jj] = TablCon[i, j];
                                            TablCon[i, j] = 0;
                                            //Setting current Order.
                                            ChessRules.CurrentOrder = -1;
                                            A = new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, TablCon[ii, jj], TablCon, -1, ii, jj);
                                            //When Check Occured.
                                            if (A.Check(TablCon, -1))
                                            {
                                                //When Current is Check.
                                                if (A.CheckBrown)
                                                {
                                                    //For Enemy Objecvts.
                                                    for (int iiii = 0; iiii < 8; iiii++)
                                                        for (int jjjj = 0; jjjj < 8; jjjj++)
                                                        {
                                                            //Ignore of Conflit.
                                                            if (iiii != i && jjjj != j && iiii != ii && jjjj != jj)
                                                            {
                                                                //Setting Enemy Order
                                                                ChessRules.CurrentOrder = 1;
                                                                //When Enemy is Supported.
                                                                if (Support(TablCon, iiii, jjjj, i, j, Color.Gray, 1))
                                                                {
                                                                    //restore and return true.
                                                                    Order = DummyOrder;
                                                                    ChessRules.CurrentOrder = DummyCurrentOrder;
                                                                    return true;
                                                                }
                                                            }
                                                        }
                                                }
                                                //restore.
                                                Order = DummyOrder;
                                                ChessRules.CurrentOrder = DummyCurrentOrder;
                                            }
                                        }

                                    }
                                }
                            }

                        }
                }

            }
            //return false.
            return false;
        }
        //When Next Movements is Checked.QC-OK
        bool IsNextMovmentIsCheckOrCheckMateForCurrentMovment(int[,] Tab, int Order, Color a, int i, int j)
        {
            //Store.
            int DummyOrder = Order;
            int DummyCurrentOrder = ChessRules.CurrentOrder;

            //For Current Order.
            int iii = i, jjj = j;
            //For Enemy Home of Current
            for (int ii = 0; ii < 8; ii++)
                for (int jj = 0; jj < 8; jj++)
                {
                    //Ignore Of Self Objects.
                    if (Order == 1 && Tab[ii, jj] >= 0)
                        continue;
                    else
                        if (Order == -1 && Tab[ii, jj] <= 0)
                            continue;
                    //Clone a Copy.
                    int[,] TabS = new int[8, 8];
                    for (int h = 0; h < 8; h++)
                        for (int k = 0; k < 8; k++)
                        {
                            TabS[h, k] = Tab[h, k];
                        }
                    ChessRules A = new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, TabS[ii, jj], TabS, Order * -1, ii, jj);
                    Color D = Color.Gray;
                    if (Order * -1 == -1)
                        D = Color.Brown;
                    if (A.Rules(ii, jj, iii, jjj, D, TabS[ii, jj]))
                    {
                        TabS[iii, jjj] = TabS[ii, jj];
                        TabS[ii, jj] = 0;
                        //Settting Enemy Order.
                        //ChessRules.CurrentOrder = Order * -1;
                        //When Enemy Attacked Current Objects.

                        if (A.CheckMate(TabS, Order * -1))
                        {
                            //For All Current Objects.
                            for (int iiii = 0; iiii < 8; iiii++)
                                for (int jjjj = 0; jjjj < 8; jjj++)
                                {
                                    //clone a Copy.
                                    int[,] TabSS = new int[8, 8];
                                    for (int h = 0; h < 8; h++)
                                        for (int k = 0; k < 8; k++)
                                        {
                                            TabSS[h, k] = TabS[h, k];
                                        }
                                    //Create ChessRules Object.
                                    A = new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, TabSS[iiii, jjjj], TabSS, Order, iiii, jjjj);
                                    //When is Movable.
                                    if (A.Rules(iiii, jjjj, iii, jjj, a, TabSS[iiii, jjjj]))
                                    {
                                        //Take Move.
                                        TabSS[iii, jjj] = TabSS[iiii, jjjj];
                                        TabSS[iiii, jjjj] = 0;
                                        //When is CheckedMate 
                                        if (A.CheckMate(TabSS, Order))
                                        {
                                            //When is Gray Check.
                                            if (Order == 1 && (A.CheckGray))
                                            {
                                                //return true.
                                                Order = DummyOrder;
                                                ChessRules.CurrentOrder = DummyCurrentOrder;
                                                return true;

                                            }
                                            else
                                                //When is Brown Checked.
                                                if (Order == -1 && (A.CheckBrown))
                                                {
                                                    //return true.
                                                    Order = DummyOrder;
                                                    ChessRules.CurrentOrder = DummyCurrentOrder;
                                                    return true;

                                                }
                                        }
                                    }
                                }
                            //return false.
                            return false;
                        }
                        else
                            //return false.
                            return false;
                    }
                }
            Order = DummyOrder;
            ChessRules.CurrentOrder = DummyCurrentOrder;

            //return false.
            return false;
        }
        //When Current Movements is in dangrous and is not movable.QC-OK
        bool IsGardForCurrentMovmentsAndIsNotMovable(int[,] Tab, int Order, Color a, int i, int j)
        {
            //Setting false.
            bool Attacked = false;
            int DummyOrder = Order;
            int DummyCurrentOrder = ChessRules.CurrentOrder;
            //For Enemy Order.
            for (int ii = 0; ii < 8; ii++)
                for (int jj = 0; jj < 8; jj++)
                {
                    //Ignore of Self Objects.
                    if (Order == 1 && Tab[ii, jj] >= 0)
                        continue;
                    else
                        if (Order == -1 && Tab[ii, jj] <= 0)
                            continue;

                    //For Enemy Order.
                    ChessRules.CurrentOrder = Order * -1;
                    //When Enemy Attacked Current Movements.
                    if (Attack(Tab, ii, jj, i, j, a, Order * -1))
                    {
                        //Restore
                        Order = DummyOrder;
                        ChessRules.CurrentOrder = DummyCurrentOrder;
                        //For Enemy Objects and Empty.
                        for (int iii = 0; iii < 8; iii++)
                            for (int jjj = 0; jjj < 8; jjj++)
                            {
                                //Ignore of Self Objects.
                                if (Order == 1 && Tab[iii, jjj] > 0)
                                    continue;
                                else
                                    if (Order == -1 && Tab[iii, jjj] < 0)
                                        continue;
                                //Clone a Table.
                                int[,] TabS = new int[8, 8];
                                for (int p = 0; p < 8; p++)
                                    for (int m = 0; m < 8; m++)
                                        TabS[p, m] = Tab[p, m];
                                //When Current Objects Attacked Enemy.
                                if ((new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, TabS[i, j], TabS, Order, i, j)).Rules(i, j, iii, jjj, a, TabS[i, j]))
                                {
                                    //Take Movments.
                                    TabS[iii, jjj] = TabS[i, j];
                                    TabS[i, j] = 0;
                                    //Restore and Setting Enemy.
                                    Order = DummyOrder;
                                    ChessRules.CurrentOrder = DummyCurrentOrder;
                                    ChessRules.CurrentOrder = Order * -1;
                                    //For Enemy Order.
                                    for (int p = 0; p < 8; p++)
                                        for (int m = 0; m < 8; m++)
                                        {
                                            //Ignore of Self and Empty.
                                            if (Order == 1 && TabS[p, m] >= 0)
                                                continue;
                                            else
                                                if (Order == -1 && TabS[p, m] <= 0)
                                                    continue;
                                            //Setting Color.
                                            a = Color.Gray;
                                            if (TabS[p, m] < 0)
                                                a = Color.Brown;
                                            //When Enemy Attacked Current Objects (By Take Movments.).
                                            if (Attack(TabS, p, m, iii, jjj, a, Order * -1))
                                                //Take or All
                                                Attacked |= true;
                                            else
                                                //Take and All.
                                                Attacked &= true;
                                            //Rerstore.
                                            Order = DummyOrder;
                                            ChessRules.CurrentOrder = DummyCurrentOrder;


                                        }
                                }
                            }
                    }
                }
            //Restore.
            Order = DummyOrder;
            ChessRules.CurrentOrder = DummyCurrentOrder;
            Order = DummyOrder;
            ChessRules.CurrentOrder = DummyCurrentOrder;

            //Return Variable.
            return Attacked;
        }

        ///when current movments gards enemy with higer priority.QC-OK
        bool IsEnenmyInGardForCurrentMovmentsIsSuitable(int[,] Tab, int Order, Color a, int i, int j)
        {
            int Supported = 0;
            int Attacked = 0;
            int DummyOrder = Order;
            int DummyCurrentOrder = ChessRules.CurrentOrder;

            //For Enemy Order.
            for (int ii = 0; ii < 8; ii++)
                for (int jj = 0; jj < 8; jj++)
                {
                    //Ignore of Self Order.
                    if (Order == 1 && Tab[ii, jj] >= 0)
                        continue;
                    else
                        if (Order == -1 && Tab[ii, jj] <= 0)
                            continue;
                    //When There is Enemy Gard The Current PenaltyRegard Mechanisam is Suitabled
                    if (Attack(Tab, ii, jj, i, j, a, Order * -1))
                        Attacked++;
                }
            //restore.
            Order = DummyOrder;
            ChessRules.CurrentOrder = DummyCurrentOrder;
            //For Current Order.
            for (int iii = 0; iii < 0; iii++)
                for (int jjj = 0; jjj < 0; jjj++)
                {
                    //Ignore of Enemy.
                    if (Order == 1 && Tab[iii, jjj] <= 0)
                        continue;
                    else
                        if (Order == -1 && Tab[iii, jjj] >= 0)
                            continue;
                    //When Cuurent supported currenty movments.
                    if (Support(Tab, i, j, iii, jjj, a, Order))
                        Supported++;
                }

            //When number of Supported is less tahn number of attackers return true.
            if (Supported < Attacked)
            {
                Order = DummyOrder;
                ChessRules.CurrentOrder = DummyCurrentOrder;
                return true;
            }
            Order = DummyOrder;
            ChessRules.CurrentOrder = DummyCurrentOrder;

            //return false.
            return false;
        }
        ///Huristic of Check and CheckMate.QC-OK
        public double HuristicCheckAndCheckMate(int[,] Table, Color a)
        {
            double HA = 0;
            int DumOrder = Order;
            int DummyOrder = Order;
            int DummyCurrentOrder = ChessRules.CurrentOrder;

            double ObjectDangour = 0;
            double Check = 0;
            double CheckMate = 9999999;

            
                //if (AStarGreedyHuristicT)
                {
                    //Consider Global Check CheckMate ObjectDanger Variables Orderly.
                    ChessRules A = new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, 1, Table, Order, Row, Column);
                    A.CheckMate(Table, Order);
                    ChessRules AA = new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, 1, Table, Order, Row, Column);
                    AA.ObjectDangourKingMove(Order, Table, false);
                    {
                        //Consider Value to More Valuable Positive and Negative Check CheckMate ObjectDanger 
                        if (A.CheckMateGray || A.CheckMateBrown)
                        {//When is Brown CheckedMate.
                            if (Order == 1 && A.CheckMateBrown)
                            {
                                HuristicObjectDangourCheckMateValue += CheckMate * SignOrderToPlate(Order);
                                HA += CheckMate * SignOrderToPlate(Order);
                                MovementsAStarGreedyHuristicFoundT = true;
                            }
                            //When is Gray CheckedMate.
                            if (Order == -1 && A.CheckMateGray)
                            {
                                HuristicObjectDangourCheckMateValue += CheckMate * SignOrderToPlate(Order);
                                HA += CheckMate * SignOrderToPlate(Order);
                                MovementsAStarGreedyHuristicFoundT = true;
                            }
                        }
                        //When is Checked.
                        if (A.CheckGray || A.CheckBrown)
                        {
                            //When is Gray Checked 
                            if (Order == 1 && A.CheckBrown)
                            {
                                HuristicObjectDangourCheckMateValue += Check * SignOrderToPlate(Order);
                                HA += Check * SignOrderToPlate(Order);
                                MovementsAStarGreedyHuristicFoundT = true;
                            }
                            //When is Brown Check.
                            if (Order == -1 && A.CheckGray)
                            {
                                HuristicObjectDangourCheckMateValue += Check * SignOrderToPlate(Order);
                                HA += Check * SignOrderToPlate(Order);
                                MovementsAStarGreedyHuristicFoundT = true;
                            }
                        }
                        //When is Objects Dangoure.
                        if (AA.CheckGrayObjectDangour || AA.CheckBrownObjectDangour)
                        {
                            //when is Gray Objects Dangoure.
                            if (Order == 1 && AA.CheckBrownObjectDangour)
                            {
                                HuristicObjectDangourCheckMateValue += ObjectDangour * SignOrderToPlate(Order);
                                HA += ObjectDangour * SignOrderToPlate(Order);
                                MovementsAStarGreedyHuristicFoundT = true;
                            }
                            //when is Gray Objects Dangoure.
                            if (Order == -1 && AA.CheckGrayObjectDangour)
                            {
                                HuristicObjectDangourCheckMateValue += ObjectDangour * SignOrderToPlate(Order);
                                HA += ObjectDangour * SignOrderToPlate(Order);
                                MovementsAStarGreedyHuristicFoundT = true;
                            }
                        }
                        //When is CheckMate
                        if (A.CheckMateGray || A.CheckMateBrown)
                        {
                            //When is Gray Check Mate.
                            if (Order == 1 && A.CheckMateGray)
                            {
                                HuristicObjectDangourCheckMateValue -= CheckMate * SignOrderToPlate(Order);
                                HA -= CheckMate * SignOrderToPlate(Order);
                            }
                            //when is Brown CheckMate.
                            if (Order == -1 && A.CheckMateBrown)
                            {
                                HuristicObjectDangourCheckMateValue -= CheckMate * SignOrderToPlate(Order);
                                HA -= CheckMate * SignOrderToPlate(Order);
                            }
                        }
                        //when is Check
                        if (A.CheckGray || A.CheckBrown)
                        {
                            //when is Gray Check
                            if (Order == 1 && A.CheckGray)
                            {
                                HuristicObjectDangourCheckMateValue -= Check * SignOrderToPlate(Order);
                                HA -= Check * SignOrderToPlate(Order);
                            }
                            //When is Brown Check.
                            if (Order == -1 && A.CheckBrown)
                            {
                                HuristicObjectDangourCheckMateValue -= Check * SignOrderToPlate(Order);
                                HA -= Check * SignOrderToPlate(Order);
                            }
                        }
                        //When is Object Dangoure.
                        if (AA.CheckBrownObjectDangour || AA.CheckGrayObjectDangour)
                        {
                            //When is Gray Object.
                            if (Order == 1 && AA.CheckGrayObjectDangour)
                            {
                                HuristicObjectDangourCheckMateValue -= ObjectDangour * SignOrderToPlate(Order);
                                HA -= ObjectDangour * SignOrderToPlate(Order);
                            }
                            //When is Brown Object Dangoure.
                            if (Order == -1 && AA.CheckBrownObjectDangour)
                            {
                                HuristicObjectDangourCheckMateValue -= ObjectDangour * SignOrderToPlate(Order);
                                HA -= ObjectDangour * SignOrderToPlate(Order);
                            }
                        }
                    }
                }
           
            //HuristicObjectDangourCheckMateValue *= SignOrderToPlate(Order);
            Order = DummyOrder;
            ChessRules.CurrentOrder = DummyCurrentOrder;
            Order = DumOrder;
            return HA;
        }
        //Veryfy and detect Object Value.
        int VeryFye(int[,] Table, int Order, Color a)
        {
            int HA = 0;
            int Object = Table[Row, Column];
            //Wehn Solider.
            if (System.Math.Abs(Object) == 1)
                HA = 1;
            //When Elephant.
            else if (System.Math.Abs(Object) == 2)
                HA = 2;
            //When Hourse.
            else if (System.Math.Abs(Object) == 3)
                HA = 3;
            //When Bridges.
            else if (System.Math.Abs(Object) == 4)
                HA = 5;
            //When Minster.
            else if (System.Math.Abs(Object) == 5)
                HA = 8;
            //When King.
            else if (System.Math.Abs(Object) == 6)
                HA = 10;
            return HA;

        }
        //QC_OK
        //Numbers of Supporting Current Objects method.
        int SupporterCount(int[,] Table, int Order, Color a, int ii, int jj)
        {
            int Count = 0;
            int DummyOrder = Order;
            int DummyCurrentOrder = ChessRules.CurrentOrder;
            if (Order == 1)
                ChessRules.CurrentOrder = 1;
            else
                ChessRules.CurrentOrder = -1;
            bool[,] Tab = new bool[8, 8];
            for (int i = 0; i < 8; i++)
                for (int j = 0; j < 8; j++)
                {
                    if (Order == 1 && Table[i, j] <= 0)
                        continue;
                    else
                        if (Order == -1 && Table[i, j] >= 0)
                            continue;
                    if (Support(Table, i, j, ii, jj, a, Order))
                    {
                        Count++;
                    }
                }

            Order = DummyOrder;
            ChessRules.CurrentOrder = DummyCurrentOrder;
            return Count;
        }
        //Attacks on Enemies.QC-OK
        int AttackerCount(int[,] Table, int Order, Color a, int i, int j)
        {
            int Count = 0;
            int DummyOrder = Order;
            int DummyCurrentOrder = ChessRules.CurrentOrder;
            int[,] Tab = new int[8, 8];
            for (int h = 0; h < 8; h++)
                for (int k = 0; k < 8; k++)
                    Tab[h, k] = Table[h, k];
            //For Slef Objects..
            for (int ii = 0; ii < 8; ii++)
                for (int jj = 0; jj < 8; jj++)
                {
                    //Ignore Of Self Objects
                    if (Order == 1 && Tab[ii, jj] >= 0)
                        continue;
                    else
                        if (Order == -1 && Tab[ii, jj] <= 0)
                            continue;
                    //If Current Attacks Enemy.
                    if (Attack(Tab, i, j, ii, jj, a, Order))
                    {
                        Count++;
                    }
                }

            Order = DummyOrder;
            ChessRules.CurrentOrder = DummyCurrentOrder;
            return Count;
        }
        //Attackers of Enemies.QC_OK.
        int EnemyAttackerCount(int[,] Table, int Order, Color a, int ii, int jj)
        {
            int Count = 0;
            int DummyOrder = Order;
            int DummyCurrentOrder = ChessRules.CurrentOrder;
            if (Order == 1)
                ChessRules.CurrentOrder = 1;
            else
                ChessRules.CurrentOrder = -1;
            int[,] Tab = new int[8, 8];
            for (int h = 0; h < 8; h++)
                for (int k = 0; k < 8; k++)
                    Tab[h, k] = Table[h, k];
            for (int i = 0; i < 8; i++)
                for (int j = 0; j < 8; j++)
                {
                    if (Order == 1 && Table[i, j] >= 0)
                        continue;
                    else
                        if (Order == -1 && Table[i, j] <= 0)
                            continue;
                    if (Attack(Table, i, j, ii, jj, a, Order * -1))
                    {
                        Count++;
                    }
                }

            Order = DummyOrder;
            ChessRules.CurrentOrder = DummyCurrentOrder;
            return Count;
        }
        //Distance of Enemy Kings from Current Object.QC-OK
        public double HeuristicDistabceOfCurrentMoveFromEnemyKing(int[,] Tab, int Order, int ii, int jj)
        {
            //Initiate.
            int RowG = -1, ColumnG = -1, RowB = -1, ColumnB = -1;
            //Create ChessRules Objects.
            ChessRules A = new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, Tab[ii, jj], Tab, Order, ii, jj);
            double Dis = 0;
            //Order is  Gray.
            if (Order == -1)
            {
                //Found of Gray King Location.
                A.FindGrayKing(Tab, ref RowG, ref ColumnG);
                
                //When Soldier.
                if (System.Math.Abs(Tab[ii, jj]) == 1)
                    Dis = -100.0 * (1.0 / (double)SodierValue) * System.Math.Sqrt(System.Math.Pow(ii - RowG, 2) + System.Math.Pow(jj - ColumnG, 2));
                else
                    //When Elephant.
                    if (System.Math.Abs(Tab[ii, jj]) == 2)
                        Dis = -100.0 * (1.0 / (double)ElefantValue) * System.Math.Sqrt(System.Math.Pow(ii - RowG, 2) + System.Math.Pow(jj - ColumnG, 2));
                    else
                        //When Hourse.
                        if (System.Math.Abs(Tab[ii, jj]) == 3)
                            Dis = -100.0 * (1.0 / (double)HourseValue) * System.Math.Sqrt(System.Math.Pow(ii - RowG, 2) + System.Math.Pow(jj - ColumnG, 2));
                        else
                            //When Bridges.
                            if (System.Math.Abs(Tab[ii, jj]) == 4)
                                Dis = -100.0 * (1.0 / (double)BridgeValue) * System.Math.Sqrt(System.Math.Pow(ii - RowG, 2) + System.Math.Pow(jj - ColumnG, 2));
                            else
                                //When minister.
                                if (System.Math.Abs(Tab[ii, jj]) == 5)
                                    Dis = -100.0 * (1.0 / (double)MinisterValue) * System.Math.Sqrt(System.Math.Pow(ii - RowG, 2) + System.Math.Pow(jj - ColumnG, 2));
                                else
                                    //When King.
                                    if (System.Math.Abs(Tab[ii, jj]) == 6)
                                        Dis = -100.0 * (1.0 / (double)KingValue) * System.Math.Sqrt(System.Math.Pow(ii - RowG, 2) + System.Math.Pow(jj - ColumnG, 2));
                // Dis = -1000.0;
                HuristicObjectDangourCheckMateValue += Dis * SignOrderToPlate(Order);
            }
            //Brown Order.
            else
            {
                //Found of Brown King Location.
                A.FindBrownKing(Tab, ref RowB, ref ColumnB);                
                //When Soldier.
                if (System.Math.Abs(Tab[ii, jj]) == 1)
                    Dis = -100.0 * (1.0 / (double)SodierValue) * System.Math.Sqrt(System.Math.Pow(ii - RowB, 2) + System.Math.Pow(jj - ColumnB, 2));
                else
                    //When Elephant.
                    if (System.Math.Abs(Tab[ii, jj]) == 2)
                        Dis = -100.0 * (1.0 / (double)ElefantValue) * System.Math.Sqrt(System.Math.Pow(ii - RowB, 2) + System.Math.Pow(jj - ColumnB, 2));
                    else
                        //When Hourse.
                        if (System.Math.Abs(Tab[ii, jj]) == 3)
                            Dis = -100.0 * (1.0 / (double)HourseValue) * System.Math.Sqrt(System.Math.Pow(ii - RowB, 2) + System.Math.Pow(jj - ColumnB, 2));
                        else
                            //When Bridges.
                            if (System.Math.Abs(Tab[ii, jj]) == 4)
                                Dis = -100.0 * (1.0 / (double)BridgeValue) * System.Math.Sqrt(System.Math.Pow(ii - RowB, 2) + System.Math.Pow(jj - ColumnB, 2));
                            else
                                //When Minister.
                                if (System.Math.Abs(Tab[ii, jj]) == 5)
                                    Dis = -100.0 * (1.0 / (double)MinisterValue) * System.Math.Sqrt(System.Math.Pow(ii - RowB, 2) + System.Math.Pow(jj - ColumnB, 2));
                                else
                                    //When King.
                                    Dis = -100.0 * (1.0 / (double)KingValue) * System.Math.Sqrt(System.Math.Pow(ii - RowG, 2) + System.Math.Pow(jj - ColumnG, 2));
                //Dis = -1000.0;
                HuristicObjectDangourCheckMateValue += Dis * SignOrderToPlate(Order);
            }
            return Dis;
        }
        ///Huristic of Movments.QC-OK
        public double HuristicMovment(int[,] Table, Color a, int ii, int jj)
        {
            //Initiate Local Variable.
            double HA = 0;
            int DummyOrder = Order;
            int DummyCurrentOrder = ChessRules.CurrentOrder;
            ///When AStarGreedy Huristic is Not Assigned.
            
                if (!AStarGreedyHuristicT)
                {
                    ///For Current Objects.
                    //int ii = Row, jj = Column;
                    for (int i = 0; i < 8; i++)
                    {
                        for (int j = 0; j < 8; j++)
                        {
                            if (i == ii && j == jj)
                                continue;
                            Order = DummyOrder;
                            int Sign = 1;
                            ///When Moveble is true. means [ii,jj] is in Movmebale to [i,j].
                            ///What is Moveable!
                            ///Ans:When [ii,jj] is Movebale to [i,j] return true when Empty or Enemy is located in [ii,jj].
                            if (Table[i, j] >= 0 && DummyOrder == -1 && Table[ii, jj] < 0)
                            {
                                Order = -1;
                                Sign = 1 * AllDraw.SignMovments;
                                ChessRules.CurrentOrder = -1;
                                a = Color.Brown;
                            }
                            else if (Table[i, j] <= 0 && DummyOrder == 1 && Table[ii, jj] > 0)
                            {
                                Order = 1;
                                Sign = 1 * AllDraw.SignMovments;
                                ChessRules.CurrentOrder = 1;
                                a = Color.Gray;
                            }
                            else
                                continue;
                            //When is Movable Movement inCurrent.
                            if (Movable(Table, ii, jj, i, j, a, Order))
                            {
                                //When Solider.
                                if (System.Math.Abs(Table[ii, jj]) == 1)
                                    HA += (Sign * System.Math.Abs(SodierValue - GetObjectValue(Table, i, j, Order)
                                        ));
                                //When Elephant.
                                else if (System.Math.Abs(Table[ii, jj]) == 2)
                                    HA += (Sign * System.Math.Abs(ElefantValue - GetObjectValue(Table, i, j, Order)
                                        ));
                                //When Hourse.
                                else if (System.Math.Abs(Table[ii, jj]) == 3)
                                    HA += (Sign * System.Math.Abs(HourseValue - GetObjectValue(Table, i, j, Order)
                                        ));
                                //When Bridges.
                                else if (System.Math.Abs(Table[ii, jj]) == 4)
                                    HA += (Sign * System.Math.Abs(BridgeValue - GetObjectValue(Table, i, j, Order)
                                        ));
                                //When Minister.
                                else if (System.Math.Abs(Table[ii, jj]) == 5)
                                    HA += (Sign * System.Math.Abs(MinisterValue - GetObjectValue(Table, i, j, Order)
                                        ));
                                //When King.
                                else if (System.Math.Abs(Table[ii, jj]) == 6)
                                    HA += (Sign * System.Math.Abs(KingValue - GetObjectValue(Table, i, j, Order)
                                        ));
                            }
                        }
                    }

                }
                //For All Homes Table.
                else
                {
                    for (int i = 0; i < 8; i++)
                    {
                        for (int j = 0; j < 8; j++)
                        {
                            for (ii = 0; ii < 8; ii++)
                            {
                                for (jj = 0; jj < 8; jj++)
                                {
                                    if (i == ii && j == jj)
                                        continue;
                                    int Sign = 1;
                                    Order = DummyOrder;
                                    ///When Moveble is true. means [ii,jj] is in Movmebale to [i,j].
                                    ///What is Moveable!
                                    ///Ans:When [ii,jj] is Movebale to [i,j] return true when Empty or Enemy is located in [ii,jj].
                                    if (Table[i, j] >= 0 && DummyOrder == -1 && Table[ii, jj] < 0)
                                    {
                                        Order = -1;
                                        Sign = 1 * AllDraw.SignMovments;
                                        ChessRules.CurrentOrder = -1;
                                        a = Color.Brown;
                                    }
                                    else if (Table[i, j] <= 0 && DummyOrder == 1 && Table[ii, jj] > 0)
                                    {
                                        Order = 1;
                                        Sign = 1 * AllDraw.SignMovments;
                                        ChessRules.CurrentOrder = 1;
                                        a = Color.Gray;
                                    }
                                    else
                                        continue;
                                    //If Current Home is Moveble.
                                    if (Movable(Table, ii, jj, i, j, a, Order))
                                    {
                                        //When Soldier.
                                        if (System.Math.Abs(Table[ii, jj]) == 1)
                                            HA += (Sign * System.Math.Abs(SodierValue - GetObjectValue(Table, i, j, Order)
                                                ));
                                        //When Elephant.
                                        else if (System.Math.Abs(Table[ii, jj]) == 2)
                                            HA += (Sign * System.Math.Abs(ElefantValue - GetObjectValue(Table, i, j, Order)
                                                ));
                                        //When Hourse.
                                        else if (System.Math.Abs(Table[ii, jj]) == 3)
                                            HA += (Sign * System.Math.Abs(HourseValue - GetObjectValue(Table, i, j, Order)
                                                ));
                                        //When Bridges.
                                        else if (System.Math.Abs(Table[ii, jj]) == 4)
                                            HA += (Sign * System.Math.Abs(BridgeValue - GetObjectValue(Table, i, j, Order)
                                                ));
                                        //When Minister.
                                        else if (System.Math.Abs(Table[ii, jj]) == 5)
                                            HA += (Sign * System.Math.Abs(MinisterValue - GetObjectValue(Table, i, j, Order)
                                                ));
                                        //When King.
                                        else if (System.Math.Abs(Table[ii, jj]) == 6)
                                            HA += (Sign * System.Math.Abs(KingValue - GetObjectValue(Table, i, j, Order)
                                                ));
                                    }

                                }
                            }
                        }
                    }
                }
           

            //Reassignments of Begin Call Global Orders.
            Order = DummyOrder;
            ChessRules.CurrentOrder = DummyCurrentOrder;
            //Store Local Huristic in Global One.
            HuristicMovementValue += HA * SignOrderToPlate(Order);
            //Return Local Huristic.
            return HA;

        }

        ///Attack Determination.QC_Ok
        public bool Attack(int[,] Tab, int i, int j, int ii, int jj, Color a, int Order)
        {
            int CCurentOrder = ChessRules.CurrentOrder;
            //Initiate Global static  Variable.
            ChessRules.CurrentOrder = Order;
            int[,] Table = new int[8, 8];
            for (int ik = 0; ik < 8; ik++)
                for (int jk = 0; jk < 8; jk++)
                    Table[ik, jk] = Tab[ik, jk];

            //when there is a Movment from Parameter One to Second Parameter return Attacke..
            if ((new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, Table[i, j], Table, Order, i, j)).Rules(i, j, ii, jj, a, Order) && Table[ii, jj] != 0)
            {
                ChessRules.CurrentOrder = CCurentOrder;
                return true;
            }
            ChessRules.CurrentOrder = CCurentOrder;
            return false;
        }
        ///ObjectDanger Determination.QC-OK
        public bool ObjectDanger(int[,] Tab, int i, int j, int ii, int jj, Color a, int Order)
        {
            int CCurrentOrder = ChessRules.CurrentOrder;
            //Initiate Local Varibales.
            int[,] Table = new int[8, 8];
            for (int iii = 0; iii < 8; iii++)
                for (int jjj = 0; jjj < 8; jjj++)
                {
                    Table[iii, jjj] = Tab[iii, jjj];
                }
            ChessRules.CurrentOrder = Order;
            ///When [i,j] is Attacked [ii,jj] retrun true when enemy is located in [ii,jj].
            if ((new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, Table[i, j], Table, Order, i, j)).Rules(i, j, ii, jj, a, Order))
            {
                //Initiate Local Variables.
                for (int iii = 0; iii < 8; iii++)
                    for (int jjj = 0; jjj < 8; jjj++)
                    {
                        Table[iii, jjj] = Tab[iii, jjj];
                    }
                //Take Movments.
                Table[ii, jj] = Table[i, j];
                Table[i, j] = 0;
                //Consider Check.
                ChessRules AA = new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, Table[ii, jj], Table, Order, i, j);
                if (AA.ObjectDangourKingMove(Order, Table, false))
                {
                    ChessRules.CurrentOrder = CCurrentOrder;
                    //Return ObjectDanger.
                    if ((AA.CheckGrayObjectDangour) && Order == 1)
                        return true;
                    else
                        if ((AA.CheckBrownObjectDangour) && Order == -1)
                            return true;

                }
                if (AA.CheckMate(Table, Order))
                {
                    ChessRules.CurrentOrder = CCurrentOrder;
                    //Return ObjectDanger.
                    if ((AA.CheckGray || AA.CheckMateGray) && Order == 1)
                        return true;
                    else
                        if ((AA.CheckBrown || AA.CheckMateBrown) && Order == -1)
                            return true;

                }
            }





            ChessRules.CurrentOrder = CCurrentOrder;
            //return Non ObjectDanger.
            return false;
        }

        ///Supportation Determination.QC_OK
        public bool Support(int[,] Tab, int i, int j, int ii, int jj, Color a, int Order)
        {
            //Initiate Local Variables.
            int[,] Table = new int[8, 8];

            for (int iii = 0; iii < 8; iii++)
                for (int jjj = 0; jjj < 8; jjj++)
                    Table[iii, jjj] = Tab[iii, jjj];
            ///When All Tables is Gray.
            if (Table[i, j] > 0 && Table[ii, jj] > 0)
            {
                Table[ii, jj] = 0;
                ///When [i,j] Supporte [ii,jj].
                if ((new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, Table[i, j], Table, Order, i, j)).Rules(i, j, ii, jj, a, Order))
                {

                    return true;
                }

            }

            for (int iii = 0; iii < 8; iii++)
                for (int jjj = 0; jjj < 8; jjj++)
                    Table[iii, jjj] = Tab[iii, jjj];
            ///When All is Brown.
            if (Table[i, j] < 0 && Table[ii, jj] < 0)
            {
                ///When [i,j] Supporetd [ii,jj].
                Table[ii, jj] = 0;
                if ((new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, Table[i, j], Table, Order, i, j)).Rules(i, j, ii, jj, a, Table[i, j]))
                {
                    return true;
                }
            }

            return false;
        }
        //Return Msx Huiristic of Child Level.
        public bool MaxHuristic(ref int j, int Kin, ref double Less)
        {
            bool Found = false;
            //When Solders.
            if (Kin == 1)
            {
                for (int i = 0; i < this.PenaltyRegardListSolder.Count; i++)
                {
                    if (PenaltyRegardListSolder[i].IsPenaltyAction() != 0)
                    {
                        if (Less < HuristicListSolder[i][0] +
                            HuristicListSolder[i][1] +
                            HuristicListSolder[i][2] +
                            HuristicListSolder[i][3] +
                            HuristicListSolder[i][4] +
                            HuristicListSolder[i][5] +
                            HuristicListSolder[i][6])
                        {
                            Less = HuristicListSolder[i][0] +
                        HuristicListSolder[i][1] +
                        HuristicListSolder[i][2] +
                        HuristicListSolder[i][3] +
                        HuristicListSolder[i][4] +
                        HuristicListSolder[i][5] +
                        HuristicListSolder[i][6];
                            j = i;
                            Found = true;
                        }

                    }
                }

            }

            else//When Elephant.
                if (Kin == 2)
                {
                    for (int i = 0; i < this.PenaltyRegardListElefant.Count; i++)
                    {
                        if (PenaltyRegardListElefant[i].IsPenaltyAction() != 0)
                        {
                            if (Less < HuristicListElefant[i][0] +
                                HuristicListElefant[i][1] +
                                HuristicListElefant[i][2] +
                                HuristicListElefant[i][3] +
                                HuristicListElefant[i][4] +
                                HuristicListElefant[i][5] +
                                HuristicListElefant[i][6])
                            {
                                Less = HuristicListElefant[i][0] +
                            HuristicListElefant[i][1] +
                            HuristicListElefant[i][2] +
                            HuristicListElefant[i][3] +
                            HuristicListElefant[i][4] +
                            HuristicListElefant[i][5] +
                            HuristicListElefant[i][6];
                                j = i;
                                Found = true;
                            }

                        }
                    }
                }
                else//When Hourse.
                    if (Kin == 3)
                    {
                        for (int i = 0; i < this.PenaltyRegardListHourse.Count; i++)
                        {
                            if (PenaltyRegardListHourse[i].IsPenaltyAction() != 0)
                            {
                                if (Less < HuristicListHourse[i][0] +
                                    HuristicListHourse[i][1] +
                                    HuristicListHourse[i][2] +
                                    HuristicListHourse[i][3] +
                                    HuristicListHourse[i][4] +
                                    HuristicListHourse[i][5] +
                                    HuristicListHourse[i][6])
                                {
                                    Less = HuristicListHourse[i][0] +
                                HuristicListHourse[i][1] +
                                HuristicListHourse[i][2] +
                                HuristicListHourse[i][3] +
                                HuristicListHourse[i][4] +
                                HuristicListHourse[i][5] +
                                HuristicListHourse[i][6];
                                    j = i;
                                    Found = true;
                                }

                            }
                        }
                    }
                    else//When Bridges.
                        if (Kin == 4)
                        {
                            for (int i = 0; i < this.PenaltyRegardListBridge.Count; i++)
                            {
                                if (PenaltyRegardListBridge[i].IsPenaltyAction() != 0)
                                {
                                    if (Less < HuristicListBridge[i][0] +
                                        HuristicListBridge[i][1] +
                                        HuristicListBridge[i][2] +
                                        HuristicListBridge[i][3] +
                                        HuristicListBridge[i][4] +
                                        HuristicListBridge[i][5] +
                                        HuristicListBridge[i][6])
                                    {
                                        Less = HuristicListBridge[i][0] +
                                    HuristicListBridge[i][1] +
                                    HuristicListBridge[i][2] +
                                    HuristicListBridge[i][3] +
                                    HuristicListBridge[i][4] +
                                    HuristicListBridge[i][5] +
                                    HuristicListBridge[i][6];
                                        j = i;
                                        Found = true;
                                    }

                                }
                            }
                        }
                        else//When Minister.
                            if (Kin == 5)
                            {
                                for (int i = 0; i < this.PenaltyRegardListMinister.Count; i++)
                                {
                                    if (PenaltyRegardListMinister[i].IsPenaltyAction() != 0)
                                    {
                                        if (Less < HuristicListMinister[i][0] +
                                            HuristicListMinister[i][1] +
                                            HuristicListMinister[i][2] +
                                            HuristicListMinister[i][3] +
                                            HuristicListMinister[i][4] +
                                            HuristicListMinister[i][5] +
                                            HuristicListMinister[i][6])
                                        {
                                            Less = HuristicListMinister[i][0] +
                                        HuristicListMinister[i][1] +
                                        HuristicListMinister[i][2] +
                                        HuristicListMinister[i][3] +
                                        HuristicListMinister[i][4] +
                                        HuristicListMinister[i][5] +
                                        HuristicListMinister[i][6];
                                            j = i;
                                            Found = true;
                                        }

                                    }
                                }
                            }
                            else//When King.
                                if (Kin == 6)
                                {
                                    for (int i = 0; i < this.PenaltyRegardListKing.Count; i++)
                                    {
                                        if (PenaltyRegardListKing[i].IsPenaltyAction() != 0)
                                        {
                                            if (Less < HuristicListKing[i][0] +
                                                HuristicListKing[i][1] +
                                                HuristicListKing[i][2] +
                                                HuristicListKing[i][3] +
                                                HuristicListKing[i][4] +
                                                HuristicListKing[i][5] +
                                                HuristicListKing[i][6])
                                            {
                                                Less = HuristicListKing[i][0] +
                                            HuristicListKing[i][1] +
                                            HuristicListKing[i][2] +
                                            HuristicListKing[i][3] +
                                            HuristicListKing[i][4] +
                                            HuristicListKing[i][5] +
                                            HuristicListKing[i][6];
                                                j = i;
                                                Found = true;
                                            }

                                        }
                                    }
                                }
            return Found;
        }
        //Setting Numbers of Objects in Current Table boards.
        public void SetObjectNumbers(int[,] TabS)
        {
            //Set Zero Object Table Count.
            SodierMidle = 0;
            SodierHigh = 0;
            ElefantMidle = 0;
            ElefantHigh = 0;
            HourseMidle = 0;
            HourseHight = 0;
            BridgeMidle = 0;
            BridgeHigh = 0;
            MinisterMidle = 0;
            MinisterHigh = 0;
            KingMidle = 0;
            KingHigh = 0;
            //For All Table items.
            for (int h = 0; h < 8; h++)
                for (int s = 0; s < 8; s++)
                {
                    //When Gray Soldier.
                    if (TabS[h, s] == 1)
                    {
                        SodierMidle++;
                        SodierHigh++;
                    }
                    //When Gray Elephant.
                    else if (TabS[h, s] == 2)
                    {
                        ElefantMidle++;
                        ElefantHigh++;
                    }
                    //When Gray Hourse.
                    else if (TabS[h, s] == 3)
                    {
                        HourseMidle++;
                        HourseHight++;
                    }
                    //When Bridges Gray.
                    else if (TabS[h, s] == 4)
                    {
                        BridgeMidle++;
                        BridgeHigh++;
                    }
                    //When Gray Minster.
                    else if (TabS[h, s] == 5)
                    {
                        MinisterMidle++;
                        MinisterHigh++;
                    }
                    //When Gray King.
                    else if (TabS[h, s] == 6)
                    {
                        KingMidle++;
                        KingHigh++;
                    }
                    else//When Brown Solder.
                        if (TabS[h, s] == -1)
                        {
                            SodierHigh++;
                        }
                        //When Brown Elephant.
                        else if (TabS[h, s] == -2)
                        {
                            ElefantHigh++;
                        }
                        //When Brown Hourse.
                        else if (TabS[h, s] == -3)
                        {
                            HourseHight++;
                        }
                        //When Brown Bridges.
                        else if (TabS[h, s] == -4)
                        {
                            BridgeHigh++;
                        }
                        //When Brown Minster.
                        else if (TabS[h, s] == -5)
                        {

                            MinisterHigh++;
                        }
                        //When Brown King.
                        else if (TabS[h, s] == -6)
                        {
                            KingHigh++;
                        }
                }
        }
        //Count of Solders on Table.
        int SolderOnTableCount(ref DrawSoldier[] So, bool Mi)
        {
            int Count = 0, i = 0;
            
                //For Alll Solders on Color Calculate Solkder Count.
                do
                {
                    if (So[i] != null)
                    {
                        //When Color is Gray or Brown.
                        if (So[i].color == Color.Gray || So[i].color == Color.Brown)
                        {
                            if (Mi)
                            {
                                if (So[i].color == Color.Gray)
                                    Count++;
                            }
                            else
                                Count++;
                        }
                        else
                            So[i] = null;
                    }
                    i++;
                }
                while (i < 64);
           
            return Count;
        }
        //Elepahnt On Table Count.
        int ElefantOnTableCount(ref DrawElefant[] So, bool Mi)
        {

            int Count = 0, i = 0;
            
                //For All Elephant items in Table.
                do
                {
                    if (So[i] != null)
                    {
                        //when Elaphant Color is Gray or Brown.
                        if (So[i].color == Color.Gray || So[i].color == Color.Brown)
                        {
                            if (Mi)
                            {
                                if (So[i].color == Color.Gray)
                                    Count++;
                            }
                            else
                                Count++;
                        }
                        else
                            So[i] = null;
                    }
                    i++;
                }
                while (i < 64);
           
            return Count;
        }
        //Calculate Hourse on table.
        int HourseOnTableCount(ref DrawHourse[] So, bool Mi)
        {
            int Count = 0, i = 0;
            
                do
                {
                    //For All Hourse on Table .
                    if (So[i] != null)
                    {
                        //When Color is Gray or Brown.
                        if (So[i].color == Color.Gray || So[i].color == Color.Brown)
                        {
                            if (Mi)
                            {
                                if (So[i].color == Color.Gray)
                                    Count++;
                            }
                            else
                                Count++;
                        }
                        else
                            So[i] = null;
                    }
                    i++;
                }
                while (i < 64);
           
            return Count;
        }
        //Calculate Bridges Count.
        int BridgeOnTableCount(ref DrawBridge[] So, bool Mi)
        {
            int Count = 0, i = 0;
            
                do
                {
                    if (So[i] != null)
                    {
                        //When Bridges Color is Gray or Brown.
                        if (So[i].color == Color.Gray || So[i].color == Color.Brown)
                        {
                            if (Mi)
                            {
                                if (So[i].color == Color.Gray)
                                    Count++;
                            }
                            else
                                Count++;
                        }
                        else
                            So[i] = null;
                    }
                    i++;
                }
                while (i < 64);
           
            return Count;
        }
        //Calculate Minsiter Count.
        int MinisterOnTableCount(ref DrawMinister[] So, bool Mi)
        {
            int Count = 0, i = 0;
            
                do
                {
                    if (So[i] != null)
                    {
                        //When Color of items is gray or Brown.
                        if (So[i].color == Color.Gray || So[i].color == Color.Brown)
                        {
                            if (Mi)
                            {
                                if (So[i].color == Color.Gray)
                                    Count++;
                            }
                            else
                                Count++;
                        }
                        else
                            So[i] = null;
                    }
                    i++;
                }
                while (i < 64);
           
            return Count;
        }
        //Calculate King on Table.
        int KingOnTableCount(ref DrawKing[] So, bool Mi)
        {
            int Count = 0, i = 0;
            
                do
                {
                    if (So[i] != null)
                    {
                        //when Color is Gray or Brown.
                        if (So[i].color == Color.Gray || So[i].color == Color.Brown)
                        {
                            if (Mi)
                            {
                                if (So[i].color == Color.Gray)
                                    Count++;
                            }
                            else
                                Count++;
                        }
                        else
                            So[i] = null;
                    }
                    i++;
                }
                while (i < 64);
           
            return Count;
        }
        //Return Huristic.
        public double ReturnHuristic(int ii, int j, int Order)
        {
            NumbersOfCurrentBranchesPenalties = 0;
            //calculation of huristic methos and storing value retured.
            double Hur = ReturnHuristicCalculartor(0, ii, j, Order);
            //Optimization depend of numbers of unpealties nodes quefficient.
            return Hur * ((double)(NumbersOfAllNode - NumbersOfCurrentBranchesPenalties) / (double)(NumbersOfAllNode));
        }
        public double ReturnHuristicCalculartor(int iAstarGready, int ii, int j, int Order)
        {
            if (iAstarGready >= AllDraw.MinThinkingTreeDepth)
                return 0;
            NumbersOfCurrentBranchesPenalties = 0;
            double Huristic = 0; ;
            int iIndex = -1, mIndex = -1, jIndex = -1, Kin = -1;
            double Less = Double.MinValue;
            //Calculate numbers of current branches penalties.
            NumbersOfCurrentBranchesPenalties += NumberOfPenalties;
            int DummyOrder = Order;
            if (FormRefrigtz.Blitz)
                Order *= -1;
            if (ii != -1)
            {
                //When is Gray.
                if (Order == -1)
                {
                    //For All Depth Count.
                    for (int i = 0; i < AStarGreedy.Count; i++)
                    {
                        //For All solder DrawOn Table Count.
                        for (int m = 0; m < SolderOnTableCount(ref AStarGreedy[i].SolderesOnTable, true); m++)
                        {
                            //When Depth of Solders On Table is Not NULL.
                            if (AStarGreedy[i].SolderesOnTable[m] != null)
                            {
                                //Calculate Maximum Huristic in Branch.
                                if (AStarGreedy[i].SolderesOnTable[m].SoldierThinking[0].MaxHuristic(ref jIndex, 1, ref Less))
                                {
                                    iIndex = i;
                                    mIndex = m;
                                    Kin = 1;
                                    Huristic = Less;
                                }
                            }

                        }
                        //For All Elephant On Table Count.
                        for (int m = 0; m < ElefantOnTableCount(ref AStarGreedy[i].ElephantOnTable, true); m++)
                        {
                            //For All Elephant in Depth Count.
                            if (AStarGreedy[i].ElephantOnTable[m] != null)
                            {
                                //Found of Maxmimum in Branch.
                                if (AStarGreedy[i].ElephantOnTable[m].ElefantThinking[0].MaxHuristic(ref jIndex, 2, ref Less))
                                {
                                    iIndex = i;
                                    mIndex = m;
                                    Kin = 2;
                                    Huristic = Less;
                                }
                            }

                        }
                        //For All Hourse on Table Count.
                        for (int m = 0; m < HourseOnTableCount(ref AStarGreedy[i].HoursesOnTable, true); m++)
                        {
                            //When is HourseOn Table Depth Object is Not NULL.
                            if (AStarGreedy[i].HoursesOnTable[m] != null)
                            {
                                //Forund of Maximum on on Branch.
                                if (AStarGreedy[i].HoursesOnTable[m].HourseThinking[0].MaxHuristic(ref jIndex, 3, ref Less))
                                {
                                    iIndex = i;
                                    mIndex = m;
                                    Kin = 3;
                                    Huristic = Less;
                                }
                            }

                        }
                        //For All Bridges on table Count.
                        for (int m = 0; m < BridgeOnTableCount(ref AStarGreedy[i].BridgesOnTable, true); m++)
                        {
                            //When Depth Objects of Hourse Table is Not NULL.
                            if (AStarGreedy[i].BridgesOnTable[m] != null)
                            {
                                //Found of Maximum Bridges Branch.
                                if (AStarGreedy[i].BridgesOnTable[m].BridgeThinking[0].MaxHuristic(ref jIndex, 4, ref Less))
                                {
                                    iIndex = i;
                                    mIndex = m;
                                    Kin = 4;
                                    Huristic = Less;
                                }
                            }

                        }
                        //For All Minsiter on table count.
                        for (int m = 0; m < MinisterOnTableCount(ref AStarGreedy[i].MinisterOnTable, true); m++)
                        {
                            //When Minster of Depth is Not Null.
                            if (AStarGreedy[i].MinisterOnTable[m] != null)
                            {
                                //Found of Maximum Minster on table Branches.
                                if (AStarGreedy[i].MinisterOnTable[m].MinisterThinking[0].MaxHuristic(ref jIndex, 5, ref Less))
                                {
                                    iIndex = i;
                                    mIndex = m;
                                    Kin = 5;
                                    Huristic = Less;
                                }
                            }

                        }
                        //For All King on table Count.
                        for (int m = 0; m < KingOnTableCount(ref AStarGreedy[i].KingOnTable, true); m++)
                        {
                            //When Depth Object of King Table is Not NULL.
                            if (AStarGreedy[i].KingOnTable[m] != null)
                            {
                                //Found of Maximum on table Branches.
                                if (AStarGreedy[i].KingOnTable[m].KingThinking[0].MaxHuristic(ref jIndex, 1, ref Less))
                                {
                                    iIndex = i;
                                    mIndex = m;
                                    Kin = 6;
                                    Huristic = Less;
                                }
                            }

                        }
                    }

                }
                else
                {
                    //For All Depth Variables.
                    for (int i = 0; i < AStarGreedy.Count; i++)
                    {
                        //For All Brown Solders on table count.
                        for (int m = SolderOnTableCount(ref AStarGreedy[i].SolderesOnTable, true); m < SolderOnTableCount(ref AStarGreedy[i].SolderesOnTable, false); m++)
                        {
                            //When solderis on table depth obejcts is nopt null.
                            if (AStarGreedy[i].SolderesOnTable[m] != null)
                            {
                                //Found of Maximum on Depth solders on table items.
                                if (AStarGreedy[i].SolderesOnTable[m].SoldierThinking[0].MaxHuristic(ref jIndex, 1, ref Less))
                                {
                                    iIndex = i;
                                    mIndex = m;
                                    Kin = 1;
                                    Huristic = Less;
                                }
                            }

                        }
                        //For All Elephant On Table Count.
                        for (int m = ElefantOnTableCount(ref AStarGreedy[i].ElephantOnTable, true); m < ElefantOnTableCount(ref AStarGreedy[i].ElephantOnTable, false); m++)
                        {
                            //For All Elephant in Depth Count.
                            if (AStarGreedy[i].ElephantOnTable[m] != null)
                            {
                                //Found of Maxmimum in Branch.
                                if (AStarGreedy[i].ElephantOnTable[m].ElefantThinking[0].MaxHuristic(ref jIndex, 2, ref Less))
                                {
                                    iIndex = i;
                                    mIndex = m;
                                    Kin = 2;
                                    Huristic = Less;
                                }
                            }

                        }
                        //For All Hourse on Table Count.
                        for (int m = HourseOnTableCount(ref AStarGreedy[i].HoursesOnTable, true); m < HourseOnTableCount(ref AStarGreedy[i].HoursesOnTable, false); m++)
                        {
                            //When is HourseOn Table Depth Object is Not NULL.
                            if (AStarGreedy[i].HoursesOnTable[m] != null)
                            {
                                //Forund of Maximum on on Branch.
                                if (AStarGreedy[i].HoursesOnTable[m].HourseThinking[0].MaxHuristic(ref jIndex, 3, ref Less))
                                {
                                    iIndex = i;
                                    mIndex = m;
                                    Kin = 3;
                                    Huristic = Less;
                                }
                            }

                        }
                        //For All Bridges on table Count.
                        for (int m = BridgeOnTableCount(ref AStarGreedy[i].BridgesOnTable, true); m < BridgeOnTableCount(ref AStarGreedy[i].BridgesOnTable, false); m++)
                        {
                            //When Depth Objects of Hourse Table is Not NULL.
                            if (AStarGreedy[i].BridgesOnTable[m] != null)
                            {
                                //Found of Maximum Bridges Branch.
                                if (AStarGreedy[i].BridgesOnTable[m].BridgeThinking[0].MaxHuristic(ref jIndex, 4, ref Less))
                                {
                                    iIndex = i;
                                    mIndex = m;
                                    Kin = 4;
                                    Huristic = Less;
                                }
                            }

                        }
                        //For All Minsiter on table count.
                        for (int m = MinisterOnTableCount(ref AStarGreedy[i].MinisterOnTable, true); m < MinisterOnTableCount(ref AStarGreedy[i].MinisterOnTable, false); m++)
                        {
                            //When Minster of Depth is Not Null.
                            if (AStarGreedy[i].MinisterOnTable[m] != null)
                            {
                                //Found of Maximum Minster on table Branches.
                                if (AStarGreedy[i].MinisterOnTable[m].MinisterThinking[0].MaxHuristic(ref jIndex, 5, ref Less))
                                {
                                    iIndex = i;
                                    mIndex = m;
                                    Kin = 5;
                                    Huristic = Less;
                                }
                            }

                        }
                        //For All King on table Count.
                        for (int m = KingOnTableCount(ref AStarGreedy[i].KingOnTable, true); m < KingOnTableCount(ref AStarGreedy[i].KingOnTable, false); m++)
                        {
                            //When Minster of Depth is Not Null.
                            if (AStarGreedy[i].KingOnTable[m] != null)
                            {
                                //When Depth Object of King Table is Not NULL.
                                if (AStarGreedy[i].KingOnTable[m].KingThinking[0].MaxHuristic(ref jIndex, 1, ref Less))
                                {
                                    iIndex = i;
                                    mIndex = m;
                                    Kin = 6;
                                    Huristic = Less;
                                }
                            }

                        }
                    }

                }
                //Calculate Huristic of Current Node.
                //When Sodleris Kind.
                if (System.Math.Abs(Kind) == 1)
                {
                    Huristic += HuristicListSolder[j][0] +
                        HuristicListSolder[j][1] +
                        HuristicListSolder[j][2] +
                        HuristicListSolder[j][3] +
                        HuristicListSolder[j][4] +
                        HuristicListSolder[j][5] +
                        HuristicListSolder[j][6] +
                        HuristicListSolder[j][7];
                }
                else
                    //When Elephant Kind.
                    if (System.Math.Abs(Kind) == 2)
                    {
                        Huristic += HuristicListElefant[j][0] +
                            HuristicListElefant[j][1] +
                            HuristicListElefant[j][2] +
                            HuristicListElefant[j][3] +
                            HuristicListElefant[j][4] +
                            HuristicListElefant[j][5] +
                            HuristicListElefant[j][6];

                    }
                    else
                        //When Hourse Kind.
                        if (System.Math.Abs(Kind) == 3)
                        {
                            Huristic += HuristicListHourse[j][0] +
                                HuristicListHourse[j][1] +
                                HuristicListHourse[j][2] +
                                HuristicListHourse[j][3] +
                                HuristicListHourse[j][4] +
                                HuristicListHourse[j][5] +
                                HuristicListHourse[j][6];
                        }
                        else
                            //When Bridges Kind.
                            if (System.Math.Abs(Kind) == 4)
                            {
                                Huristic += HuristicListBridge[j][0] +
                                    HuristicListBridge[j][1] +
                                    HuristicListBridge[j][2] +
                                    HuristicListBridge[j][3] +
                                    HuristicListBridge[j][4] +
                                    HuristicListBridge[j][5] +
                                    HuristicListBridge[j][6];
                            }
                            else
                                //When Minister Kind.
                                if (System.Math.Abs(Kind) == 5)
                                {
                                    Huristic += HuristicListMinister[j][0] +
                                        HuristicListMinister[j][1] +
                                        HuristicListMinister[j][2] +
                                        HuristicListMinister[j][3] +
                                        HuristicListMinister[j][4] +
                                        HuristicListMinister[j][5] +
                                        HuristicListMinister[j][6];
                                }
                                else
                                    //When King Kind.
                                    if (System.Math.Abs(Kind) == 6)
                                    {
                                        Huristic += HuristicListKing[j][0] +
                                            HuristicListKing[j][1] +
                                            HuristicListKing[j][2] +
                                            HuristicListKing[j][3] +
                                            HuristicListKing[j][4] +
                                            HuristicListKing[j][5] +
                                            HuristicListKing[j][6];
                                    }
            }
            else
            {
                //When Solder Kind.
                if (System.Math.Abs(Kind) == 1)
                {
                    Huristic += HuristicListSolder[j][0] +
                        HuristicListSolder[j][1] +
                        HuristicListSolder[j][2] +
                        HuristicListSolder[j][3];
                }
                else
                    //When Elephant Kind.
                    if (System.Math.Abs(Kind) == 2)
                    {
                        Huristic += HuristicListElefant[j][0] +
                            HuristicListElefant[j][1] +
                            HuristicListElefant[j][2] +
                            HuristicListElefant[j][3];
                    }
                    else
                        //When Hourse Kind.
                        if (System.Math.Abs(Kind) == 3)
                        {
                            Huristic += HuristicListHourse[j][0] +
                                HuristicListHourse[j][1] +
                                HuristicListHourse[j][2] +
                                HuristicListHourse[j][3];
                        }
                        else
                            //When Bridges Kind.
                            if (System.Math.Abs(Kind) == 4)
                            {
                                Huristic += HuristicListBridge[j][0] +
                                    HuristicListBridge[j][1] +
                                    HuristicListBridge[j][2] +
                                    HuristicListBridge[j][3];
                            }
                            else
                                //When Minstre Kind.
                                if (System.Math.Abs(Kind) == 5)
                                {
                                    Huristic += HuristicListMinister[j][0] +
                                        HuristicListMinister[j][1] +
                                        HuristicListMinister[j][2] +
                                        HuristicListMinister[j][3];
                                }
                                else
                                    //When King Kind.
                                    if (System.Math.Abs(Kind) == 6)
                                    {
                                        Huristic += HuristicListKing[j][0] +
                                            HuristicListKing[j][1] +
                                            HuristicListKing[j][2] +
                                            HuristicListKing[j][3];
                                    }

            }
            //When Kimnd Found.
            if (Kin != -1)
            {
                //Reapeate for Solders.
                if (Kin == 1)
                    Huristic += AStarGreedy[iIndex].SolderesOnTable[jIndex].SoldierThinking[0].ReturnHuristicCalculartor(iAstarGready, ii, j, Order * -1);
                else
                    //Repeate for Elephant.
                    if (Kin == 2)
                        Huristic += AStarGreedy[iIndex].ElephantOnTable[jIndex].ElefantThinking[0].ReturnHuristicCalculartor(iAstarGready, ii, j, Order * -1);
                    else
                        //Repeate for Hourse.
                        if (Kin == 3)
                            Huristic += AStarGreedy[iIndex].HoursesOnTable[jIndex].HourseThinking[0].ReturnHuristicCalculartor(iAstarGready, ii, j, Order * -1);
                        else
                            //Repeate for Bridges.
                            if (Kin == 4)
                                Huristic += AStarGreedy[iIndex].BridgesOnTable[jIndex].BridgeThinking[0].ReturnHuristicCalculartor(iAstarGready, ii, j, Order * -1);
                            else
                                //Repeate for Minstre.
                                if (Kin == 5)
                                    Huristic += AStarGreedy[iIndex].MinisterOnTable[jIndex].MinisterThinking[0].ReturnHuristicCalculartor(iAstarGready, ii, j, Order * -1);
                                else
                                    //Repeate for King.
                                    if (Kin == 6)
                                        Huristic += AStarGreedy[iIndex].KingOnTable[jIndex].KingThinking[0].ReturnHuristicCalculartor(iAstarGready, ii, j, Order * -1);

            }
            Order = DummyOrder;
            return Huristic;
        }
        //Returrn of Hurestic Tree.QC_Ok.
        //Scope of Every Objects Movments.QC-OK
        bool Scop(int i, int j, int ii, int jj, int Kind)
        {
            bool Validity = false;
            if (Kind == 1)//Sodier
            {
                if (System.Math.Abs(i - ii) <= 2 && System.Math.Abs(j - jj) <= 2)
                    Validity = true;
            }
            else
                if (Kind == 2)//Elephant
                {
                    if (System.Math.Abs(i - ii) == System.Math.Abs(j - jj))

                        Validity = true;
                }
                else
                    if (Kind == 3)
                    {
                        if (System.Math.Abs(i - ii) <= 2 && System.Math.Abs(j - jj) <= 2)
                            Validity = true;
                    }
                    else
                        if (Kind == 4)
                        {
                            if ((i == ii && j != jj) || (i != ii && j == jj))
                                Validity = true;
                        }
                        else
                            if (Kind == 5)
                            {
                                if (((i == ii && j != jj) || (i != ii && j == jj)) || System.Math.Abs(i - ii) == System.Math.Abs(j - jj))
                                    Validity = true;
                            }
                            else
                                if (Kind == 6)
                                {
                                    if (System.Math.Abs(i - ii) <= 1 && System.Math.Abs(j - jj) <= 1)
                                        Validity = true;
                                }
            return Validity;
        }
        //when current movments is suitable for movments return true.

        //Determine when current movment is suitable and is not dangrous return false.QC-OK
        bool IsAllTraversalHomeIsDangerous(int[,] Table, int ii, int jj,
            int iii, int jjj,
            //int iiiO, int jjjO,
            int Order, Color a)
        {
            //setting false.
            bool IsDangreous = false;
            int DummyOrder = Order;
            int DummyCurrentOrder = ChessRules.CurrentOrder;
            int COr = Order;

            //Clone a Table.
            int[,] Tab = new int[8, 8];
            for (int ik = 0; ik < 8; ik++)
                for (int jk = 0; jk < 8; jk++)
                    Tab[ik, jk] = Table[ik, jk];

            if (Order == 1)
                a = Color.Gray;
            else
                a = Color.Brown;

            //For Self Objects.
            //int iiii = ii, jjjj = jj;
            for (int iiii = 0; iiii < 8; iiii++)
                for (int jjjj = 0; jjjj < 8; jjjj++)
                {
                    if (Order == 1 & Tab[iiii, jjjj] <= 0)
                        continue;
                    if (Order == -1 & Tab[iiii, jjjj] >= 0)
                        continue;

                    //Create Chess Rules Objects.
                    ChessRules A = new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, Tab[iiii, jjjj], Tab, Order, iiii, jjjj);
                    //When Objects dangoure.
                    if (A.ObjectDangourKingMove(Order, Tab, false))
                    {
                        //When Objects Dangoure Gray.
                        if (Order == 1 && A.CheckGrayObjectDangour)
                        {
                            IsDangreous = true;
                            return true;
                        }
                        //When Objects Brown Dangoure.
                        if (Order == -1 && A.CheckBrownObjectDangour)
                        {
                            IsDangreous = true;
                            return true;
                        }
                    }
                }
            Order = DummyOrder;
            ChessRules.CurrentOrder = DummyCurrentOrder;
            return IsDangreous;
        }

        void KingThinkingChess(int DummyOrder, int DummyCurrentOrder, int[,] TableS, int ii, int jj, QuantumAtamata Current, bool DoEnemySelf, bool PenRegStrore, bool EnemyCheckMateAction, int i, int j, bool Bridge, ChessRules AAA)
        {
            Order = DummyOrder;
            ChessRules.CurrentOrder = DummyCurrentOrder;
            ///When There is Movments.
            if ((new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, TableS[ii, jj], TableS, Order, ii, jj)).Rules(ii, jj, i, j, color, TableS[ii, jj]))
            {
                KingValue = ObjectValueCalculator(TableS, Order, ii, jj);
                //Ignore of Kings Moving until kish or bridges occured.
                /*if (Order == 1 && (!KingMaovableGray))
                    return;
                else
                    if (Order == -1 && (!KingMaovableBrown))
                        return;
                 */ 
                ///Calculate Hit Occured and Value of Object.
                bool Hit = false;
                int HitNumber = TableS[i, j];
                if (System.Math.Abs(TableS[i, j]) > 0)
                    Hit = true;
                ///Add Table to List of Private.
                HitNumberKing.Add(TableS[i, j]);
                ThinkingRun = true;
                ///Predict Huristic.
                //if (Order == FormRefrigtz.OrderPlate)
                {
                    CalculateHuristics(TableS, ii, jj, color);
                    NumbersOfAllNode++;
                }
                bool IsSuitbale = new bool();
                bool IsGardNotMovable = new bool();
                bool IsNextMovemntIsCheckOrCheckMateForCurrent = new bool();
                bool IsDangerous = new bool();
                bool CanHittingAnUnSupportedEnemy = new bool();
                bool InDangrousUnSupported = new bool();

                ///Calculate Huristic and Add to List Speciifically and Cal Syntax.
                ///Action of Movements.
                InAttackedُSelfNotSupporetd(TableS, Order, color, ii, jj);
                InAttackedNotSelfSupportedBefore = InAttackedNotSelfSupported;
                SelfSupportedBefore = SelfSupported;
                TableS[i, j] = TableS[ii, jj];
                TableS[ii, jj] = 0;
                if (PenRegStrore && UsePenaltyRegardMechnisamT && PenaltyRegardListKing.Count == TableListKing.Count //+ 1)
                    )
                {
                    //Mechanisam of Regrad.  
                    CalculateLearningVars(TableS, i, j, ii, jj, ref IsSuitbale, ref IsNextMovemntIsCheckOrCheckMateForCurrent, ref  IsDangerous, ref CanHittingAnUnSupportedEnemy, ref InDangrousUnSupported);
                }

                //KingValue = 10 * (VeryFye(TableS, Order, color) + 1);
                int RowB = 0, ColumnB = 0;
                int RowG = 0, ColumnG = 0;
                AAA.FindBrownKing(TableS, ref RowB, ref ColumnB);
                AAA.FindGrayKing(TableS, ref RowG, ref ColumnG);
                bool ConvergenceofTowKMing = false;
                //Gray Order.
                //Illegal King Foundation.
                if (System.Math.Abs(RowB - RowG) <= 1 && System.Math.Abs(ColumnB - ColumnG) <= 1)
                {
                    NumberOfPenalties++;
                    Current.LearningAlgorithmPenalty();
                    PenaltyRegardListKing.Add(Current);
                    ConvergenceofTowKMing = true;
                }

                ///Consideration of Itterative Movments to ignore.
                if (ExistTableInList(TableS, TableListKing, 0))
                {
                    ///Set Predict Huristic and Movments Backward.
                    TableS[ii, jj] = TableS[i, j];
                    TableS[i, j] = 0;
                    HuristicAttackValue = 0;
                    HuristicMovementValue = 0;
                    HuristicSelfSupportedValue = 0;
                    HuristicObjectDangourCheckMateValue = 0;

                    return;
                }
                //Consideration of Prevention from going Check State by self order.
                ChessRules AA = new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, TableS[ii, jj], TableS, Order, Row, Column);
                if (!UsePenaltyRegardMechnisamT)
                    if (AA.Check(TableS, Order))
                    {
                        if (Order == 1 && AA.CheckGray)
                            return;
                        else
                            if (Order == -1 && AA.CheckBrown)
                                return;
                    }
                if (IgnoreObjectDangour == 0)
                    IgnoreObjectDangour = 1;
                if (AA.CheckMate(TableS, Order))
                {

                    if (Order == 1 && AA.CheckMateBrown)
                    {
                        DoEnemySelf = false;
                        FoundFirstMating++; SelfCheckMateAction = false; EnemyCheckMateAction = true;
                    }
                    if (Order == -1 && AA.CheckMateGray)
                    {
                        DoEnemySelf = false;
                        FoundFirstMating++; SelfCheckMateAction = false; EnemyCheckMateAction = true;
                    }
                    if (Order == 1 && AA.CheckMateGray)
                    {
                        SelfCheckMateAction = true; EnemyCheckMateAction = false;
                    }
                    if (Order == -1 && AA.CheckMateBrown)
                    {
                        SelfCheckMateAction = true; EnemyCheckMateAction = false;
                    }
                }
                if (AA.ObjectDangourKingMove(Order, TableS, false))
                {

                    if (Order == 1 && AA.CheckGrayObjectDangour)
                    {
                        DoEnemySelf = false;

                        AchamazCurrent = true;
                    }
                    if (Order == -1 && AA.CheckBrownObjectDangour)
                    {
                        DoEnemySelf = false;

                        AchamazCurrent = true;
                    }
                }
                ///Operation of Penalty Regard Mechanisam on Check and mate speciffically.
                if (Current.IsPenaltyAction() != 0 && UsePenaltyRegardMechnisamT && PenaltyRegardListKing.Count == TableListKing.Count + 1 && !ConvergenceofTowKMing)
                {

                    ChessRules A = new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, TableS[ii, jj], TableS, Order, Row, Column);
                    if (A.Check(TableS, Order))
                    {
                        if (Order == 1 && (A.CheckGray))
                        {
                            NumberOfPenalties++;
                            Current.LearningAlgorithmPenalty();
                        }
                        else
                            if (Order == -1 && (A.CheckBrown))
                            {
                                NumberOfPenalties++;
                                Current.LearningAlgorithmPenalty();
                            }
                        PenaltyRegardListKing.Add(Current);
                    }
                    else
                    {
                        if (IsCurrentStateIsDangreousForCurrentOrder(TableS, Order, color, i, j) && DoEnemySelf)
                        {
                            NumberOfPenalties++;
                            Current.LearningAlgorithmPenalty();
                            PenaltyRegardListKing.Add(Current);
                        }
                        else
                            PenaltyRegardListKing.Add(Current);
                    }

                }

                ///Store of Indexes Changes and Table in specific List.
                int[] AS = new int[2];
                AS[0] = i;
                AS[1] = j;
                RowColumnKing.Add(AS);
                RowColumn[Index, 0] = i;
                RowColumn[Index, 1] = j;
                Index++;
                TableListKing.Add(CloneATable(TableS)); ;
                IndexKing++;
                KingValue = ObjectValueCalculator(TableS, Order, i, j);
                //Calculate Movment Huristic After Movments.
                //if (Order == FormRefrigtz.OrderPlate)
                {
                    CalculateHuristics(TableS, i, j, color);
                }

                if (PenRegStrore && UsePenaltyRegardMechnisamT && PenaltyRegardListKing.Count == TableListKing.Count)
                {
                    //For Not Suppored In Attacked.
                    if (InDangrousUnSupported// || IsGardNotMovable || IsNextMovemntIsCheckOrCheckMateForCurrent
                        )
                    {
                        if (Current.IsPenaltyAction() != 0)
                        {
                            //DontClearPenalty = true;
                            NumberOfPenalties++;
                            PenaltyRegardListKing.RemoveAt(PenaltyRegardListKing.Count - 1);
                            Current.LearningAlgorithmPenalty();
                            PenaltyRegardListKing.Add(Current);
                        }
                    }
                    //For Ocuuring in Enemy CheckMate.
                    if (EnemyCheckMateAction && SelfSupported && (!InAttackedNotSelfSupported) && Current.IsPenaltyAction() != 0)
                    {
                        if (Current.IsPenaltyAction() != 0)
                        {
                            PenaltyRegardListKing.RemoveAt(PenaltyRegardListKing.Count - 1);
                            Current.LearningAlgorithmRegard();
                            PenaltyRegardListKing.Add(Current);
                        }
                    }
                    //For Preventing of Self CheckMate.
                    if (SelfCheckMateAction)
                    {
                        if (Current.IsPenaltyAction() != 0)
                        {
                            PenaltyRegardListKing.RemoveAt(PenaltyRegardListKing.Count - 1);
                            Current.LearningAlgorithmRegard();
                            PenaltyRegardListKing.Add(Current);
                        }
                    }
                    //For Ocuuring Enemy Garding Objects.
                    if (CanHittingAnUnSupportedEnemy && IsSuitbale && EnemyNotSupported && InAttackedNotEnemySupported && SelfSupported && (!InAttackedNotSelfSupported))
                    {
                        if (Current.IsPenaltyAction() != 0)
                        {
                            PenaltyRegardListKing.RemoveAt(PenaltyRegardListKing.Count - 1);
                            Current.LearningAlgorithmRegard();
                            PenaltyRegardListKing.Add(Current);
                            //IgnoreAchmatPenalty = true;
                        }
                    }
                    bool IgnoreRemove = false;
                    if (AA.CheckGray && Order == 1)
                        IgnoreRemove = true;
                    else
                        if (AA.CheckBrown && Order == -1)
                            IgnoreRemove = true;

                    if (Current.IsPenaltyAction() == 0) if (RemovePenalty(TableS, Order, i, j))
                        {
                            Current = new QuantumAtamata(3, 3, 3);
                            PenaltyRegardListKing.RemoveAt(PenaltyRegardListKing.Count - 1);
                            PenaltyRegardListKing.Add(Current);
                        }

                }
                else
                    PenaltyRegardListKing.Add(Current);///Calculate Huristic and Add to List Speciifically and Cal Syntax.
                double[] Hu = new double[7];
                Hu[0] = HuristicAttackValue;
                Hu[1] = HuristicMovementValue;
                Hu[2] = HuristicSelfSupportedValue;
                Hu[3] = HuristicObjectDangourCheckMateValue;
                Hu[4] = HuristicHittingValue;
                Hu[5] = HuristicReducedAttackValue;
                Hu[6] = HuristicObjectDangourCheckMateValue;
                HuristicListKing.Add(Hu);

            }
        }
        void MinisterThinkingChess(int DummyOrder, int DummyCurrentOrder, int[,] TableS, int ii, int jj, QuantumAtamata Current, bool DoEnemySelf, bool PenRegStrore, bool EnemyCheckMateAction, int i, int j, bool Bridge)
        {
            Order = DummyOrder;
            ChessRules.CurrentOrder = DummyCurrentOrder;
            ///When There is Movments.
            if ((new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, TableS[ii, jj], TableS, Order, ii, jj)).Rules(ii, jj, i, j, color, TableS[ii, jj]))
            {
                MinisterValue = ObjectValueCalculator(TableS, Order, ii, jj);
                ///Calculate Hit Occured and Value of Object.
                bool Hit = false;
                int HitNumber = TableS[i, j];
                if (System.Math.Abs(TableS[i, j]) > 0)
                    Hit = true;
                ///Add Table to List of Private.
                HitNumberMinister.Add(TableS[i, j]);
                ThinkingRun = true;
                ///Predict Huristic.
                //if (Order == FormRefrigtz.OrderPlate)
                {
                    CalculateHuristics(TableS, ii, jj, color);
                    NumbersOfAllNode++;
                }
                bool IsSuitbale = new bool();
                bool IsGardNotMovable = new bool();
                bool IsNextMovemntIsCheckOrCheckMateForCurrent = new bool();
                bool IsDangerous = new bool();
                bool CanHittingAnUnSupportedEnemy = new bool();
                bool InDangrousUnSupported = new bool();

                InAttackedُSelfNotSupporetd(TableS, Order, color, ii, jj);
                InAttackedNotSelfSupportedBefore = InAttackedNotSelfSupported;
                SelfSupportedBefore = SelfSupported;
                TableS[i, j] = TableS[ii, jj];
                TableS[ii, jj] = 0;
                if (PenRegStrore && UsePenaltyRegardMechnisamT && PenaltyRegardListMinister.Count == TableListMinister.Count //+ 1)
                    )
                {
                    //Mechanisam of Regrad.     
                    CalculateLearningVars(TableS, i, j, ii, jj, ref IsSuitbale, ref IsNextMovemntIsCheckOrCheckMateForCurrent, ref  IsDangerous, ref CanHittingAnUnSupportedEnemy, ref InDangrousUnSupported);
                }
                //Consideration of Prevention from going Check State by self order.
                ChessRules AA = new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, TableS[ii, jj], TableS, Order, Row, Column);
                if (!UsePenaltyRegardMechnisamT)
                    if (AA.Check(TableS, Order))
                    {
                        if (Order == 1 && AA.CheckGray)
                            return;

                        else if (Order == -1 && AA.CheckBrown)
                            return;
                    }
                if (IgnoreObjectDangour == 0)
                    IgnoreObjectDangour = 1;
                ///Consideration of Itterative Movments to ignore.
                if (ExistTableInList(TableS, TableListMinister, 0))
                {
                    ///Set Predict Huristic and Movments Backward.
                    TableS[ii, jj] = TableS[i, j];
                    TableS[i, j] = 0;
                    HuristicAttackValue = 0;
                    HuristicMovementValue = 0;
                    HuristicSelfSupportedValue = 0;
                    HuristicObjectDangourCheckMateValue = 0;

                    return;
                }
                ///Operation of Penalty Regard Mechanisam on Check and mate speciffically.
                if (Current.IsPenaltyAction() != 0 && UsePenaltyRegardMechnisamT && PenaltyRegardListMinister.Count == TableListMinister.Count //+ 1)
                    )
                {
                    // PenaltyRegardListMinister.RemoveAt(PenaltyRegardListMinister.Count - 1);
                    ChessRules A = new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, TableS[ii, jj], TableS, Order, Row, Column);
                    if (A.Check(TableS, Order))
                    {
                        if (Order == 1 && (A.CheckGray))
                        {
                            NumberOfPenalties++;
                            Current.LearningAlgorithmPenalty();
                        }
                        else
                            if (Order == -1 && (A.CheckBrown))
                            {
                                NumberOfPenalties++;
                                Current.LearningAlgorithmPenalty();
                            }
                        PenaltyRegardListMinister.Add(Current);
                    }
                    else
                    {
                        if (IsCurrentStateIsDangreousForCurrentOrder(TableS, Order, color, i, j) && DoEnemySelf)
                        {
                            NumberOfPenalties++;
                            Current.LearningAlgorithmPenalty();
                            PenaltyRegardListMinister.Add(Current);
                        }
                        else
                            PenaltyRegardListMinister.Add(Current);
                    }

                }
                if (AA.CheckMate(TableS, Order))
                {

                    if (Order == 1 && AA.CheckMateBrown)
                    {
                        DoEnemySelf = false;
                        FoundFirstMating++; SelfCheckMateAction = false; EnemyCheckMateAction = true;
                    }
                    if (Order == -1 && AA.CheckMateGray)
                    {
                        DoEnemySelf = false;
                        FoundFirstMating++; SelfCheckMateAction = false; EnemyCheckMateAction = true;
                    }
                    if (Order == 1 && AA.CheckMateGray)
                    {
                        SelfCheckMateAction = true; EnemyCheckMateAction = false;
                    }
                    if (Order == -1 && AA.CheckMateBrown)
                    {
                        SelfCheckMateAction = true; EnemyCheckMateAction = false;
                    }
                }
                if (AA.ObjectDangourKingMove(Order, TableS, false))
                {

                    if (Order == 1 && AA.CheckGrayObjectDangour)
                    {
                        DoEnemySelf = false;

                        AchamazCurrent = true;
                    }
                    if (Order == -1 && AA.CheckBrownObjectDangour)
                    {
                        DoEnemySelf = false;

                        AchamazCurrent = true;
                    }
                }
                ///Store of Indexes Changes and Table in specific List.
                int[] AS = new int[2];
                AS[0] = i;
                AS[1] = j;
                RowColumnMinister.Add(AS);
                RowColumn[Index, 0] = i;
                RowColumn[Index, 1] = j;
                Index++;
                TableListMinister.Add(CloneATable(TableS)); ;
                IndexMinister++;
                MinisterValue = ObjectValueCalculator(TableS, Order, i, j);
                ///Wehn Predict of Operation Do operate a Predict of this movments.
                //if (Order == FormRefrigtz.OrderPlate)
                {
                    CalculateHuristics(TableS, i, j, color);
                }

                if (PenRegStrore && UsePenaltyRegardMechnisamT && PenaltyRegardListMinister.Count == TableListMinister.Count)
                {
                    //For Not Suppored In Attacked.
                    if (InDangrousUnSupported// || IsGardNotMovable || IsNextMovemntIsCheckOrCheckMateForCurrent
                        )
                    {
                        //if (InAttackedNotSelfSupported || IsDangerous || IsGardNotMovable || !ExistingOfEnemyHiiting || IsNextMovemntIsCheckOrCheckMateForCurrent || SupporterVar1 > SupporterVar2 || AttacakerVar1 > AttacakerVar2 && EnemyVarAttacker1 < EnemyVarAttacker2)
                        {
                            if (Current.IsPenaltyAction() != 0)
                            {
                                NumberOfPenalties++;
                                PenaltyRegardListMinister.RemoveAt(PenaltyRegardListMinister.Count - 1);
                                Current.LearningAlgorithmPenalty();
                                PenaltyRegardListMinister.Add(Current);
                            }
                        }
                    }
                    //For Ocuuring Enemy Garding Objects.
                    if (CanHittingAnUnSupportedEnemy && IsSuitbale && EnemyNotSupported && InAttackedNotEnemySupported && SelfSupported && (!InAttackedNotSelfSupported))
                    {
                        //if ((InAttackedNotEnemySupported || IsSuitbale || IsGard) && !IsDangerous)
                        {
                            if (Current.IsPenaltyAction() != 0)
                            {
                                PenaltyRegardListMinister.RemoveAt(PenaltyRegardListMinister.Count - 1);
                                Current.LearningAlgorithmRegard();
                                PenaltyRegardListMinister.Add(Current);
                            }
                        }
                    }
                    //For Preventing of Self CheckMate.
                    if (SelfCheckMateAction)
                    {
                        if (Current.IsPenaltyAction() != 0)
                        {
                            NumberOfPenalties++;
                            PenaltyRegardListMinister.RemoveAt(PenaltyRegardListMinister.Count - 1);
                            Current.LearningAlgorithmPenalty();
                            PenaltyRegardListMinister.Add(Current);
                        }
                    }
                    //For Ocuuring in Enemy CheckMate.7
                    if (EnemyCheckMateAction && SelfSupported && (!InAttackedNotSelfSupported) && Current.IsPenaltyAction() != 0)
                    {
                        if (Current.IsPenaltyAction() != 0)
                        {
                            PenaltyRegardListMinister.RemoveAt(PenaltyRegardListMinister.Count - 1);
                            Current.LearningAlgorithmRegard();
                            PenaltyRegardListMinister.Add(Current);
                            //ignoreAchmatPenalty = true;
                        }
                    }
                    bool IgnoreRemove = false;
                    if (AA.CheckGray && Order == 1)
                        IgnoreRemove = true;
                    else
                        if (AA.CheckBrown && Order == -1)
                            IgnoreRemove = true;

                    if (Current.IsPenaltyAction() == 0) if (RemovePenalty(TableS, Order, i, j))
                        {
                            Current = new QuantumAtamata(3, 3, 3);
                            PenaltyRegardListMinister.RemoveAt(PenaltyRegardListMinister.Count - 1);
                            PenaltyRegardListMinister.Add(Current);
                        }
                }
                else
                    PenaltyRegardListMinister.Add(Current);
                ///Calculate Huristic and Add to List Speciifically and Cal Syntax.
                double[] Hu = new double[7];
                Hu[0] = HuristicAttackValue;
                Hu[1] = HuristicMovementValue;
                Hu[2] = HuristicSelfSupportedValue;
                Hu[3] = HuristicObjectDangourCheckMateValue;
                Hu[4] = HuristicHittingValue;
                Hu[5] = HuristicReducedAttackValue;
                Hu[6] = HuristicObjectDangourCheckMateValue;
                HuristicListMinister.Add(Hu);

            }
        }
        void CalculateLearningVars(int[,] TableS, int i, int j, int ii, int jj, ref bool IsSuitbale, ref bool IsNextMovemntIsCheckOrCheckMateForCurrent, ref bool IsDangerous, ref bool CanHittingAnUnSupportedEnemy, ref bool InDangrousUnSupported)
        {
            BeforeAttacker = false;
            IsSuitbale = IsEnenmyInGardForCurrentMovmentsIsSuitable(TableS, Order, color, i, j);
            IsNextMovemntIsCheckOrCheckMateForCurrent = IsNextMovmentIsCheckOrCheckMateForCurrentMovment(TableS, Order, color, i, j);
            InAttackedEnemyNotSupporetd(TableS, Order, color, i, j, ii, jj);
            InAttackedُSelfNotSupporetd(TableS, Order, color, i, j);
            IsDangerous = IsAllTraversalHomeIsDangerous(TableS, i, j, ii, jj, Order, color);
            CanHittingAnUnSupportedEnemy = InAttackedNotEnemySupported;
            //if (!CanHittingAnUnSupportedEnemy)
            InDangrousUnSupported = (IsDangerous || InAttackedNotSelfSupported) && (!CanHittingAnUnSupportedEnemy);
            //else
            //   InDangrousUnSupported = false;
        }
        void BridgesThinkingChess(int DummyOrder, int DummyCurrentOrder, int[,] TableS, int ii, int jj, QuantumAtamata Current, bool DoEnemySelf, bool PenRegStrore, bool EnemyCheckMateAction, int i, int j, bool Bridge)
        {
            Order = DummyOrder;
            ChessRules.CurrentOrder = DummyCurrentOrder;
            ///When There is Movments.
            if ((new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, TableS[ii, jj], TableS, Order, ii, jj)).Rules(ii, jj, i, j, color, TableS[ii, jj]))
            {
                BridgeValue = ObjectValueCalculator(TableS, Order, ii, jj);
                ///Calculate Hit Occured and Value of Object.

                bool Hit = false;
                int HitNumber = TableS[i, j];
                if (System.Math.Abs(TableS[i, j]) > 0)
                    Hit = true;
                ///Add Table to List of Private.
                HitNumberBridge.Add(TableS[i, j]);
                ThinkingRun = true;
                ///Predict Huristic.
                //if (Order == FormRefrigtz.OrderPlate)
                {
                    CalculateHuristics(TableS, ii, jj, color);
                    NumbersOfAllNode++;
                }
                bool IsSuitbale = new bool();
                bool IsGardNotMovable = new bool();
                bool IsNextMovemntIsCheckOrCheckMateForCurrent = new bool();
                bool IsDangerous = new bool();
                bool CanHittingAnUnSupportedEnemy = new bool();
                bool InDangrousUnSupported = new bool();

                InAttackedُSelfNotSupporetd(TableS, Order, color, ii, jj);
                InAttackedNotSelfSupportedBefore = InAttackedNotSelfSupported;
                SelfSupportedBefore = SelfSupported;
                TableS[i, j] = TableS[ii, jj];
                TableS[ii, jj] = 0;
                if (PenRegStrore && UsePenaltyRegardMechnisamT && PenaltyRegardListBridge.Count == TableListBridge.Count //+ 1)
                    )
                {
                    //Mechanisam of Regrad.   
                    CalculateLearningVars(TableS, i, j, ii, jj, ref IsSuitbale, ref IsNextMovemntIsCheckOrCheckMateForCurrent, ref  IsDangerous, ref CanHittingAnUnSupportedEnemy, ref InDangrousUnSupported);
                }
                ChessRules AA = new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, TableS[ii, jj], TableS, Order, Row, Column);
                if (!UsePenaltyRegardMechnisamT)
                    if (AA.Check(TableS, Order))
                    {
                        if (Order == 1 && AA.CheckGray)
                            return;
                        else
                            if (Order == -1 && AA.CheckBrown)
                                return;
                    }
                if (IgnoreObjectDangour == 0)
                    IgnoreObjectDangour = 1;

                if (AA.CheckMate(TableS, Order))
                {

                    if (Order == 1 && AA.CheckMateBrown)
                    {
                        DoEnemySelf = false;
                        FoundFirstMating++; SelfCheckMateAction = false; EnemyCheckMateAction = true;
                    }
                    if (Order == -1 && AA.CheckMateGray)
                    {
                        DoEnemySelf = false;
                        FoundFirstMating++; SelfCheckMateAction = false; EnemyCheckMateAction = true;
                    }
                    if (Order == 1 && AA.CheckMateGray)
                    {
                        SelfCheckMateAction = true; EnemyCheckMateAction = false;
                    }
                    if (Order == -1 && AA.CheckMateBrown)
                    {
                        SelfCheckMateAction = true; EnemyCheckMateAction = false;
                    }
                }
                if (AA.ObjectDangourKingMove(Order, TableS, false))
                {

                    if (Order == 1 && AA.CheckGrayObjectDangour)
                    {
                        DoEnemySelf = false;

                        AchamazCurrent = true;
                    }
                    if (Order == -1 && AA.CheckBrownObjectDangour)
                    {
                        DoEnemySelf = false;

                        AchamazCurrent = true;
                    }
                }
                ///Consideration of Itterative Movments to ignore.
                if (ExistTableInList(TableS, TableListBridge, 0))
                {
                    ///Set Predict Huristic and Movments Backward.
                    TableS[ii, jj] = TableS[i, j];
                    TableS[i, j] = 0;
                    HuristicAttackValue = 0;
                    HuristicMovementValue = 0;
                    HuristicSelfSupportedValue = 0;
                    HuristicObjectDangourCheckMateValue = 0;

                    return;
                }
                ///Operation of Penalty Regard Mechanisam on Check and mate speciffically.
                if (Current.IsPenaltyAction() != 0 && UsePenaltyRegardMechnisamT && PenaltyRegardListBridge.Count == TableListBridge.Count //+ 1)
                    )
                {
                    //PenaltyRegardListBridge.RemoveAt(PenaltyRegardListBridge.Count - 1);
                    ChessRules A = new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, TableS[ii, jj], TableS, Order, Row, Column);
                    if (A.Check(TableS, Order))
                    {
                        if (Order == 1 && (A.CheckGray))
                        {
                            NumberOfPenalties++;
                            Current.LearningAlgorithmPenalty();
                        }
                        else
                            if (Order == -1 && (A.CheckBrown))
                            {
                                NumberOfPenalties++;
                                Current.LearningAlgorithmPenalty();
                            }
                        PenaltyRegardListBridge.Add(Current);
                    }
                    else
                    {
                        if (IsCurrentStateIsDangreousForCurrentOrder(TableS, Order, color, i, j) && DoEnemySelf)
                        {
                            NumberOfPenalties++;
                            Current.LearningAlgorithmPenalty();
                            PenaltyRegardListBridge.Add(Current);
                        }
                        else
                            PenaltyRegardListBridge.Add(Current);
                    }

                }
                ///Store of Indexes Changes and Table in specific List.
                int[] AS = new int[2];
                AS[0] = i;
                AS[1] = j;
                RowColumnBridge.Add(AS);
                RowColumn[Index, 0] = i;
                RowColumn[Index, 1] = j;
                Index++;
                TableListBridge.Add(CloneATable(TableS)); ;
                IndexBridge++;
                BridgeValue = ObjectValueCalculator(TableS, Order, i, j);
                //if (Order == FormRefrigtz.OrderPlate)
                {
                    CalculateHuristics(TableS, i, j, color);
                }

                if (PenRegStrore && UsePenaltyRegardMechnisamT && PenaltyRegardListBridge.Count == TableListBridge.Count)
                {
                    //For Not Suppored In Attacked.
                    if (InDangrousUnSupported// || IsGardNotMovable || IsNextMovemntIsCheckOrCheckMateForCurrent
                        )
                    {
                        if (Current.IsPenaltyAction() != 0)
                        {
                            //DontClearPenalty = true;
                            NumberOfPenalties++;
                            PenaltyRegardListBridge.RemoveAt(PenaltyRegardListBridge.Count - 1);
                            Current.LearningAlgorithmPenalty();
                            PenaltyRegardListBridge.Add(Current);
                        }
                    }
                    //For Ocuuring Enemy Garding Objects.
                    if (CanHittingAnUnSupportedEnemy && IsSuitbale && EnemyNotSupported && InAttackedNotEnemySupported && SelfSupported && (!InAttackedNotSelfSupported))
                    {
                        //if ((InAttackedNotEnemySupported || IsSuitbale || IsGard) && !IsDangerous)
                        {
                            if (Current.IsPenaltyAction() != 0)
                            {
                                PenaltyRegardListBridge.RemoveAt(PenaltyRegardListBridge.Count - 1);
                                Current.LearningAlgorithmRegard();
                                PenaltyRegardListBridge.Add(Current);
                                //IgnoreAchmatPenalty = true;
                            }
                        }
                    }
                    //For Preventing of Self CheckMate.
                    if (SelfCheckMateAction)
                    {
                        if (Current.IsPenaltyAction() != 0)
                        {
                            //DontClearPenalty = true;
                            NumberOfPenalties++;
                            PenaltyRegardListBridge.RemoveAt(PenaltyRegardListBridge.Count - 1);
                            Current.LearningAlgorithmPenalty();
                            PenaltyRegardListBridge.Add(Current);
                        }
                    }
                    //For Ocuuring in Enemy CheckMate.
                    if (EnemyCheckMateAction && SelfSupported && (!InAttackedNotSelfSupported) && Current.IsPenaltyAction() != 0)
                    {
                        if (Current.IsPenaltyAction() != 0)
                        {
                            PenaltyRegardListBridge.RemoveAt(PenaltyRegardListBridge.Count - 1);
                            Current.LearningAlgorithmRegard();
                            PenaltyRegardListBridge.Add(Current);
                            //IgnoreAchmatPenalty = true;
                        }
                    }
                    bool IgnoreRemove = false;
                    if (AA.CheckGray && Order == 1)
                        IgnoreRemove = true;
                    else
                        if (AA.CheckBrown && Order == -1)
                            IgnoreRemove = true;

                    if (Current.IsPenaltyAction() == 0) if (RemovePenalty(TableS, Order, i, j))
                        {
                            Current = new QuantumAtamata(3, 3, 3);
                            PenaltyRegardListBridge.RemoveAt(PenaltyRegardListBridge.Count - 1);
                            PenaltyRegardListBridge.Add(Current);
                        }

                }
                else
                    PenaltyRegardListBridge.Add(Current);
                ///Calculate Huristic and Add to List Speciifically and Cal Syntax.
                double[] Hu = new double[7];
                Hu[0] = HuristicAttackValue;
                Hu[1] = HuristicMovementValue;
                Hu[2] = HuristicSelfSupportedValue;
                Hu[3] = HuristicObjectDangourCheckMateValue;
                Hu[4] = HuristicHittingValue;
                Hu[5] = HuristicReducedAttackValue;
                Hu[6] = HuristicObjectDangourCheckMateValue;
                HuristicListBridge.Add(Hu);

            }
        }
        void HourseThinkingChess(int DummyOrder, int DummyCurrentOrder, int[,] TableS, int ii, int jj, QuantumAtamata Current, bool DoEnemySelf, bool PenRegStrore, bool EnemyCheckMateAction, int i, int j, bool Bridge)
        {
            Order = DummyOrder;
            ChessRules.CurrentOrder = DummyCurrentOrder;
            ///When There is Movments.
            if ((new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, TableS[ii, jj], TableS, Order, ii, jj)).Rules(ii, jj, i, j, color, TableS[ii, jj]))
            {
                ///Calculate Hit Occured and Value of Object.
                HourseValue = ObjectValueCalculator(TableS, Order, ii, jj);
                bool Hit = false;
                int HitNumber = TableS[i, j];
                if (System.Math.Abs(TableS[i, j]) > 0)
                    Hit = true;
                ///Add Table to List of Private.
                HitNumberHourse.Add(TableS[i, j]);
                ThinkingRun = true;
                ///Predict Huristic.
                //if (Order == FormRefrigtz.OrderPlate)
                {
                    CalculateHuristics(TableS, ii, jj, color);
                    NumbersOfAllNode++;
                }
                bool IsSuitbale = new bool();
                bool IsGardNotMovable = new bool();
                bool IsNextMovemntIsCheckOrCheckMateForCurrent = new bool();
                bool IsDangerous = new bool();
                bool CanHittingAnUnSupportedEnemy = new bool();
                bool InDangrousUnSupported = new bool();

                InAttackedُSelfNotSupporetd(TableS, Order, color, ii, jj);
                InAttackedNotSelfSupportedBefore = InAttackedNotSelfSupported;
                SelfSupportedBefore = SelfSupported;
                TableS[i, j] = TableS[ii, jj];
                TableS[ii, jj] = 0;
                if (PenRegStrore && UsePenaltyRegardMechnisamT && PenaltyRegardListHourse.Count == TableListHourse.Count //+ 1)
                    )
                {
                    //Mechanisam of Regrad. 
                    CalculateLearningVars(TableS, i, j, ii, jj, ref IsSuitbale, ref IsNextMovemntIsCheckOrCheckMateForCurrent, ref  IsDangerous, ref CanHittingAnUnSupportedEnemy, ref InDangrousUnSupported);
                }
                ChessRules AA = new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, TableS[ii, jj], TableS, Order, Row, Column);
                if (!UsePenaltyRegardMechnisamT)
                    if (AA.Check(TableS, Order))
                    {
                        if (Order == 1 && AA.CheckGray)
                            return;
                        else if (Order == -1 && AA.CheckBrown)
                            return;

                    }
                if (IgnoreObjectDangour == 0)
                    IgnoreObjectDangour = 1;

                if (AA.CheckMate(TableS, Order))
                {

                    if (Order == 1 && AA.CheckMateBrown)
                    {
                        DoEnemySelf = false;
                        FoundFirstMating++; SelfCheckMateAction = false; EnemyCheckMateAction = true;
                    }
                    if (Order == -1 && AA.CheckMateGray)
                    {
                        DoEnemySelf = false;
                        FoundFirstMating++; SelfCheckMateAction = false; EnemyCheckMateAction = true;
                    }
                    if (Order == 1 && AA.CheckMateGray)
                    {
                        SelfCheckMateAction = true; EnemyCheckMateAction = false;
                    }
                    if (Order == -1 && AA.CheckMateBrown)
                    {
                        SelfCheckMateAction = true; EnemyCheckMateAction = false;
                    }
                }
                if (AA.ObjectDangourKingMove(Order, TableS, false))
                {

                    if (Order == 1 && AA.CheckGrayObjectDangour)
                    {
                        DoEnemySelf = false;

                        AchamazCurrent = true;
                    }
                    if (Order == -1 && AA.CheckBrownObjectDangour)
                    {
                        DoEnemySelf = false;

                        AchamazCurrent = true;
                    }
                }
                ///Consideration of Itterative Movments to ignore.
                if (ExistTableInList(TableS, TableListHourse, 0))
                {
                    ///Set Predict Huristic and Movments Backward.
                    TableS[ii, jj] = TableS[i, j];
                    TableS[i, j] = 0;
                    HuristicAttackValue = 0;
                    HuristicMovementValue = 0;
                    HuristicSelfSupportedValue = 0;
                    HuristicObjectDangourCheckMateValue = 0;

                    return;
                }
                ///Operation of Penalty Regard Mechanisam on Check and mate speciffically.
                if (Current.IsPenaltyAction() != 0 && UsePenaltyRegardMechnisamT && PenaltyRegardListHourse.Count == TableListHourse.Count //+ 1)
                    )
                {
                    //PenaltyRegardListHourse.RemoveAt(PenaltyRegardListHourse.Count - 1);
                    ChessRules A = new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, TableS[ii, jj], TableS, Order, Row, Column);
                    if (A.Check(TableS, Order))
                    {
                        if (Order == 1 && (A.CheckGray))
                        {
                            NumberOfPenalties++;
                            Current.LearningAlgorithmPenalty();
                        }
                        else
                            if (Order == -1 && (A.CheckBrown))
                            {
                                NumberOfPenalties++;
                                Current.LearningAlgorithmPenalty();
                            }
                        PenaltyRegardListHourse.Add(Current);
                    }
                    else
                    {
                        if (IsCurrentStateIsDangreousForCurrentOrder(TableS, Order, color, i, j) && DoEnemySelf)
                        {
                            NumberOfPenalties++;
                            Current.LearningAlgorithmPenalty();
                            PenaltyRegardListHourse.Add(Current);
                        }
                        else
                            PenaltyRegardListHourse.Add(Current);
                    }
                }
                ///Store of Indexes Changes and Table in specific List.
                int[] AS = new int[2];
                AS[0] = i;
                AS[1] = j;
                RowColumnHourse.Add(AS);

                RowColumn[Index, 0] = i;
                RowColumn[Index, 1] = j;
                Index++;
                TableListHourse.Add(CloneATable(TableS)); ;
                IndexHourse++;
                HourseValue = ObjectValueCalculator(TableS, Order, i, j);
                ///Wehn Predict of Operation Do operate a Predict of this movments.
                //if (Order == FormRefrigtz.OrderPlate)
                {
                    CalculateHuristics(TableS, i, j, color);
                }


                if (PenRegStrore && UsePenaltyRegardMechnisamT && PenaltyRegardListHourse.Count == TableListHourse.Count)
                {
                    //For Not Suppored In Attacked.
                    if (InDangrousUnSupported// || IsGardNotMovable || IsNextMovemntIsCheckOrCheckMateForCurrent
                        )
                    {
                        if (Current.IsPenaltyAction() != 0)
                        {
                            //DontClearPenalty = true;
                            NumberOfPenalties++;
                            PenaltyRegardListHourse.RemoveAt(PenaltyRegardListHourse.Count - 1);
                            Current.LearningAlgorithmPenalty();
                            PenaltyRegardListHourse.Add(Current);
                        }
                    }
                    //For Ocuuring Enemy Garding Objects.
                    if (CanHittingAnUnSupportedEnemy && IsSuitbale && EnemyNotSupported && InAttackedNotEnemySupported && SelfSupported && (!InAttackedNotSelfSupported))
                    {
                        if (Current.IsPenaltyAction() != 0)
                        {
                            PenaltyRegardListHourse.RemoveAt(PenaltyRegardListHourse.Count - 1);
                            Current.LearningAlgorithmRegard();
                            PenaltyRegardListHourse.Add(Current);
                            //IgnoreAchmatPenalty = true;
                        }
                    }
                    //For Preventing of Self CheckMate.
                    if (SelfCheckMateAction)
                    {
                        if (Current.IsPenaltyAction() != 0)
                        {
                            //DontClearPenalty = true;
                            NumberOfPenalties++;
                            PenaltyRegardListHourse.RemoveAt(PenaltyRegardListHourse.Count - 1);
                            Current.LearningAlgorithmPenalty();
                            PenaltyRegardListHourse.Add(Current);
                        }
                    }
                    //For Ocuuring in Enemy CheckMate.
                    if (EnemyCheckMateAction && SelfSupported && (!InAttackedNotSelfSupported) && Current.IsPenaltyAction() != 0)
                    {
                        if (Current.IsPenaltyAction() != 0)
                        {
                            PenaltyRegardListHourse.RemoveAt(PenaltyRegardListHourse.Count - 1);
                            Current.LearningAlgorithmRegard();
                            PenaltyRegardListHourse.Add(Current);
                            //IgnoreAchmatPenalty = true;
                        }
                    }

                    bool IgnoreRemove = false;
                    if (AA.CheckGray && Order == 1)
                        IgnoreRemove = true;
                    else
                        if (AA.CheckBrown && Order == -1)
                            IgnoreRemove = true;

                    if (Current.IsPenaltyAction() == 0) if (RemovePenalty(TableS, Order, i, j))
                        {
                            Current = new QuantumAtamata(3, 3, 3);
                            PenaltyRegardListHourse.RemoveAt(PenaltyRegardListHourse.Count - 1);
                            PenaltyRegardListHourse.Add(Current);
                        }

                }
                else
                    PenaltyRegardListHourse.Add(Current);
                //Calculate Huristic and Add to List and Cal Syntax.
                double[] Hu = new double[7];
                Hu[0] = HuristicAttackValue;
                Hu[1] = HuristicMovementValue;
                Hu[2] = HuristicSelfSupportedValue;
                Hu[3] = HuristicObjectDangourCheckMateValue;
                Hu[4] = HuristicHittingValue;
                Hu[5] = HuristicReducedAttackValue;
                Hu[6] = HuristicObjectDangourCheckMateValue;
                HuristicListHourse.Add(Hu);

            }
        }
        void ElephantThinkingChess(int DummyOrder, int DummyCurrentOrder, int[,] TableS, int ii, int jj, QuantumAtamata Current, bool DoEnemySelf, bool PenRegStrore, bool EnemyCheckMateAction, int i, int j, bool Bridge)
        {
            Order = DummyOrder;
            ChessRules.CurrentOrder = DummyCurrentOrder;
            ///When There is Movments.
            if ((new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, TableS[ii, jj], TableS, Order, ii, jj)).Rules(ii, jj, i, j, color, TableS[ii, jj]))
            {
                ElefantValue = ObjectValueCalculator(TableS, Order, ii, jj);

                ///Calculate Hit Occured and Value of Object.
                bool Hit = false;
                int HitNumber = TableS[i, j];
                if (System.Math.Abs(TableS[i, j]) > 0)
                    Hit = true;
                ///Add Table to List of Private.
                HitNumberElefant.Add(TableS[i, j]);
                ThinkingRun = true;
                ///Predict Huristic.
                //if (Order == FormRefrigtz.OrderPlate)
                {
                    CalculateHuristics(TableS, i, j, color);
                }
                bool IsSuitbale = new bool();
                bool IsGardNotMovable = new bool();
                bool IsNextMovemntIsCheckOrCheckMateForCurrent = new bool();
                bool IsDangerous = new bool();
                bool CanHittingAnUnSupportedEnemy = new bool();
                bool InDangrousUnSupported = new bool();

                InAttackedُSelfNotSupporetd(TableS, Order, color, ii, jj);
                InAttackedNotSelfSupportedBefore = InAttackedNotSelfSupported;
                SelfSupportedBefore = SelfSupported;
                TableS[i, j] = TableS[ii, jj];
                TableS[ii, jj] = 0;
                if (PenRegStrore && UsePenaltyRegardMechnisamT && PenaltyRegardListElefant.Count == TableListElefant.Count //+ 1)
                    )
                {
                    //Mechanisam of Regrad. 
                    CalculateLearningVars(TableS, i, j, ii, jj, ref IsSuitbale, ref IsNextMovemntIsCheckOrCheckMateForCurrent, ref  IsDangerous, ref CanHittingAnUnSupportedEnemy, ref InDangrousUnSupported);
                }
                ChessRules AA = new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, TableS[ii, jj], TableS, Order, Row, Column);
                if (!UsePenaltyRegardMechnisamT)
                    if (AA.Check(TableS, Order))
                    {
                        if (Order == 1 && AA.CheckGray)
                            return;
                        else
                            if (Order == -1 && AA.CheckBrown)
                                return;
                    }
                if (IgnoreObjectDangour == 0)
                    IgnoreObjectDangour = 1;

                if (AA.CheckMate(TableS, Order))
                {

                    if (Order == 1 && AA.CheckMateBrown)
                    {
                        DoEnemySelf = false;
                        FoundFirstMating++; SelfCheckMateAction = false; EnemyCheckMateAction = true;
                    }
                    if (Order == -1 && AA.CheckMateGray)
                    {
                        DoEnemySelf = false;
                        FoundFirstMating++; SelfCheckMateAction = false; EnemyCheckMateAction = true;
                    }
                    if (Order == 1 && AA.CheckMateGray)
                    {
                        SelfCheckMateAction = true; EnemyCheckMateAction = false;
                    }
                    if (Order == -1 && AA.CheckMateBrown)
                    {
                        SelfCheckMateAction = true; EnemyCheckMateAction = false;
                    }
                }
                if (AA.ObjectDangourKingMove(Order, TableS, false))
                {

                    if (Order == 1 && AA.CheckGrayObjectDangour)
                    {
                        DoEnemySelf = false;

                        AchamazCurrent = true;
                    }
                    if (Order == -1 && AA.CheckBrownObjectDangour)
                    {
                        DoEnemySelf = false;

                        AchamazCurrent = true;
                    }
                }
                ///Consideration of Itterative Movments to ignore.
                if (ExistTableInList(TableS, TableListElefant, 0))
                {
                    ///Set Predict Huris0tic and Movments Backward.0
                    TableS[ii, jj] = TableS[i, j];
                    TableS[i, j] = 0;
                    HuristicAttackValue = 0;
                    HuristicMovementValue = 0;
                    HuristicSelfSupportedValue = 0;
                    HuristicObjectDangourCheckMateValue = 0;

                    return;
                }
                ///Operation of Penalty Regard Mechanisam on Check and mate speciffically.
                if (Current.IsPenaltyAction() != 0 && UsePenaltyRegardMechnisamT && PenaltyRegardListElefant.Count == TableListElefant.Count //+ 1)
                    )
                {
                    ChessRules A = new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, TableS[ii, jj], TableS, Order, Row, Column);
                    if (A.Check(TableS, Order))
                    {
                        if (Order == 1 && (A.CheckGray))
                        {
                            NumberOfPenalties++;
                            Current.LearningAlgorithmPenalty();
                        }
                        else
                            if (Order == -1 && (A.CheckBrown))
                            {
                                NumberOfPenalties++;
                                Current.LearningAlgorithmPenalty();
                            }
                        PenaltyRegardListElefant.Add(Current);
                    }
                    else
                    {
                        if (IsCurrentStateIsDangreousForCurrentOrder(TableS, Order, color, i, j) && DoEnemySelf)
                        {
                            NumberOfPenalties++;
                            Current.LearningAlgorithmPenalty();
                            PenaltyRegardListElefant.Add(Current);
                        }
                        else
                            PenaltyRegardListElefant.Add(Current);
                    }
                }
                ///Store of Indexes Changes and Table in specific List.
                int[] AS = new int[2];
                AS[0] = i;
                AS[1] = j;
                RowColumnElefant.Add(AS);

                RowColumn[Index, 0] = i;
                RowColumn[Index, 1] = j;
                Index++;
                TableListElefant.Add(CloneATable(TableS)); ;
                IndexElefant++;
                ElefantValue = ObjectValueCalculator(TableS, Order, i, j);
                //Wehn Predict of Operation Do operate a Predict of this movments.
                //if (         PredictHuristicT)
                {
                    //if (Order == FormRefrigtz.OrderPlate)
                    {
                        CalculateHuristics(TableS, i, j, color);
                    }
                }

                if (PenRegStrore && UsePenaltyRegardMechnisamT && PenaltyRegardListElefant.Count == TableListElefant.Count)
                {
                    //For Not Suppored In Attacked.
                    if (InDangrousUnSupported// || IsGardNotMovable || IsNextMovemntIsCheckOrCheckMateForCurrent
                        )
                    {
                        {
                            if (Current.IsPenaltyAction() != 0)
                            {
                                //DontClearPenalty = true;
                                NumberOfPenalties++;
                                PenaltyRegardListElefant.RemoveAt(PenaltyRegardListElefant.Count - 1);
                                Current.LearningAlgorithmPenalty();
                                PenaltyRegardListElefant.Add(Current);
                            }
                        }
                    }
                    //For Ocuuring Enemy Garding Objects.
                    if (CanHittingAnUnSupportedEnemy && IsSuitbale && EnemyNotSupported && InAttackedNotEnemySupported && SelfSupported && (!InAttackedNotSelfSupported))
                    {
                        //if ((InAttackedNotEnemySupported || IsSuitbale || IsGard) && !IsDangerous)
                        {
                            if (Current.IsPenaltyAction() != 0)
                            {

                                PenaltyRegardListElefant.RemoveAt(PenaltyRegardListElefant.Count - 1);
                                Current.LearningAlgorithmRegard();
                                PenaltyRegardListElefant.Add(Current);
                            }
                        }
                    }
                    //For Preventing of Self CheckMate.
                    if (SelfCheckMateAction)
                    {
                        if (Current.IsPenaltyAction() != 0)
                        {
                            NumberOfPenalties++;
                            PenaltyRegardListElefant.RemoveAt(PenaltyRegardListElefant.Count - 1);
                            Current.LearningAlgorithmPenalty();
                            PenaltyRegardListElefant.Add(Current);
                        }
                    }
                    //For Ocuuring in Enemy CheckMate.
                    if (EnemyCheckMateAction && SelfSupported && (!InAttackedNotSelfSupported) && Current.IsPenaltyAction() != 0)
                    {
                        if (Current.IsPenaltyAction() != 0)
                        {
                            PenaltyRegardListElefant.RemoveAt(PenaltyRegardListElefant.Count - 1);
                            Current.LearningAlgorithmRegard();
                            PenaltyRegardListElefant.Add(Current);
                        }
                    }
                    bool IgnoreRemove = false;
                    if (AA.CheckGray && Order == 1)
                        IgnoreRemove = true;
                    else
                        if (AA.CheckBrown && Order == -1)
                            IgnoreRemove = true;

                    if (Current.IsPenaltyAction() == 0) if (RemovePenalty(TableS, Order, i, j))
                        {
                            Current = new QuantumAtamata(3, 3, 3);
                            PenaltyRegardListElefant.RemoveAt(PenaltyRegardListElefant.Count - 1);
                            PenaltyRegardListElefant.Add(Current);
                        }

                    ///Calculate Huristic and Add to List Speciifically and Cal Syntax.
                }
                else
                    PenaltyRegardListElefant.Add(Current);
                double[] Hu = new double[7];
                Hu[0] = HuristicAttackValue;
                Hu[1] = HuristicMovementValue;
                Hu[2] = HuristicSelfSupportedValue;
                Hu[3] = HuristicObjectDangourCheckMateValue;
                Hu[4] = HuristicHittingValue;
                Hu[5] = HuristicReducedAttackValue;
                Hu[6] = HuristicObjectDangourCheckMateValue;
                HuristicListElefant.Add(Hu);

            }
        }
        void SolderThinkingChess(int DummyOrder, int DummyCurrentOrder, int[,] TableS, int ii, int jj, QuantumAtamata Current, bool DoEnemySelf, bool PenRegStrore, bool EnemyCheckMateAction, int i, int j, bool Bridge)
        {
            Order = DummyOrder;
            ChessRules.CurrentOrder = DummyCurrentOrder;
            ///When There is Movments.
            if ((new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, TableS[ii, jj], TableS, Order, ii, jj)).Rules(ii, jj, i, j, color, TableS[ii, jj]))
            {
                //int EnemyVarAttacker1 = EnemyAttackerCount(TableS, Order, color, ii, jj);
                //int AttacakerVar1 = AttackerCount(TableS, Order, color, ii, jj);
                //int SupporterVar1 = SupporterCount(TableS, Order, color, ii, jj);
                SodierValue = ObjectValueCalculator(TableS, Order, ii, jj);
                ///Calculate Hit Occured and Value of Object.
                bool Hit = false;
                int HitNumber = TableS[i, j];
                if (System.Math.Abs(TableS[i, j]) > 0)
                    Hit = true;
                ///Add Table to List of Private.
                HitNumberSoldier.Add(TableS[i, j]);
                ThinkingRun = true;
                ///Predict Huristic.
                //if (Order == FormRefrigtz.OrderPlate)
                {
                    CalculateHuristics(TableS, ii, jj, color);
                    NumbersOfAllNode++;
                }
                bool IsSuitbale = new bool();
                bool IsGardNotMovable = new bool();
                bool IsNextMovemntIsCheckOrCheckMateForCurrent = new bool();
                bool IsDangerous = new bool();
                bool CanHittingAnUnSupportedEnemy = new bool();
                bool InDangrousUnSupported = new bool();


                ///Action of Movements.
                InAttackedُSelfNotSupporetd(TableS, Order, color, ii, jj);
                InAttackedNotSelfSupportedBefore = InAttackedNotSelfSupported;
                SelfSupportedBefore = SelfSupported;
                TableS[i, j] = TableS[ii, jj];
                TableS[ii, jj] = 0;
                if (PenRegStrore && UsePenaltyRegardMechnisamT && PenaltyRegardListSolder.Count == TableListSolder.Count //+ 1)
                    )
                {
                    //Mechanisam of Regrad.  
                    CalculateLearningVars(TableS, i, j, ii, jj, ref IsSuitbale, ref IsNextMovemntIsCheckOrCheckMateForCurrent, ref  IsDangerous, ref CanHittingAnUnSupportedEnemy, ref InDangrousUnSupported);
                }
                ChessRules AA = new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, TableS[ii, jj], TableS, Order, Row, Column);
                if (!UsePenaltyRegardMechnisamT)
                    if (AA.Check(TableS, Order))
                    {
                        if (Order == 1 && AA.CheckGray)
                            return;
                        else
                            if (Order == -1 && AA.CheckBrown)
                                return;
                    }

                if (IgnoreObjectDangour == 0)
                    IgnoreObjectDangour = 1;

                if (AA.CheckMate(TableS, Order))
                {

                    if (Order == 1 && AA.CheckMateBrown)
                    {
                        DoEnemySelf = false;
                        FoundFirstMating++; SelfCheckMateAction = false; EnemyCheckMateAction = true;
                    }
                    if (Order == -1 && AA.CheckMateGray)
                    {
                        DoEnemySelf = false;
                        FoundFirstMating++; SelfCheckMateAction = false; EnemyCheckMateAction = true;
                    }
                    if (Order == 1 && AA.CheckMateGray)
                    {
                        SelfCheckMateAction = true; EnemyCheckMateAction = false;
                    }
                    if (Order == -1 && AA.CheckMateBrown)
                    {
                        SelfCheckMateAction = true; EnemyCheckMateAction = false;
                    }
                }
                if (AA.ObjectDangourKingMove(Order, TableS, false))
                {

                    if (Order == 1 && AA.CheckGrayObjectDangour)
                    {
                        DoEnemySelf = false;

                        AchamazCurrent = true;
                    }
                    if (Order == -1 && AA.CheckBrownObjectDangour)
                    {
                        DoEnemySelf = false;

                        AchamazCurrent = true;
                    }

                }
                ///Consideration of Itterative Movments to ignore.
                if (ExistTableInList(TableS, TableListSolder, 0))
                {
                    ///Set Predict Huristic and Movments Backward.
                    TableS[ii, jj] = TableS[i, j];
                    TableS[i, j] = 0;
                    HuristicAttackValue = 0;
                    HuristicMovementValue = 0;
                    HuristicSelfSupportedValue = 0;
                    HuristicObjectDangourCheckMateValue = 0;


                    return;
                }
                ///Operation of Penalty Regard Mechanisam on Check and mate speciffically.
                if (Current.IsPenaltyAction() != 0 && UsePenaltyRegardMechnisamT && PenaltyRegardListSolder.Count == TableListSolder.Count //+ 1)
                    )
                {
                    ChessRules A = new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, TableS[ii, jj], TableS, Order, Row, Column);
                    if (A.Check(TableS, Order))
                    {
                        if (Order == 1 && (A.CheckGray))
                        {
                            NumberOfPenalties++;
                            Current.LearningAlgorithmPenalty();
                        }
                        else
                            if (Order == -1 && (A.CheckBrown))
                            {
                                NumberOfPenalties++;
                                Current.LearningAlgorithmPenalty();
                            }
                        PenaltyRegardListSolder.Add(Current);
                    }
                    else
                    {
                        if (IsCurrentStateIsDangreousForCurrentOrder(TableS, Order, color, i, j) && DoEnemySelf)
                        {
                            NumberOfPenalties++;
                            Current.LearningAlgorithmPenalty();
                            PenaltyRegardListSolder.Add(Current);
                        }
                        else
                            PenaltyRegardListSolder.Add(Current);
                    }

                }
                ///Store of Indexes Changes and Table in specific List.
                int[] AS = new int[2];
                AS[0] = i;
                AS[1] = j;
                RowColumnSoldier.Add(AS);
                RowColumn[Index, 0] = i;
                RowColumn[Index, 1] = j;
                Index++;
                TableListSolder.Add(CloneATable(TableS)); ;
                IndexSoldier++;
                SodierValue = ObjectValueCalculator(TableS, Order, i, j);
                //Wehn Predict of Operation Do operate a Predict of this movments.
                //if (         PredictHuristicT)
                {
                    //if (Order == FormRefrigtz.OrderPlate)
                    {
                        CalculateHuristics(TableS, i, j, color);
                    }
                }

                if (PenRegStrore && UsePenaltyRegardMechnisamT && PenaltyRegardListSolder.Count == TableListSolder.Count)
                {
                    //For Not Suppored In Attacked.
                    if (InDangrousUnSupported// || IsGardNotMovable || IsNextMovemntIsCheckOrCheckMateForCurrent
                        )
                    {
                        {
                            if (Current.IsPenaltyAction() != 0)
                            {
                                NumberOfPenalties++;
                                PenaltyRegardListSolder.RemoveAt(PenaltyRegardListSolder.Count - 1);
                                Current.LearningAlgorithmPenalty();
                                PenaltyRegardListSolder.Add(Current);
                            }
                        }
                    }
                    //For Preventing of Self CheckMate.
                    if (SelfCheckMateAction)
                    {
                        if (Current.IsPenaltyAction() != 0)
                        {
                            NumberOfPenalties++;
                            PenaltyRegardListSolder.RemoveAt(PenaltyRegardListSolder.Count - 1);
                            Current.LearningAlgorithmPenalty();
                            PenaltyRegardListSolder.Add(Current);
                        }
                    }
                    //For Ocuuring in Enemy CheckMate.
                    if (EnemyCheckMateAction && SelfSupported && (!InAttackedNotSelfSupported) && Current.IsPenaltyAction() != 0)
                    {
                        if (Current.IsPenaltyAction() != 0)
                        {
                            PenaltyRegardListSolder.RemoveAt(PenaltyRegardListSolder.Count - 1);
                            Current.LearningAlgorithmRegard();
                            PenaltyRegardListSolder.Add(Current);
                        }
                    }
                    //For Ocuuring Enemy Garding Objects.
                    if (CanHittingAnUnSupportedEnemy && IsSuitbale && EnemyNotSupported && InAttackedNotEnemySupported && SelfSupported && (!InAttackedNotSelfSupported))
                    {
                        //if ((InAttackedNotEnemySupported || IsSuitbale || IsGard) && !IsDangerous)
                        {
                            if (Current.IsPenaltyAction() != 0)
                            {
                                PenaltyRegardListSolder.RemoveAt(PenaltyRegardListSolder.Count - 1);
                                Current.LearningAlgorithmRegard();
                                PenaltyRegardListSolder.Add(Current);
                            }
                        }
                    }
                    bool IgnoreRemove = false;
                    if (AA.CheckGray && Order == 1)
                        IgnoreRemove = true;
                    else
                        if (AA.CheckBrown && Order == -1)
                            IgnoreRemove = true;

                    if (Current.IsPenaltyAction() == 0) if (RemovePenalty(TableS, Order, i, j))
                        {
                            Current = new QuantumAtamata(3, 3, 3);
                            PenaltyRegardListSolder.RemoveAt(PenaltyRegardListSolder.Count - 1);
                            PenaltyRegardListSolder.Add(Current);
                        }

                }
                else
                    PenaltyRegardListSolder.Add(Current);
                ///Calculate Huristic and Add to List Speciifically and Cal Syntax.
                double[] Hu = new double[7];
                Hu[0] = HuristicAttackValue;
                Hu[1] = HuristicMovementValue;
                Hu[2] = HuristicSelfSupportedValue;
                Hu[3] = HuristicObjectDangourCheckMateValue;
                Hu[4] = HuristicHittingValue;
                Hu[5] = HuristicReducedAttackValue;
                Hu[6] = HuristicObjectDangourCheckMateValue;
                HuristicListSolder.Add(Hu);

            }
        }
        void BridgesKingThinkingBrown(int DummyOrder, int DummyCurrentOrder, int[,] TableS, int ii, int jj, QuantumAtamata Current, bool DoEnemySelf, bool PenRegStrore, bool EnemyCheckMateAction, int i, int j, bool Bridge)
        {
            Order = DummyOrder;
            ChessRules.CurrentOrder = DummyCurrentOrder;
            //When is Brown Bridges King.

            {

                //Calcuilate Huristic Before Movment.
                ThinkingRun = true;
                //if (Order == FormRefrigtz.OrderPlate)
                {
                    CalculateHuristics(TableS, ii, jj, color);
                    NumbersOfAllNode++;
                }
                bool IsSuitbale = new bool();
                bool IsGardNotMovable = new bool();
                bool IsNextMovemntIsCheckOrCheckMateForCurrent = new bool();
                bool IsDangerous = new bool();
                bool CanHittingAnUnSupportedEnemy = new bool();
                bool InDangrousUnSupported = new bool();


                //Act Movment.
                if (i < ii)
                {
                    TableS[ii - 1, j] = -4;
                    TableS[ii - 2, j] = -6;
                    TableS[ii, jj] = 0;
                    TableS[0, jj] = 0;

                }

                else
                {
                    TableS[ii + 1, j] = -4;
                    TableS[ii + 2, j] = -6;
                    TableS[ii, jj] = 0;
                    TableS[7, jj] = 0;

                }
                if (PenRegStrore && UsePenaltyRegardMechnisamT && PenaltyRegardListKing.Count == TableListKing.Count //+ 1)
                    )
                {
                    //Mechanisam of Regrad.      
                    CalculateLearningVars(TableS, i, j, ii, jj, ref IsSuitbale, ref IsNextMovemntIsCheckOrCheckMateForCurrent, ref  IsDangerous, ref CanHittingAnUnSupportedEnemy, ref InDangrousUnSupported);
                }
                //Consideration of Prevention from going Check State by self order.
                ChessRules AA = new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, TableS[ii, jj], TableS, Order, Row, Column);
                if (!UsePenaltyRegardMechnisamT)
                    if (AA.Check(TableS, Order))
                    {
                        if (Order == 1 && AA.CheckGray)
                            return;
                        else
                            if (Order == -1 && AA.CheckBrown)
                                return;

                    }
                if (IgnoreObjectDangour == 0)
                    IgnoreObjectDangour = 1;

                ///Operation of Penalty Regard Mechanisam on Check and mate speciffically.
                if (Current.IsPenaltyAction() != 0 && UsePenaltyRegardMechnisamT && PenaltyRegardListKing.Count == TableListKing.Count //+ 1)
                    )
                {
                    //PenaltyRegardListKing.RemoveAt(PenaltyRegardListKing.Count - 1);
                    ChessRules A = new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, TableS[ii, jj], TableS, Order, Row, Column);
                    if (A.Check(TableS, Order))
                    {
                        if (Order == 1 && (A.CheckGray))
                        {
                            NumberOfPenalties++;
                            Current.LearningAlgorithmPenalty();
                        }
                        else
                            if (Order == -1 && (A.CheckBrown))
                            {
                                NumberOfPenalties++;
                                Current.LearningAlgorithmPenalty();
                            }
                        PenaltyRegardListKing.Add(Current);
                    }
                    else
                    {
                        if (IsCurrentStateIsDangreousForCurrentOrder(TableS, Order, color, i, j) && DoEnemySelf)
                        {
                            NumberOfPenalties++;
                            Current.LearningAlgorithmPenalty();
                            PenaltyRegardListKing.Add(Current);
                        }
                        else
                            PenaltyRegardListKing.Add(Current);
                    }
                }
                if (AA.CheckMate(TableS, Order))
                {

                    if (Order == 1 && AA.CheckMateBrown)
                    {
                        DoEnemySelf = false;
                        FoundFirstMating++; SelfCheckMateAction = false; EnemyCheckMateAction = true;
                    }
                    if (Order == -1 && AA.CheckMateGray)
                    {
                        DoEnemySelf = false;
                        FoundFirstMating++; SelfCheckMateAction = false; EnemyCheckMateAction = true;
                    }
                    if (Order == 1 && AA.CheckMateGray)
                    {
                        SelfCheckMateAction = true; EnemyCheckMateAction = false;
                    }
                    if (Order == -1 && AA.CheckMateBrown)
                    {
                        SelfCheckMateAction = true; EnemyCheckMateAction = false;
                    }
                }
                if (AA.ObjectDangourKingMove(Order, TableS, false))
                {

                    if (Order == 1 && AA.CheckGrayObjectDangour)
                    {
                        DoEnemySelf = false;

                        AchamazCurrent = true;
                    }
                    if (Order == -1 && AA.CheckBrownObjectDangour)
                    {
                        DoEnemySelf = false;

                        AchamazCurrent = true;
                    }
                }

                //Store Movments Items. 
                int[] AS = new int[2];
                AS[0] = i;
                AS[1] = j;
                RowColumnKing.Add(AS);
                RowColumn[Index, 0] = i;
                RowColumn[Index, 1] = j;
                Index++;
                TableListKing.Add(CloneATable(TableS)); ;
                IndexKing++;
                if (PenRegStrore && UsePenaltyRegardMechnisamT && PenaltyRegardListKing.Count == TableListKing.Count)
                {
                    //Calculatre Huristic After Movments.
                    //if (         PredictHuristicT)
                    {
                        //if (Order == FormRefrigtz.OrderPlate)
                        {
                            CalculateHuristics(TableS, i, j, color);
                        }
                    }

                    //For Ocuuring in Enemy CheckMate.
                    if (EnemyCheckMateAction && SelfSupported && (!InAttackedNotSelfSupported) && Current.IsPenaltyAction() != 0)
                    {
                        if (Current.IsPenaltyAction() != 0)
                        {
                            PenaltyRegardListKing.RemoveAt(PenaltyRegardListKing.Count - 1);
                            Current.LearningAlgorithmRegard();
                            PenaltyRegardListKing.Add(Current);
                            //IgnoreAchmatPenalty = true;
                        }
                    }
                    //For Preventing of Self CheckMate.
                    if (SelfCheckMateAction)
                    {
                        if (Current.IsPenaltyAction() != 0)
                        {
                            //DontClearPenalty = true;
                            NumberOfPenalties++;
                            PenaltyRegardListKing.RemoveAt(PenaltyRegardListKing.Count - 1);
                            Current.LearningAlgorithmPenalty();
                            PenaltyRegardListKing.Add(Current);
                        }
                    }
                    if (PenRegStrore && UsePenaltyRegardMechnisamT && PenaltyRegardListKing.Count == TableListKing.Count)
                    {
                        //For Not Suppored In Attacked.
                        if (InDangrousUnSupported// || IsGardNotMovable || IsNextMovemntIsCheckOrCheckMateForCurrent
                            )
                        {
                            //if (InAttackedNotSelfSupported || IsDangerous || IsGardNotMovable || !ExistingOfEnemyHiiting || IsNextMovemntIsCheckOrCheckMateForCurrent || SupporterVar1 > SupporterVar2 || AttacakerVar1 > AttacakerVar2 && EnemyVarAttacker1 < EnemyVarAttacker2)
                            {
                                if (Current.IsPenaltyAction() != 0)
                                {
                                    //DontClearPenalty = true;
                                    NumberOfPenalties++;
                                    PenaltyRegardListKing.RemoveAt(PenaltyRegardListKing.Count - 1);
                                    Current.LearningAlgorithmPenalty();
                                    PenaltyRegardListKing.Add(Current);
                                }
                            }
                        }
                    }
                    //For Ocuuring Enemy  Garding Objects.
                    if (CanHittingAnUnSupportedEnemy && IsSuitbale && EnemyNotSupported && InAttackedNotEnemySupported && SelfSupported && (!InAttackedNotSelfSupported))
                    {
                        //if ((InAttackedNotEnemySupported || IsSuitbale || IsGard) && !IsDangerous)
                        {
                            if (Current.IsPenaltyAction() != 0)
                            {
                                PenaltyRegardListKing.RemoveAt(PenaltyRegardListKing.Count - 1);
                                Current.LearningAlgorithmRegard();
                                PenaltyRegardListKing.Add(Current);
                                //IgnoreAchmatPenalty = true;
                            }
                        }
                    }
                    bool IgnoreRemove = false;
                    if (AA.CheckGray && Order == 1)
                        IgnoreRemove = true;
                    else
                        if (AA.CheckBrown && Order == -1)
                            IgnoreRemove = true;

                    if (Current.IsPenaltyAction() == 0) if (RemovePenalty(TableS, Order, i, j))
                        {
                            Current = new QuantumAtamata(3, 3, 3);
                            PenaltyRegardListKing.RemoveAt(PenaltyRegardListKing.Count - 1);
                            PenaltyRegardListKing.Add(Current);
                        }

                }
                else
                    PenaltyRegardListKing.Add(Current);
                //Calculate Huristic Sumation and Store in Specific List.
                double[] Hu = new double[7];
                Hu[0] = HuristicAttackValue;
                Hu[1] = HuristicMovementValue;
                Hu[2] = HuristicSelfSupportedValue;
                Hu[3] = HuristicObjectDangourCheckMateValue;
                Hu[4] = HuristicHittingValue;
                Hu[5] = HuristicReducedAttackValue;
                Hu[6] = HuristicObjectDangourCheckMateValue;
                HuristicListKing.Add(Hu);
                //ChessRules.BridgeActBrown = true;
                Bridge = true;

            }
        }
        public void CalculateHuristics(int[,] TableSS, int i, int j, Color color)
        {
            double HA = HuristicAttack(TableSS, Order, color, i, j);
            double MA = HuristicMovment(TableSS, color, i, j);
            double SA = HuristicSelfSupported(TableSS, Order, color, i, j);
            double CA = HuristicCheckAndCheckMate(TableSS, color);
            double HiA = HuristicHitting(TableSS, i, j, Order, color, false);
            double RA = HuristicReducsedAttack(TableSS, Order, color, i, j);
            double DA = HeuristicDistabceOfCurrentMoveFromEnemyKing(TableSS, Order, i, j);
        }
        void BridgesKingThinkingGray(int DummyOrder, int DummyCurrentOrder, int[,] TableS, int ii, int jj, QuantumAtamata Current, bool DoEnemySelf, bool PenRegStrore, bool EnemyCheckMateAction, int i, int j, bool Bridge)
        {
            Order = DummyOrder;
            ChessRules.CurrentOrder = DummyCurrentOrder;
            //When is Bridges Gray King.

            {
                //Predict Huristic Caluculatio Before Movments.
                ThinkingRun = true;
                //if (Order == FormRefrigtz.OrderPlate)
                {

                    CalculateHuristics(TableS, ii, jj, color);
                    NumbersOfAllNode++;

                }
                bool IsSuitbale = new bool();
                bool IsGardNotMovable = new bool();
                bool IsNextMovemntIsCheckOrCheckMateForCurrent = new bool();
                bool IsDangerous = new bool();
                bool CanHittingAnUnSupportedEnemy = new bool();
                bool InDangrousUnSupported = new bool();

                //Act Movments.
                if (i < ii)
                {
                    TableS[ii - 1, j] = 4;
                    TableS[ii - 2, j] = 6;
                    TableS[ii, jj] = 0;
                    TableS[0, jj] = 0;

                }

                else
                {
                    TableS[ii + 1, j] = 4;
                    TableS[ii + 2, j] = 6;
                    TableS[ii, jj] = 0;
                    TableS[7, jj] = 0;

                }
                if (PenRegStrore && UsePenaltyRegardMechnisamT && PenaltyRegardListKing.Count == TableListKing.Count //+ 1)
                    )
                {
                    //Mechanisam of Regrad.
                    CalculateLearningVars(TableS, i, j, ii, jj, ref IsSuitbale, ref IsNextMovemntIsCheckOrCheckMateForCurrent, ref  IsDangerous, ref CanHittingAnUnSupportedEnemy, ref InDangrousUnSupported);

                }
                //Consideration of Prevention from going Check State by self order.

                ChessRules AA = new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, TableS[ii, jj], TableS, Order, Row, Column);
                if (!UsePenaltyRegardMechnisamT)
                    if (AA.Check(TableS, Order))
                    {
                        if (Order == 1 && AA.CheckGray)
                            return;
                        else
                            if (Order == -1 && AA.CheckBrown)
                                return;
                    }
                if (IgnoreObjectDangour == 0)
                    IgnoreObjectDangour = 1;

                ///Operation of Penalty Regard Mechanisam on Check and mate speciffically.
                if (Current.IsPenaltyAction() != 0 && UsePenaltyRegardMechnisamT && PenaltyRegardListKing.Count == TableListKing.Count //+ 1)
                    )
                {
                    //PenaltyRegardListKing.RemoveAt(PenaltyRegardListKing.Count - 1);
                    ChessRules A = new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, TableS[ii, jj], TableS, Order, Row, Column);
                    if (A.Check(TableS, Order))
                    {
                        if (Order == 1 && (A.CheckGray))
                        {
                            NumberOfPenalties++;
                            Current.LearningAlgorithmPenalty();
                        }
                        else
                            if (Order == -1 && (A.CheckBrown))
                            {
                                NumberOfPenalties++;
                                Current.LearningAlgorithmPenalty();
                            }


                        PenaltyRegardListKing.Add(Current);
                    }
                    else
                    {
                        if (IsCurrentStateIsDangreousForCurrentOrder(TableS, Order, color, i, j) && DoEnemySelf)
                        {
                            NumberOfPenalties++;
                            Current.LearningAlgorithmPenalty();
                            PenaltyRegardListKing.Add(Current);
                        }
                        else
                            PenaltyRegardListKing.Add(Current);
                    }
                }
                if (AA.CheckMate(TableS, Order))
                {

                    if (Order == 1 && AA.CheckMateBrown)
                    {
                        DoEnemySelf = false;
                        FoundFirstMating++; SelfCheckMateAction = false; EnemyCheckMateAction = true;
                    }
                    if (Order == -1 && AA.CheckMateGray)
                    {
                        DoEnemySelf = false;
                        FoundFirstMating++; SelfCheckMateAction = false; EnemyCheckMateAction = true;
                    }
                    if (Order == 1 && AA.CheckMateGray)
                    {
                        SelfCheckMateAction = true; EnemyCheckMateAction = false;
                    }
                    if (Order == -1 && AA.CheckMateBrown)
                    {
                        SelfCheckMateAction = true; EnemyCheckMateAction = false;
                    }
                }
                if (AA.ObjectDangourKingMove(Order, TableS, false))
                {

                    if (Order == 1 && AA.CheckGrayObjectDangour)
                    {
                        DoEnemySelf = false;

                        AchamazCurrent = true;
                    }
                    if (Order == -1 && AA.CheckBrownObjectDangour)
                    {
                        DoEnemySelf = false;

                        AchamazCurrent = true;
                    }
                }
                //Store Movments Items.
                int[] AS = new int[2];
                AS[0] = i;
                AS[1] = j;
                RowColumnKing.Add(AS);
                RowColumn[Index, 0] = i;
                RowColumn[Index, 1] = j;

                Index++;
                TableListKing.Add(CloneATable(TableS));
                IndexKing++;
                //InAttackedNotSelfSupported = false;
                //Calculate Movment Huristic After Movments.
                {
                    //if (Order == FormRefrigtz.OrderPlate)
                    {
                        CalculateHuristics(TableS, i, j, color);
                    }
                }

                if (PenRegStrore && UsePenaltyRegardMechnisamT && PenaltyRegardListKing.Count == TableListKing.Count)
                {

                    //For Not Suppored In Attacked.
                    if (InDangrousUnSupported// || IsGardNotMovable || IsNextMovemntIsCheckOrCheckMateForCurrent
                        )
                    {
                        //if (InAttackedNotSelfSupported || IsDangerous || IsGardNotMovable || !ExistingOfEnemyHiiting || IsNextMovemntIsCheckOrCheckMateForCurrent || SupporterVar1 > SupporterVar2 || AttacakerVar1 > AttacakerVar2 && EnemyVarAttacker1 < EnemyVarAttacker2)
                        {
                            if (Current.IsPenaltyAction() != 0)
                            {
                                NumberOfPenalties++;
                                //DontClearPenalty = true;
                                PenaltyRegardListKing.RemoveAt(PenaltyRegardListKing.Count - 1);
                                Current.LearningAlgorithmPenalty();
                                PenaltyRegardListKing.Add(Current);
                            }
                        }
                    }
                    //For Ocuuring in Enemy CheckMate.
                    if (EnemyCheckMateAction && SelfSupported && (!InAttackedNotSelfSupported) && Current.IsPenaltyAction() != 0)
                    {
                        if (Current.IsPenaltyAction() != 0)
                        {
                            PenaltyRegardListKing.RemoveAt(PenaltyRegardListKing.Count - 1);
                            Current.LearningAlgorithmRegard();
                            PenaltyRegardListKing.Add(Current);
                            //IgnoreAchmatPenalty = true;
                        }
                    }
                    //For Preventing of Self CheckMate.
                    if (SelfCheckMateAction)
                    {
                        if (Current.IsPenaltyAction() != 0)
                        {
                            //DontClearPenalty = true;
                            NumberOfPenalties++;
                            PenaltyRegardListKing.RemoveAt(PenaltyRegardListKing.Count - 1);
                            Current.LearningAlgorithmPenalty();
                            PenaltyRegardListKing.Add(Current);
                        }
                    }
                    //For Ocuuring Enemy Garding Objects.
                    if (CanHittingAnUnSupportedEnemy && IsSuitbale && EnemyNotSupported && InAttackedNotEnemySupported && SelfSupported && (!InAttackedNotSelfSupported))
                    {
                        //if ((InAttackedNotEnemySupported || IsSuitbale || IsGard) && !IsDangerous)
                        {
                            if (Current.IsPenaltyAction() != 0)
                            {

                                PenaltyRegardListKing.RemoveAt(PenaltyRegardListKing.Count - 1);
                                Current.LearningAlgorithmRegard();
                                PenaltyRegardListKing.Add(Current);
                                //IgnoreAchmatPenalty = true;
                            }
                        }
                    }
                    bool IgnoreRemove = false;
                    if (AA.CheckGray && Order == 1)
                        IgnoreRemove = true;
                    else
                        if (AA.CheckBrown && Order == -1)
                            IgnoreRemove = true;

                    if (Current.IsPenaltyAction() == 0) if (RemovePenalty(TableS, Order, i, j))
                        {
                            Current = new QuantumAtamata(3, 3, 3);
                            PenaltyRegardListKing.RemoveAt(PenaltyRegardListKing.Count - 1);
                            PenaltyRegardListKing.Add(Current);
                        }

                }
                else
                    PenaltyRegardListKing.Add(Current);//Calculate Huristic Sumaton and Stor Specificcaly.
                double[] Hu = new double[7];
                Hu[0] = HuristicAttackValue;
                Hu[1] = HuristicMovementValue;
                Hu[2] = HuristicSelfSupportedValue;
                Hu[3] = HuristicObjectDangourCheckMateValue;
                Hu[4] = HuristicHittingValue;
                Hu[5] = HuristicReducedAttackValue;
                Hu[6] = HuristicObjectDangourCheckMateValue;
                HuristicListKing.Add(Hu);
                //ChessRules.BridgeActGray = true;                                        
                Bridge = true;
            }


        }

        ///Kernel of Thinking
        public void Thinking()
        {
            int S = 0;
            while (!ThinkingBegin) { Thread.Sleep(100); }// S += 100; if (FormRefrigtz.Blitz) { if (S > ThresholdBlitz)break; } else { if (S > ThresholdFullGame)break; } }
            NumberOfPenalties = 0;
            SetObjectNumbers(TableConst);
            bool PenRegStrore = true;
            // if (Order != FormRefrigtz.OrderPlate)
            //  PenRegStrore = false;

            //Thread.Sleep(500);
            BeginThread++;
            if (CheckMateOcuured //|| FoundFirstMating > AllDraw.MaxAStarGreedy
                )
            {
                ThinkingFinished = true;
                EndThread++;
                //UsePenaltyRegardMechnisamT = PenRegStrore;
                return;
            }
            int DummyOrder = Order;
            int DummyCurrentOrder = ChessRules.CurrentOrder;
            //Initiate Locallly Global Variables. 
            TableListSolder.Clear();
            TableListElefant.Clear();
            TableListHourse.Clear();
            TableListBridge.Clear();
            TableListMinister.Clear();
            TableListKing.Clear();
            HuristicListBridge.Clear();
            HuristicListElefant.Clear();
            HuristicListHourse.Clear();
            HuristicListKing.Clear();
            HuristicListMinister.Clear();
            HuristicListSolder.Clear();
            RowColumnSoldier.Clear();
            RowColumnElefant.Clear();
            RowColumnHourse.Clear();
            RowColumnBridge.Clear();
            RowColumnMinister.Clear();
            RowColumnKing.Clear();
            HitNumberSoldier.Clear();
            HitNumberElefant.Clear();
            HitNumberHourse.Clear();
            HitNumberBridge.Clear();
            HitNumberMinister.Clear();
            HitNumberKing.Clear();
            PenaltyRegardListSolder.Clear();
            PenaltyRegardListMinister.Clear();
            PenaltyRegardListKing.Clear();
            PenaltyRegardListHourse.Clear();
            PenaltyRegardListElefant.Clear();
            PenaltyRegardListBridge.Clear();
            IndexSoldier = 0;
            IndexElefant = 0;
            IndexHourse = 0;
            IndexBridge = 0;
            IndexMinister = 0;
            IndexKing = 0;
            {
                ///For Stored Location of Objects.
                int ii = Row;
                int jj = Column;
                ///For Every Tables Home.
                for (int i = 0; i < 8; i++)
                {
                    for (int j = 0; j < 8; j++)
                    {
                        BeforeAttacker = true;
                        InAttackedNotSelfSupportedBefore = false;
                        SelfSupportedBefore = false;
                        if (CheckMateOcuured
                            //|| FoundFirstMating > AllDraw.MaxAStarGreedy
                            )
                        {
                            ThinkingFinished = true;
                            EndThread++;
                            return;
                        }
                        IgnoreObjectDangour = -1;
                        CurrentRow = i;
                        CurrentColumn = j;
                        SelfCheckMateAction = false;
                        AchamazCurrent = false;
                        ///Current is Ignored for Increased of Performance.
                        if (ii == i && jj == j)
                            continue;
                        HuristicAttackValue = new double();
                        HuristicMovementValue = new double();
                        HuristicSelfSupportedValue = new double();
                        HuristicObjectDangourCheckMateValue = new double();
                        HuristicHittingValue = new double();
                        HuristicReducedAttackValue = new double();
                        HeuristicDistabceOfCurrentMoveFromEnemyKingValue = new double();

                        ///Initiate a Local Variables.
                        int[,] TableS = new int[8, 8];
                        ///"Inizialization of This New Class (Current is Dynamic class Object) is MalFunction (Constant Variable Count).
                        QuantumAtamata Current = new QuantumAtamata(3, 3, 3);
                        ///Most Dot Net FrameWork Hot Path
                        ///Create A Clone of Current Table Constant in ThinkingChess Object Tasble.
                        for (int iii = 0; iii < 8; iii++)
                            for (int jjj = 0; jjj < 8; jjj++)
                            {
                                TableS[iii, jjj] = TableConst[iii, jjj];
                            }
                        /*
                        ///Deterimine Current Table Order and Color.
                        if (TableS[ii, jj] > 0 && CurrentArray < ThingsNumber / 2 && Order == 1)
                            color = Color.Gray;
                        else
                            if (TableS[ii, jj] < 0 && CurrentArray >= ThingsNumber / 2 && Order == -1)
                                color = Color.Brown;
                            else
                            {
                                if (!ThinkingBegin)
                                {
                                    ThinkingFinished = true;
                                    EndThread++;
                                    return;
                                }
                            }
                         */
                        ///Deterimine for Bridge King Wrongly Desision.
                        bool Bridge = false;
                        ChessRules.ExistInDestinationEnemy = false;
                        bool DoEnemySelf = true;
                        ChessRules AAA = new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, TableS[ii, jj], TableS, Order, Row, Column);
                        if (AAA.CheckMate(TableS, Order))
                        {
                            if (AAA.CheckMateGray || AAA.CheckMateBrown)
                            {
                                ThinkingFinished = true;
                                CheckMateOcuured = true;
                                EndThread++;
                                return;
                            }
                        }
                        if (Order == 1 && AAA.CheckGray)
                        {
                            IgnoreObjectDangour = 0;
                            IsCheck = true;
                            DoEnemySelf = false;
                        }
                        if (Order == -1 && AAA.CheckBrown)
                        {
                            IgnoreObjectDangour = 0;
                            IsCheck = true;
                            DoEnemySelf = false;
                        }
                        //When Root is CheckMate Benefit of Current Order No Consideration.
                        int CDumnmy = ChessRules.CurrentOrder;
                        bool EnemyCheckMateAction = false;
                        Order = DummyOrder;
                        ChessRules.CurrentOrder = DummyCurrentOrder;
                        ///Calculate Bridges of Gray King.
                        if ((new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, 7, TableS, Order, ii, jj)).Rules(ii, jj, i, j, color, 7) && (ChessRules.BridgeKingAllowedGray))
                        {
                            BridgesKingThinkingGray(DummyOrder, DummyCurrentOrder, TableS, ii, jj, Current, DoEnemySelf, PenRegStrore, EnemyCheckMateAction, i, j, Bridge);
                        }
                        else
                            ///Calculate of Bridges of Brown.
                            if ((new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, -7, TableS, Order, ii, jj)).Rules(ii, jj, i, j, color, -7) && (ChessRules.BridgeKingAllowedBrown))
                            {
                                BridgesKingThinkingBrown(DummyOrder, DummyCurrentOrder, TableS, ii, jj, Current, DoEnemySelf, PenRegStrore, EnemyCheckMateAction, i, j, Bridge);
                            }
                            else   ///For Soldier Thinking
                                if (Scop(ii, jj, i, j, 1) && System.Math.Abs(TableS[ii, jj]) == 1 && System.Math.Abs(Kind) == 1)
                                {
                                    SolderThinkingChess(DummyOrder, DummyCurrentOrder, TableS, ii, jj, Current, DoEnemySelf, PenRegStrore, EnemyCheckMateAction, i, j, Bridge);
                                }
                                else
                                    ///Else for Elephant Thinking.
                                    if (Scop(ii, jj, i, j, 2) && System.Math.Abs(TableS[ii, jj]) == 2 && System.Math.Abs(Kind) == 2)
                                    {
                                        ElephantThinkingChess(DummyOrder, DummyCurrentOrder, TableS, ii, jj, Current, DoEnemySelf, PenRegStrore, EnemyCheckMateAction, i, j, Bridge);
                                    }
                                    ///Else for Hourse Thinking.
                                    else if (Scop(ii, jj, i, j, 3) && System.Math.Abs(TableS[ii, jj]) == 3 && System.Math.Abs(Kind) == 3)
                                    {
                                        HourseThinkingChess(DummyOrder, DummyCurrentOrder, TableS, ii, jj, Current, DoEnemySelf, PenRegStrore, EnemyCheckMateAction, i, j, Bridge);
                                    }
                                    ///Else For Bridges Thinking.
                                    else
                                        if (Scop(ii, jj, i, j, 4) && System.Math.Abs(TableS[ii, jj]) == 4 && System.Math.Abs(Kind) == 4)
                                        {
                                            BridgesThinkingChess(DummyOrder, DummyCurrentOrder, TableS, ii, jj, Current, DoEnemySelf, PenRegStrore, EnemyCheckMateAction, i, j, Bridge);
                                        }
                                        ///Else for Minister Thinkings.
                                        else if (Scop(ii, jj, i, j, 5) && System.Math.Abs(TableS[ii, jj]) == 5 && System.Math.Abs(Kind) == 5)
                                        {
                                            MinisterThinkingChess(DummyOrder, DummyCurrentOrder, TableS, ii, jj, Current, DoEnemySelf, PenRegStrore, EnemyCheckMateAction, i, j, Bridge);
                                        }
                                        ///Else For Kings Thinkings.
                                        else if (Scop(ii, jj, i, j, 6) && System.Math.Abs(TableS[ii, jj]) == 6 && System.Math.Abs(Kind) == 6)
                                        {
                                            KingThinkingChess(DummyOrder, DummyCurrentOrder, TableS, ii, jj, Current, DoEnemySelf, PenRegStrore, EnemyCheckMateAction, i, j, Bridge, AAA);
                                        }
                    }
                    ///Wehn Thinkings finished by Movments found breaks.
                    if (ThinkingFinished)
                        break;
                }
                ///Initiate Global Varibales at END.
                ThinkingBegin = false;
                ///This Variable Not Work! 
                ThinkingFinished = true;

            }
            Order = DummyOrder;
            ChessRules.CurrentOrder = DummyCurrentOrder;
            EndThread++;
            //UsePenaltyRegardMechnisamT = PenRegStrore;
            //Thread.Sleep(1);
            ///Return at End.
            return;
        }
        int ObjectValueCalculator(int[,] Tabl, int Order, int ii, int jj)
        {
            int Val = 0;
            ChessRules A = new ChessRules(MovementsAStarGreedyHuristicFoundT, IgnoreSelfObjectsT, UsePenaltyRegardMechnisamT, BestMovmentsT, PredictHuristicT, OnlySelfT, AStarGreedyHuristicT, ArrangmentsChanged, Order);
            Color a = Color.Gray;
            if (Order == -1)
                a = Color.Brown;
            for (int Row = 0; Row < 8; Row++)
                for (int Column = 0; Column < 8; Column++)
                {
                    if (System.Math.Abs(Tabl[ii, jj]) == 1)
                    {
                        if (A.Rules(ii, jj, ii, jj, a, Tabl[ii, jj]))
                            Val++;
                    }
                    else
                        if (System.Math.Abs(Tabl[ii, jj]) == 2)
                        {
                            if (A.Rules(ii, jj, ii, jj, a, Tabl[ii, jj]))
                                Val++;
                        }
                        else
                            if (System.Math.Abs(Tabl[ii, jj]) == 3)
                            {
                                if (A.Rules(ii, jj, ii, jj, a, Tabl[ii, jj]))
                                    Val++;
                            }
                            else
                                if (System.Math.Abs(Tabl[ii, jj]) == 4)
                                {
                                    if (A.Rules(ii, jj, ii, jj, a, Tabl[ii, jj]))
                                        Val++;
                                }
                                else
                                    if (System.Math.Abs(Tabl[ii, jj]) == 5)
                                    {
                                        if (A.Rules(ii, jj, ii, jj, a, Tabl[ii, jj]))
                                            Val++;
                                    }
                                    else
                                        if (System.Math.Abs(Tabl[ii, jj]) == 6)
                                        {
                                            if (A.Rules(ii, jj, ii, jj, a, Tabl[ii, jj]))
                                                Val++;
                                        }
                }
            if (System.Math.Abs(Tabl[ii, jj]) == 1)
            {
                Val = Val + 1;
            }
            else
                if (System.Math.Abs(Tabl[ii, jj]) == 2)
                {
                    Val = Val * 2 + 1;
                }
                else
                    if (System.Math.Abs(Tabl[ii, jj]) == 3)
                    {
                        Val = Val * 3 + 1;
                    }
                    else
                        if (System.Math.Abs(Tabl[ii, jj]) == 4)
                        {
                            Val = Val * 4 + 1; ;
                        }
                        else
                            if (System.Math.Abs(Tabl[ii, jj]) == 5)
                            {
                                Val = Val * 8 + 1;
                            }
                            else
                                if (System.Math.Abs(Tabl[ii, jj]) == 6)
                                {
                                    Val = Val * 10 + 1;
                                }
            return Val;

        }
    }
}

//End of Documentation.
